#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x .venv/bin/python ]]; then
  echo "First run ./setup_local.sh to install the bot."
  exit 1
fi
.venv/bin/python scripts/start_local.py
