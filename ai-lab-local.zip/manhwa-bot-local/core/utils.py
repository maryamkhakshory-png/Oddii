"""ابزارهای عمومی: خواندن/نوشتن تصویر با نام فارسی، آرشیو، مرتب‌سازی طبیعی."""

from __future__ import annotations

import os
import re
import shutil
import zipfile
from pathlib import Path
from typing import Iterable, List, Sequence

import cv2
import numpy as np

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}
ARCHIVE_EXTS = {".zip", ".cbz"}


# ---------------------------------------------------------------- تصویر
def imread(path: str | Path, flags: int = cv2.IMREAD_COLOR) -> np.ndarray:
    """خواندن تصویر با پشتیبانی از مسیرهای غیر‌اسکی (فارسی)."""
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, flags)
    if img is None:
        raise ValueError(f"تصویر خوانده نشد: {path}")
    return img


def imwrite(path: str | Path, img: np.ndarray, quality: int = 92) -> Path:
    """نوشتن تصویر با پشتیبانی از مسیرهای غیر‌اسکی."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    ext = path.suffix.lower()
    if ext in (".jpg", ".jpeg"):
        params = [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)]
    elif ext == ".webp":
        params = [int(cv2.IMWRITE_WEBP_QUALITY), int(quality)]
    else:
        params = []
    ok, buf = cv2.imencode(ext if ext else ".png", img, params)
    if not ok:
        raise ValueError(f"ذخیره تصویر ناموفق بود: {path}")
    buf.tofile(str(path))
    return path


def to_bgr(img) -> np.ndarray:
    """تبدیل PIL/مسیر/آرایه به تصویر BGR نرم‌افزار OpenCV."""
    if isinstance(img, np.ndarray):
        return img if img.ndim == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    from PIL import Image  # local import

    if isinstance(img, Image.Image):
        arr = np.array(img.convert("RGB"))
        return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
    return imread(img)


def to_pil(img: np.ndarray):
    from PIL import Image

    if img.ndim == 2:
        return Image.fromarray(img)
    return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))


def resize_max(img: np.ndarray, max_side: int) -> np.ndarray:
    h, w = img.shape[:2]
    m = max(h, w)
    if m <= max_side:
        return img
    s = max_side / m
    return cv2.resize(img, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)


# ---------------------------------------------------------------- نام فایل
def natural_key(name: str):
    """مرتب‌سازی طبیعی: page2 قبل از page10."""
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", str(name))]


def list_images(folder: str | Path) -> List[Path]:
    p = Path(folder)
    files = [f for f in p.rglob("*") if f.is_file() and f.suffix.lower() in IMAGE_EXTS]
    return sorted(files, key=lambda f: natural_key(str(f.relative_to(p))))


# ---------------------------------------------------------------- آرشیو
def extract_archive(archive: str | Path, dest: str | Path) -> Path:
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            # جلوگیری از zip-slip
            target = (dest / info.filename).resolve()
            if not str(target).startswith(str(dest.resolve())):
                continue
            try:
                z.extract(info, dest)
            except Exception:
                pass
    return dest


def make_zip(files: Sequence[Path], out_path: str | Path, arc_root: str | Path | None = None) -> Path:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    root = Path(arc_root) if arc_root else None
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for f in files:
            f = Path(f)
            arcname = f.name if root is None else str(f.relative_to(root))
            z.write(f, arcname)
    return out_path


# ---------------------------------------------------------------- متفرقه
def human_bytes(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f}{unit}"
        n /= 1024.0
    return f"{n:.1f}TB"


def chunked(seq: Sequence, size: int) -> Iterable[Sequence]:
    for i in range(0, len(seq), max(1, size)):
        yield seq[i : i + size]


def clean_dir(path: str | Path) -> None:
    p = Path(path)
    if p.exists():
        shutil.rmtree(p, ignore_errors=True)
    p.mkdir(parents=True, exist_ok=True)


def free_ram_mb() -> float:
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / 1024.0
    except Exception:
        pass
    return -1.0
