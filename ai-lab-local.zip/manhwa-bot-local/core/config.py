"""تنظیمات سراسری پروژه.

سه لایه تنظیمات داریم (به ترتیب اولویت):
    1. مقادیر پیش‌فرض این فایل
    2. فایل config.yaml
    3. متغیرهای محیطی (مثل TELEGRAM_TOKEN)

نکته: هیچ کلید/توکن پولی‌ای اینجا لازم نیست. همه چیز پیش‌فرض آفلاین و رایگان است.
"""

from __future__ import annotations

import copy
import os
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

ROOT = Path(__file__).resolve().parents[1]


def _deep_update(base: dict, new: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (new or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_update(out[k], v)
        else:
            out[k] = v
    return out


@dataclass
class OcrConfig:
    engine: str = "rapid"            # rapid | paddle | easy | none
    langs: List[str] = field(default_factory=lambda: ["en"])
    min_conf: float = 0.45
    upscale: float = 1.4             # بزرگ‌کردن تصویر قبل از OCR (دقت بهتر)
    max_side: int = 1600             # محدود کردن بزرگ‌ترین ضلع (سرعت)
    # سقفِ پیکسل برای هر کاشی: مهم‌ترین اهرمِ کنترلِ حافظه روی ماشین‌های کم‌رم
    max_pixels: int = 2_500_000
    min_side: int = 620              # متن از این اندازه کوچک‌تر نشود


@dataclass
class BubbleConfig:
    enabled: bool = True
    min_area_ratio: float = 0.004    # نسبت به مساحت کل صفحه
    max_area_ratio: float = 0.45
    min_ink_ratio: float = 0.015     # نسبت پیکسل‌های تیره داخل بالن (یعنی متن دارد)
    max_ink_ratio: float = 0.55
    dark_bubbles: bool = True        # بالن‌های مشکی (مثل افکار) هم پیدا شوند
    padding: int = 4
    reading_order: str = "webtoon"   # webtoon (بالا←پایین) | manga (راست←چپ)


@dataclass
class TranslationConfig:
    engine: str = "nllb-ct2"         # nllb-ct2 | marian | llm | identity
    model_dir: str = "models/nllb-600m-ct2"
    tokenizer_dir: str = ""          # خالی یعنی همان model_dir
    src_lang: str = "eng_Latn"
    tgt_lang: str = "pes_Arab"
    beam_size: int = 4
    max_decoding_length: int = 200
    inter_threads: int = 1
    intra_threads: int = 2
    batch_size: int = 16
    register: str = "colloquial"     # colloquial | neutral | formal
    cache: bool = True


@dataclass
class LlmConfig:
    """مدلِ گفت‌وگوی محلی؛ بدون API key و بدون ارسال متن به سرویسِ بیرونی."""

    enabled: bool = True
    backend: str = "local-llama.cpp"
    model: str = "Qwen3.5-0.8B-Q4_K_M"
    model_path: str = "models/llm/Qwen3.5-0.8B-Q4_K_M.gguf"
    n_ctx: int = 2048
    n_threads: int = 1
    temperature: float = 0.65
    max_tokens: int = 320
    timeout: int = 240
    # فیلدهای سازگاری برای LLMClient قدیمی؛ در حالتِ محلی استفاده نمی‌شوند.
    base_url: str = ""
    api_key: str = ""
    polish_translation: bool = False


@dataclass
class RenderConfig:
    font_path: str = "assets/fonts/Vazirmatn-Regular.ttf"
    font_size_ratio: float = 0.28    # فقط وقتی ارتفاع متن اصلی در دسترس نیست
    min_font: int = 10
    max_font: int = 90
    line_spacing: float = 0.34
    padding_ratio: float = 0.14
    rtl: bool = True
    color: str = "#000000"
    stroke_color: str = "#FFFFFF"
    stroke_width_ratio: float = 0.0  # 0 یعنی بدون حاشیه؛ 0.06 خوانایی را بهتر می‌کند
    align: str = "center"


@dataclass
class InpaintConfig:
    method: str = "auto"             # auto | inpaint | fill
    radius: int = 5
    dilate: int = 3
    threshold_offset: int = 42       # آستانه تشخیص پیکسل‌های متن نسبت به میانه روشنایی


@dataclass
class TtsConfig:
    engine: str = "edge"             # edge (رایگان، نیاز به اینترنت) | none
    voice: str = "fa-IR-DilaraNeural"
    rate: str = "+0%"
    volume: str = "+0%"


@dataclass
class BotConfig:
    token: str = ""                  # از متغیر محیطی TELEGRAM_TOKEN
    max_pages: int = 60
    max_zip_mb: int = 200
    send_preview: int = 3
    admin_ids: List[int] = field(default_factory=list)


@dataclass
class Config:
    ocr: OcrConfig = field(default_factory=OcrConfig)
    bubbles: BubbleConfig = field(default_factory=BubbleConfig)
    translation: TranslationConfig = field(default_factory=TranslationConfig)
    llm: LlmConfig = field(default_factory=LlmConfig)
    render: RenderConfig = field(default_factory=RenderConfig)
    inpaint: InpaintConfig = field(default_factory=InpaintConfig)
    tts: TtsConfig = field(default_factory=TtsConfig)
    bot: BotConfig = field(default_factory=BotConfig)
    work_dir: str = "data"
    log_level: str = "INFO"
    # auto = اگر رم کم باشد، مدل ترجمه را فقط هنگام نیاز بار کن
    low_memory: str = "auto"

    @property
    def use_low_memory(self) -> bool:
        v = str(self.low_memory).lower()
        if v in ("1", "true", "yes"):
            return True
        if v in ("0", "false", "no"):
            return False
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        total_mb = int(line.split()[1]) / 1024.0
                        return total_mb < 3072
        except Exception:
            pass
        return False

    # -------- مسیرها --------
    def path(self, rel: str) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else (ROOT / p)

    @property
    def model_dir(self) -> Path:
        return self.path(self.translation.model_dir)

    @property
    def tokenizer_dir(self) -> Path:
        d = self.translation.tokenizer_dir or self.translation.model_dir
        return self.path(d)

    @property
    def font_path(self) -> Path:
        return self.path(self.render.font_path)

    @property
    def work_dir_path(self) -> Path:
        p = self.path(self.work_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p


DEFAULTS: Dict[str, Any] = {
    "ocr": {},
    "bubbles": {},
    "translation": {},
    "llm": {},
    "render": {},
    "inpaint": {},
    "tts": {},
    "bot": {},
}


def _build(section_cls, data: dict):
    valid = {f.name for f in fields(section_cls)}
    clean = {k: v for k, v in (data or {}).items() if k in valid and v is not None}
    return section_cls(**clean)


def load_config(path: Optional[str | Path] = None) -> Config:
    data: Dict[str, Any] = {}
    p = Path(path) if path else (ROOT / "config.yaml")
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    data = _deep_update(DEFAULTS, data)

    cfg = Config(
        ocr=_build(OcrConfig, data.get("ocr")),
        bubbles=_build(BubbleConfig, data.get("bubbles")),
        translation=_build(TranslationConfig, data.get("translation")),
        llm=_build(LlmConfig, data.get("llm")),
        render=_build(RenderConfig, data.get("render")),
        inpaint=_build(InpaintConfig, data.get("inpaint")),
        tts=_build(TtsConfig, data.get("tts")),
        bot=_build(BotConfig, data.get("bot")),
    )
    cfg.work_dir = data.get("work_dir", cfg.work_dir)
    cfg.log_level = data.get("log_level", cfg.log_level)

    # ---- overrides from environment ----
    if os.getenv("TELEGRAM_TOKEN"):
        cfg.bot.token = os.environ["TELEGRAM_TOKEN"]
    return cfg


CONFIG = load_config()
