"""تنظیم لاگ یکپارچه برای کل پروژه."""

from __future__ import annotations

import logging
import sys

_CONFIGURED = False


def setup(level: str = "INFO", name: str = "ai-lab") -> logging.Logger:
    global _CONFIGURED
    log = logging.getLogger(name)
    if _CONFIGURED:
        return log
    log.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    log.handlers.clear()
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s | %(levelname)-7s | %(name)-18s | %(message)s",
            datefmt="%H:%M:%S",
        )
    )
    log.addHandler(h)
    log.propagate = False
    _CONFIGURED = True
    return log


def get(name: str = "ai-lab") -> logging.Logger:
    return logging.getLogger("ai-lab." + name) if name != "ai-lab" else logging.getLogger("ai-lab")
