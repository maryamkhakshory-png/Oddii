"""وب‌سرویس سبک برای تست خط لوله.

    python -m uvicorn server.app:app --host 0.0.0.0 --port 8000

همه چیز (CSS/JS) درون همین فایل است تا بدون اینترنت هم بالا بیاید.
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import time
import uuid

# مصرفِ حافظه را روی ماشین‌های کم‌رم پایین نگه می‌داریم
os.environ.setdefault("MALLOC_ARENA_MAX", "2")
os.environ.setdefault("OMP_NUM_THREADS", "2")
from pathlib import Path
from typing import Dict, List, Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fastapi import FastAPI, File, Form, UploadFile  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse  # noqa: E402

from core.config import load_config  # noqa: E402
from core.logging_setup import setup  # noqa: E402
from core.utils import (ARCHIVE_EXTS, IMAGE_EXTS, extract_archive,  # noqa: E402
                        imread, imwrite, list_images, make_zip)

CFG = load_config()
LOG = setup(CFG.log_level)
WEB_DIR = CFG.work_dir_path / "web"
WEB_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="مانها‌گردان", version="1.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=False,
    allow_methods=["*"], allow_headers=["*"],
)

JOBS: Dict[str, dict] = {}
_PIPE = None
_LOCK = asyncio.Semaphore(1)  # پردازش پشت‌سرهم (RAM کم)


def get_pipeline():
    global _PIPE
    if _PIPE is None:
        from llm.client import LLMClient
        from vision.pipeline import ManhwaPipeline

        llm = LLMClient.from_config(CFG.llm)
        _PIPE = ManhwaPipeline(CFG, log=LOG, llm=llm)
    return _PIPE


# ------------------------------------------------------------------ صفحه
INDEX = """<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>مانها‌گردان — ترجمه‌ی خودکار بالن‌ها</title>
<style>
:root{--bg:#0f1117;--card:#181b24;--line:#2a2f3d;--txt:#e8eaf0;--dim:#9aa3b5;--acc:#6ee7b7;--acc2:#60a5fa}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--txt);
font-family:Vazirmatn,"Noto Naskh Arabic",Tahoma,sans-serif;padding:24px}
.wrap{max-width:1080px;margin:0 auto}
h1{font-size:24px;margin:0 0 6px}.sub{color:var(--dim);font-size:14px;margin-bottom:22px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:18px}
.drop{border:2px dashed var(--line);border-radius:12px;padding:34px;text-align:center;cursor:pointer;transition:.15s}
.drop:hover,.drop.over{border-color:var(--acc);background:#1b2130}
.row{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:14px}
button{background:var(--acc);color:#06231a;border:0;border-radius:10px;padding:11px 20px;font-weight:700;
cursor:pointer;font-family:inherit;font-size:14px}button:disabled{opacity:.45;cursor:not-allowed}
button.alt{background:transparent;color:var(--acc);border:1px solid var(--acc)}
select,input[type=text]{background:#11141c;color:var(--txt);border:1px solid var(--line);
border-radius:9px;padding:9px 12px;font-family:inherit;font-size:14px}
label{font-size:13px;color:var(--dim)}
.bar{height:8px;background:#11141c;border-radius:99px;overflow:hidden;margin-top:14px}
.bar>i{display:block;height:100%;background:linear-gradient(90deg,var(--acc),var(--acc2));width:0;transition:.3s}
#log{font-size:13px;color:var(--dim);margin-top:10px;line-height:1.9;direction:rtl}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}
@media(max-width:820px){.grid{grid-template-columns:1fr}}
.pair{background:#11141c;border:1px solid var(--line);border-radius:12px;overflow:hidden}
.pair img{width:100%;display:block;background:#fff}
.cap{padding:8px 12px;font-size:12px;color:var(--dim);line-height:1.8}
.cap b{color:var(--acc);font-weight:600}
.tag{display:inline-block;background:#1d2432;color:var(--acc2);border-radius:6px;padding:2px 7px;font-size:11px;margin:2px}
</style></head><body><div class="wrap">
<h1>🧠 مانها‌گردان</h1>
<div class="sub">ترجمه‌ی خودکارِ بالن‌های مانها/مانگا از انگلیسی به فارسیِ عامیانه — کاملاً آفلاین و رایگان</div>

<div class="card">
  <div class="drop" id="drop">📁 عکس‌ها یا فایل ZIP/CBZ فصل را اینجا بکشید یا کلیک کنید
    <div style="font-size:12px;color:#9aa3b5;margin-top:8px">PNG / JPG / WEBP / ZIP</div></div>
  <input type="file" id="file" multiple accept=".png,.jpg,.jpeg,.webp,.zip,.cbz" hidden>
  <div class="row">
    <label>لحن:
      <select id="register">
        <option value="colloquial">عامیانه (پیش‌فرض)</option>
        <option value="neutral">متعادل</option>
        <option value="formal">رسمی</option>
      </select></label>
    <label>منبع:
      <select id="srclang"><option value="eng_Latn">انگلیسی</option>
      <option value="jpn_Jpan">ژاپنی</option><option value="kor_Hang">کره‌ای</option>
      <option value="zho_Hans">چینی</option><option value="ara_Arab">عربی</option></select></label>
    <button id="go" disabled>ترجمه کن</button>
    <button class="alt" id="clear">پاک کن</button>
  </div>
  <div class="bar"><i id="bar"></i></div>
  <div id="log">آماده‌ام. یک تصویر یا فصل انتخاب کن.</div>
</div>

<div id="out"></div>
<audio id="player" controls style="display:none;width:100%;margin-top:10px"></audio>

<script>
const drop=document.getElementById('drop'),file=document.getElementById('file'),
 go=document.getElementById('go'),out=document.getElementById('out'),logEl=document.getElementById('log'),
 bar=document.getElementById('bar'),clearB=document.getElementById('clear');
let job=null,timer=null;
drop.onclick=()=>file.click();
['dragenter','dragover'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.remove('over')}));
drop.addEventListener('drop',ev=>{file.files=ev.dataTransfer.files;updateBtn()});
file.onchange=updateBtn;
clearB.onclick=()=>{out.innerHTML='';logEl.textContent='پاک شد.';bar.style.width='0';file.value='';updateBtn()};
function updateBtn(){go.disabled=!(file.files&&file.files.length)}
go.onclick=async()=>{
  go.disabled=true;out.innerHTML='';bar.style.width='4%';logEl.textContent='در حال آپلود...';
  const fd=new FormData();
  for(const f of file.files) fd.append('files',f);
  fd.append('register',document.getElementById('register').value);
  fd.append('src_lang',document.getElementById('srclang').value);
  const r=await fetch('/api/translate',{method:'POST',body:fd});
  const j=await r.json(); if(j.error){logEl.textContent='خطا: '+j.error;go.disabled=false;return}
  job=j.job; timer=setInterval(poll,900); poll();
};
async function poll(){
  const r=await fetch('/api/status/'+job), j=await r.json();
  bar.style.width=Math.max(4,Math.round(100*j.done/Math.max(1,j.total)))+'%';
  logEl.textContent=j.message||'';
  if(j.status==='done'){
    clearInterval(timer); go.disabled=false;
    let h='';
    for(const p of j.pages){
      h+=`<div class="card"><div style="font-size:14px;margin-bottom:8px">📄 ${p.name}</div>
      <div class="grid">
        <div class="pair"><div class="cap">قبل</div><img src="${p.before}" loading="lazy"></div>
        <div class="pair"><div class="cap">بعد</div><img src="${p.after}" loading="lazy"></div>
      </div><div class="cap">`+
      (p.texts||[]).map(t=>`<span class="tag">${escapeHtml(t.src)} → ${escapeHtml(t.fa)}</span>`).join(' ')+
      `</div></div>`;
    }
    if(j.zip) h+=`<div class="card"><a href="${j.zip}" download><button>⬇️ دریافت فصل ترجمه‌شده (ZIP)</button></a></div>`;
    out.innerHTML=h;
  }
}
function escapeHtml(s){return (s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
</script>
</div></body></html>"""


@app.get("/", response_class=HTMLResponse)
def index():
    return INDEX


# ------------------------------------------------------------- API
@app.post("/api/translate")
async def translate(files: List[UploadFile] = File(...), register: str = Form("colloquial"),
                    src_lang: str = Form("eng_Latn"), tgt_lang: str = Form("pes_Arab")):
    job = uuid.uuid4().hex[:12]
    jdir = WEB_DIR / job
    clean = jdir / "in"
    (jdir / "out").mkdir(parents=True, exist_ok=True)
    clean.mkdir(parents=True, exist_ok=True)

    saved: List[Path] = []
    for f in files:
        ext = Path(f.filename or "").suffix.lower()
        if ext not in IMAGE_EXTS and ext not in ARCHIVE_EXTS:
            continue
        dest = clean / Path(f.filename or "file").name
        with open(dest, "wb") as fh:
            shutil.copyfileobj(f.file, fh)
        saved.append(dest)
    if not saved:
        return JSONResponse({"error": "هیچ فایل معتبری فرستاده نشد"}, status_code=400)

    JOBS[job] = {"status": "queued", "done": 0, "total": 0, "message": "در صف",
                 "pages": [], "zip": None, "started": time.time()}
    asyncio.create_task(_run(job, jdir, saved, register, src_lang, tgt_lang))
    return {"job": job}


async def _run(job: str, jdir: Path, inputs: List[Path], register: str,
               src_lang: str, tgt_lang: str) -> None:
    JOBS[job]["status"] = "running"
    try:
        pipe = await asyncio.to_thread(get_pipeline)
        pipe.cfg.translation.register = register
        pipe.cfg.translation.src_lang = src_lang
        pipe.cfg.translation.tgt_lang = tgt_lang
        pipe.colloq.register = register

        pages: List[Path] = []
        for p in inputs:
            if p.suffix.lower() in ARCHIVE_EXTS:
                pages.extend(list_images(extract_archive(p, jdir / "in" / ("_" + p.stem))))
            else:
                pages.append(p)
        pages = pages[: int(CFG.bot.max_pages)]
        JOBS[job]["total"] = len(pages)

        out_dir = jdir / "out"
        results = []
        for i, p in enumerate(pages, 1):
            JOBS[job]["message"] = f"در حال پردازش {p.name} ({i}/{len(pages)})"
            async with _LOCK:
                res = await asyncio.to_thread(pipe.process_path, p)
            if res.ok and res.image is not None:
                op = out_dir / (p.stem + "_fa" + p.suffix.lower())
                imwrite(op, res.image)
                results.append({
                    "name": p.name,
                    "before": f"/files/{job}/in/{p.relative_to(jdir / 'in').as_posix()}",
                    "after": f"/files/{job}/out/{op.name}",
                    "texts": [{"src": r.source.replace("\n", " "), "fa": r.translated}
                              for r in res.regions],
                })
            JOBS[job]["done"] = i
        JOBS[job]["pages"] = results
        if results:
            zp = jdir / "chapter_fa.zip"
            make_zip(sorted((jdir / "out").glob("*")), zp)
            JOBS[job]["zip"] = f"/files/{job}/chapter_fa.zip"
        JOBS[job]["status"] = "done"
        JOBS[job]["message"] = f"✅ {len(results)} صفحه در {time.time() - JOBS[job]['started']:.0f} ثانیه"
    except Exception as e:
        JOBS[job]["status"] = "error"
        JOBS[job]["message"] = f"خطا: {type(e).__name__}: {e}"
        LOG.exception(e)


@app.get("/api/status/{job}")
def status(job: str):
    j = JOBS.get(job)
    if not j:
        return JSONResponse({"error": "کار یافت نشد"}, status_code=404)
    return {k: j.get(k) for k in ("status", "done", "total", "message", "pages", "zip")}


@app.get("/files/{job}/{kind}/{name:path}")
def files(job: str, kind: str, name: str):
    base = WEB_DIR / job
    if kind == "chapter_fa.zip":
        p = base / "chapter_fa.zip"
    else:
        p = base / kind / name
    if not p.exists() or base not in p.parents and p != base / "chapter_fa.zip":
        return JSONResponse({"error": "not found"}, status_code=404)
    return FileResponse(p)


@app.get("/api/health")
def health():
    return {"ok": True, "jobs": len(JOBS)}
