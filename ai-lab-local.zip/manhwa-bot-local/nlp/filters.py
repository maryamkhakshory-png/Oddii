"""فیلترِ متن‌هایی که نباید ترجمه شوند.

روی صفحه‌ی واقعیِ مانها فقط دیالوگ نیست: واترمارکِ گروه اسکن (نوشته‌ی چینی/کره‌ای)،
آدرسِ سایت (FIRESCANS.XYZ)، لوگو و امضا هم با OCR بیرون می‌آیند. ترجمه‌ی این‌ها
یا خروجیِ بی‌ربط می‌دهد یا اثر هنری را خراب می‌کند. قانون ساده:
«اگر متن انگلیسیِ قابل‌خواندن نیست، دست نزن.»
"""

from __future__ import annotations

import re

# حداقل دو حرف لاتینِ پشت‌سرهم: زبانِ مقصدِ ما از انگلیسی است
_LATIN = re.compile(r"[A-Za-z]{2,}")

# خطوطِ غیرلاتین (چینی، ژاپنی، کره‌ای، عربی، سیریلیک)
_NON_LATIN = re.compile(
    r"[㐀-鿿぀-ヿ가-힯؀-ۿЀ-ӿ]"
)

# نشانیِ اینترنتی / دامنه‌ی سایت
_URL = re.compile(
    r"(?:https?://|www\.)"
    r"|(?:\b[A-Za-z0-9][A-Za-z0-9-]{1,30}\.(?:xyz|com|net|org|io|cc|me|tv|co|site|"
    r"online|fun|top|blog|link|dev|app|info|biz|rocks|to)\b)",
    re.IGNORECASE,
)

# اعتبارِ گروه اسکن که معمولاً با این واژه‌ها شروع می‌شود
_CREDIT = re.compile(
    r"^\s*(?:scan|scans|scanlation|translated?\s+by|edited?\s+by|typeset|"
    r"proofread|raw\s+provider|credits?)\b", re.IGNORECASE)

# بنرهای تبلیغاتیِ گروه‌های اسکن — هر جای متن که باشند، ترجمه نمی‌شوند
_WATERMARK = re.compile(
    r"our\s+website|read(?:ing)?\s+(?:the\s+)?(?:series|latest|chapter|more)|"
    r"support\s+(?:the\s+)?(?:team|us)|visit\s+us|join\s+our|"
    r"firescans|mangadex|tapas|webtoon\.com|patreon|discord\.gg",
    re.IGNORECASE)


def looks_translatable(text: str) -> bool:
    """آیا این متن ارزشِ ترجمه دارد؟"""
    t = (text or "").strip()
    if not t:
        return False
    if not _LATIN.search(t):
        return False                       # چینی/کره‌ای/... — مدل انگلیسی نمی‌فهمد
    # اگر حروفِ غیرلاتین بیشتر از لاتین است، احتمالاً واترمارک است
    latin = len(_LATIN.findall(t))
    other = len(_NON_LATIN.findall(t))
    if other and other >= latin:
        return False
    if _WATERMARK.search(t):
        return False                       # بنرِ تبلیغاتیِ گروه اسکن
    if _CREDIT.match(t) and len(t.split()) <= 5:
        return False
    if _URL.search(t):
        # متن‌های بلندتر را رها کن («VISIT OUR SITE …» هنوز معنا دارد)
        return len(t.split()) >= 6
    return True


def filter_regions(regions) -> tuple[list, list]:
    """دو دسته برمی‌گرداند: (قابل ترجمه، رها‌شده)."""
    keep, skip = [], []
    for r in regions:
        (keep if looks_translatable(getattr(r, "source", "")) else skip).append(r)
    return keep, skip


if __name__ == "__main__":
    samples = [
        "BACK WHEN I WAS STUDYING, I WAS SO BROKE",
        "FIRESCANS.XYZ",
        "终极肆意",
        "腾机动漫",
        "SUPPORT THE TEAM BY READING THE SERIES ON OUR WEBSITE FIRESCANS",
        "Scanlated by SomeGroup",
        "TSK, HOW COULD I FORGET!",
        "Louis",
        "!!",
    ]
    for s in samples:
        print(f"{looks_translatable(s)!s:5}  {s}")
