"""«عامیانه‌ساز» — لایه‌ای که خودمان نوشته‌ایم تا خروجی ترجمه‌ی رسمی را به
فارسیِ گفتاریِ روزمره نزدیک کند.

سه سطح دارد:
    formal    → فقط نرمال‌سازی (ی/ک عربی، نیم‌فاصله، کشیده)
    neutral   → + اصلاح‌های بی‌خطر (بسیار→خیلی، اکنون→الان، ...)
    colloquial→ + تبدیل افعال و ضمایر به گفتاری (می‌خواهم→می‌خوام، مرا→منو، ...)

چرا این لایه وجود دارد؟ چون مدل‌های ترجمه (مثل NLLB) روی متن رسمی آموزش
دیده‌اند و برای دیالوگِ مانها/مانگا بیش از حد کتابی حرف می‌زنند.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Pattern, Tuple, Union

try:  # هم به صورت پکیج و هم اسکریپت قابل اجرا باشد
    from vision.render import normalize_fa
except ImportError:  # pragma: no cover
    from ..vision.render import normalize_fa

HERE = Path(__file__).resolve().parent
SEP = r"[\s\u200c‌]*"  # فاصله یا نیم‌فاصله‌ی احتمالی


def _verb(pattern_stem: str, mapping: Dict[str, str]) -> List[Tuple[Pattern, str]]:
    """ساختن قاعده‌های صرفی: الگو + جایگزین برای هر شخص."""
    rules = []
    for suffix, repl in mapping.items():
        # حالت مثبت: می‌خواهم → می‌خوام
        rules.append((re.compile(rf"می{SEP}{pattern_stem}{suffix}\b"), repl))
        # حالت منفی: نمی‌خواهم → نمی‌خوام
        rules.append((re.compile(rf"نمی{SEP}{pattern_stem}{suffix}\b"), "ن" + repl))
    return rules


def _est_clitic(m: "re.Match") -> str:
    """«است» را به صورت گفتاری به کلمه‌ی قبل می‌چسباند.

    خوب است → خوبه | زیبا است → زیباست (حروف پایانیِ ا/و/ی نیاز به «س» میانجی دارند)
    """
    last = m.group(1)
    if last in ("ا", "و", "ی"):
        return last + "ست"
    if last == "ه":
        return m.group(0)
    return last + "ه"


def _mk(stem: str, ends: Dict[str, str]) -> List[Tuple[Pattern, str]]:
    """قاعده برای افعال می‌خواهم/می‌خواهی/... به شکل گفتاری."""
    return _verb(stem, ends)


# مدل ترجمه گاهی خودش عامیانه می‌نویسد ولی نیم‌فاصله نمی‌گذارد: «میتونم»، «میخوام»
# این قانون‌ها نیم‌فاصله را برمی‌گردانند — پیش از قواعد صرفی اجرا می‌شوند.
_VERB_STEMS = (
    "تون|خواه|خوای|خوام|خواد|خوایم|خواید|خوان|دان|دون|روم|رفت|ریم|رید|رن|رم|ری|ره|"
    "گوی|گویم|گویی|گوییم|گویید|گویند|گم|گی|گه|کن|شو|شم|شی|شه|ده|دم|دی|"
    "یام|یای|یاد|بین|خور|گیر|ترس|فهم|آی|آم|آد|مان|برم|آور"
)
INSERT_ZWNJ_RULES: List[Tuple[Pattern, str]] = [
    (re.compile(rf"\b(ن?می)(?={_VERB_STEMS})"), "\\1\u200c"),
    (re.compile(r"\b(بی)(?=خیال|خود|صبر|حوصل|فایده|سواد|ادب|گناه|شعور|تفاوت|سابقه|همتا|نظیر|میل|رغبت)"),
     "\\1\u200c"),
]

RULES_COLLOQUIAL: List[Tuple[Pattern, str]] = []
RULES_COLLOQUIAL += _mk("خواه", {"م": "می‌خوام", "ی": "می‌خوای", "د": "می‌خواد",
                                 "یم": "می‌خوایم", "ید": "می‌خواید", "ند": "می‌خوان"})
RULES_COLLOQUIAL += _mk("دان", {"م": "می‌دونم", "ی": "می‌دونی", "د": "می‌دونه",
                                "یم": "می‌دونیم", "ید": "می‌دونید", "ند": "می‌دونن"})
RULES_COLLOQUIAL += _mk("رو", {"م": "می‌رم", "ی": "می‌ری", "د": "می‌ره",
                               "یم": "می‌ریم", "ید": "می‌رید", "ند": "می‌رن"})
RULES_COLLOQUIAL += _mk("گوی", {"م": "می‌گم", "ی": "می‌گی", "د": "می‌گه",
                                "یم": "می‌گیم", "ید": "می‌گید", "ند": "می‌گن"})
RULES_COLLOQUIAL += _mk("ده", {"م": "می‌دم", "ی": "می‌دی", "د": "می‌ده",
                               "یم": "می‌دیم", "ید": "می‌دید", "ند": "می‌دن"})
RULES_COLLOQUIAL += _mk("توان", {"م": "می‌تونم", "ی": "می‌تونی", "د": "می‌تونه",
                                 "یم": "می‌تونیم", "ید": "می‌تونید", "ند": "می‌تونن"})
RULES_COLLOQUIAL += _mk("آی", {"م": "میام", "ی": "میای", "د": "میاد",
                               "یم": "میایم", "ید": "میاید", "ند": "میان"})
RULES_COLLOQUIAL += _mk("کن", {"م": "می‌کنم", "ی": "می‌کنی", "د": "می‌کنه",
                               "یم": "می‌کنیم", "ید": "می‌کنید", "ند": "می‌کنن"})
RULES_COLLOQUIAL += _mk("بین", {"م": "می‌بینم", "ی": "می‌بینی", "د": "می‌بینه",
                                "یم": "می‌بینیم", "ید": "می‌بینید", "ند": "می‌بینن"})
RULES_COLLOQUIAL += _mk("شو", {"م": "می‌شم", "ی": "می‌شی", "د": "می‌شه",
                               "یم": "می‌شیم", "ید": "می‌شید", "ند": "می‌شن"})
RULES_COLLOQUIAL += _mk("خور", {"م": "می‌خورم", "ی": "می‌خوری", "د": "می‌خوره",
                                "یم": "می‌خوریم", "ید": "می‌خورید", "ند": "می‌خورن"})
RULES_COLLOQUIAL += _mk("گیر", {"م": "می‌گیرم", "ی": "می‌گیری", "د": "می‌گیره",
                                "یم": "می‌گیریم", "ید": "می‌گیرید", "ند": "می‌گیرن"})

# --- فعل‌های التزامی/امری: بروم → برم، بگوید → بگه، بیاید → بیاد -----------
_SUBJ_MAP = {
    "روم": "برم", "روی": "بری", "رود": "بره", "رویم": "بریم", "روید": "برید", "روند": "برن",
    "گویم": "بگم", "گویی": "بگی", "گوید": "بگه", "گوییم": "بگیم", "گویید": "بگید", "گویند": "بگن",
    "دهم": "بدم", "دهی": "بدی", "دهد": "بده", "دهیم": "بدیم", "دهید": "بدید", "دهند": "بدن",
    "خواهم": "بخوام", "خواهی": "بخوای", "خواهد": "بخواد", "خواهیم": "بخوایم",
    "خواهید": "بخواید", "خواهند": "بخوان",
    "توانم": "بتونم", "توانی": "بتونی", "تواند": "بتونه", "توانیم": "بتونیم",
    "توانید": "بتونید", "توانند": "بتونن",
    "دانم": "بدونم", "دانی": "بدونی", "داند": "بدونه", "دانیم": "بدونیم",
    "دانید": "بدونید", "دانند": "بدونن",
    "شوم": "بشم", "شوی": "بشی", "شود": "بشه", "شویم": "بشیم", "شوید": "بشید", "شوند": "بشن",
    "آیم": "بیام", "آیی": "بیای", "آید": "بیاد", "آییم": "بیایم", "آیید": "بیاید", "آیند": "بیان",
    "گیرم": "بگیرم", "گیری": "بگیری", "گیرد": "بگیره",
}
RULES_COLLOQUIAL += [
    (re.compile(rf"\bب{SEP}{form}\b"), repl) for form, repl in _SUBJ_MAP.items()
]
RULES_COLLOQUIAL += [
    (re.compile(rf"\bن{SEP}ب{SEP}{form}\b"), "ن" + repl) for form, repl in _SUBJ_MAP.items()
]

# --- آینده‌ی صرفی: خواهد رفت → می‌ره -------------------------------------
_FUTURE_STEMS = {
    "رفت": "ر", "کرد": "کن", "شد": "ش", "گفت": "گ", "داد": "د", "گرفت": "گیر",
    "آمد": "آ", "خورد": "خور", "دید": "بین", "ماند": "مان", "برد": "بر",
    "آورد": "آور", "نوشت": "نویس", "خواند": "خون", "شنید": "شنو", "فروخت": "فروش",
    "خرید": "خر", "ساخت": "ساز", "پخت": "پز", "دوید": "دو", "پرید": "پر",
}
_FUTURE_ENDS = {"م": "م", "ی": "ی", "د": "ه", "یم": "یم", "ید": "ید", "ند": "ن"}
_FUTURE_EXCEPT = {"آمد": {"م": "میام", "ی": "میای", "د": "میاد", "یم": "میایم",
                          "ید": "میاید", "ند": "میان"}}


def _future_rules() -> List[Tuple[Pattern, str]]:
    rules = []
    for verb, stem in _FUTURE_STEMS.items():
        for end, suffix in _FUTURE_ENDS.items():
            pat = re.compile(rf"(ن?)\s*خواه{end}{SEP}{verb}\b")
            if verb in _FUTURE_EXCEPT and end in _FUTURE_EXCEPT[verb]:
                repl_fn = _FUTURE_EXCEPT[verb][end]
            else:
                repl_fn = "می‌" + stem + suffix
            rules.append((pat, lambda m, r=repl_fn: (("نمی‌" + r[3:]) if m.group(1) else r)))
    return rules


RULES_COLLOQUIAL += _future_rules()

# --- عبارت‌ها و قیدها ----------------------------------------------------
PHRASE_RULES: List[Tuple[Pattern, Any]] = [
    (re.compile(rf"می{SEP}باشد"), "هست"),
    # «است» گفتاری می‌چسبد به کلمه‌ی قبل: «خوب است» → «خوبه»
    (re.compile(r"([\u0600-\u06FF])[\s\u200c]+است(?=[\s\u0600-\u06FF.!؟?،,]|$)"), _est_clitic),
    (re.compile(r"^است(?=[\s]?[.!؟?]|$)"), "هست"),
    (re.compile(r"\bبسیار\b"), "خیلی"),
    (re.compile(r"\bاکنون\b"), "الان"),
    (re.compile(r"\bهم‌اکنون\b"), "الان"),
    (re.compile(r"\bاینک\b"), "الان"),
    (re.compile(r"\bدیگر\b(?!ی)"), "دیگه"),
    (re.compile(r"\bبله\b"), "آره"),
    (re.compile(r"\bخیر\b"), "نه"),
    (re.compile(r"\bباشد\b"), "باشه"),
    (re.compile(r"\bبسیار خوب\b"), "باشه"),
    (re.compile(r"\bمتشکرم\b"), "ممنون"),
    (re.compile(r"\bسپاس‌گزارم\b"), "ممنون"),
    (re.compile(r"\bسپاسگزارم\b"), "ممنون"),
    (re.compile(r"\bچه اتفاقی افتاد\b"), "چی شد"),
    (re.compile(rf"چه{SEP}کار{SEP}می‌?کنی"), "چیکار می‌کنی"),
    (re.compile(r"\bمرا\b"), "منو"),
    (re.compile(r"\bتو را\b"), "تورو"),
    (re.compile(r"\bاو را\b"), "اونو"),
    (re.compile(r"\bشما را\b"), "شمارو"),
    (re.compile(r"\bما را\b"), "مارو"),
    (re.compile(r"\bآن‌ها را\b"), "اونارو"),
    (re.compile(r"\bآنها را\b"), "اونارو"),
    (re.compile(rf"برای{SEP}من"), "واسه من"),
    (re.compile(rf"برای{SEP}تو"), "واسه تو"),
    (re.compile(rf"برای{SEP}او"), "واسش"),
    (re.compile(rf"از{SEP}او\b"), "ازش"),
    (re.compile(rf"به{SEP}او\b"), "بهش"),
    (re.compile(rf"با{SEP}او\b"), "باهاش"),
    (re.compile(rf"از{SEP}تو\b"), "ازت"),
    (re.compile(rf"به{SEP}تو\b"), "بهت"),
    (re.compile(rf"با{SEP}تو\b"), "باهات"),
    (re.compile(rf"از{SEP}من\b"), "ازم"),
    (re.compile(rf"برای{SEP}چه"), "واسه چی"),
    (re.compile(r"\bچگونه\b"), "چطور"),
    (re.compile(r"\bمحافظت\b"), "مراقبت"),
    (re.compile(r"\bمی‌?خواهی\b"), "می‌خوای"),
    (re.compile(r"\bفکر می‌کنم\b"), "فکر کنم"),
    (re.compile(r"\bمتوجه نمی‌شوم\b"), "نمی‌فهمم"),
    (re.compile(r"\bخداحافظ\b"), "فعلاً"),
    (re.compile(r"\bببخشید\b"), "ببخشید"),
    (re.compile(r"\bبگذار\b"), "بذار"),
    (re.compile(r"\bمی‌خواهی\b"), "می‌خوای"),
]

# قانون‌هایی که فقط در سطح «عامیانه» اعمال می‌شوند
STRONG_RULES: List[Tuple[Pattern, str]] = [
    (re.compile(r"\bآیا\s+"), ""),
    # حذف «من» اضافه پیش از فعل (در گفتار معمولاً گفته نمی‌شود و جا هم کم می‌کند)
    (re.compile(r"^من\s+(?=(ن?می|ن?ب|ن?خواه)[\u0600-\u06FF\u200c])"), ""),
    (re.compile(r"\bخواهشمندم\b"), "لطفاً"),
    (re.compile(r"\bبفرمایید\b"), "بفرما"),
    (re.compile(r"\bباید\s+ترک\s+کنم\b"), "باید برم"),
    (re.compile(r"\bفراموشش?\s+کن\b"), "بی‌خیالش شو"),
    (re.compile(r"\bموفق\s+باشید\b"), "موفق باشی"),
]

# قانون‌های بی‌خطر برای همه‌ی سطوح
SAFE_RULES: List[Tuple[Pattern, str]] = [
    (re.compile(r"\s+([.!؟?،,:])"), r"\1"),
    (re.compile(r"([.!؟?])([^\s.!؟?])"), r"\1 \2"),
    (re.compile(r"\s{2,}"), " "),
]


@dataclass
class Colloquializer:
    register: str = "colloquial"
    idioms: Dict[str, str] = field(default_factory=dict)
    sfx: Dict[str, str] = field(default_factory=dict)
    names: Dict[str, str] = field(default_factory=dict)
    contractions: Dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_file(cls, path: str | Path | None, register: str = "colloquial") -> "Colloquializer":
        data: Dict[str, dict] = {}
        p = Path(path) if path else HERE / "glossary.json"
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f) or {}
        except Exception:
            data = {}
        obj = cls(
            register=register,
            idioms={k.lower(): v for k, v in (data.get("idioms") or {}).items()},
            sfx={k.upper(): v for k, v in (data.get("sfx") or {}).items()},
            names=dict(data.get("names") or {}),
            contractions={k.lower(): v for k, v in (data.get("contractions") or {}).items()},
        )
        return obj

    # ---------------------------------------------------------- انگلیسی
    def preprocess_en(self, text: str) -> str:
        """آماده‌سازی متن انگلیسی قبل از ترجمه (باز کردن مخفف‌ها و اصطلاح‌ها)."""
        t = (text or "").strip()
        if not t:
            return t
        out = []
        for tok in re.split(r"(\W+)", t):
            low = tok.lower()
            if low in self.contractions:
                out.append(self.contractions[low])
            else:
                out.append(tok)
        t = "".join(out)
        return re.sub(r"\s{2,}", " ", t).strip()

    def lookup_direct(self, text: str) -> str | None:
        """اگر کلِ عبارت در واژه‌نامه هست، مستقیم جواب بده (بدون صدا زدن مدل)."""
        t = (text or "").strip().strip("!.,?؟").strip()
        if not t:
            return None
        low = t.lower()
        if low in self.idioms:
            return self.idioms[low]
        up = t.upper()
        if up in self.sfx:
            return self.sfx[up]
        # صداهای کوتاه (مثل BOOM!) که فقط یک کلمه‌اند
        words = t.split()
        if len(words) == 1 and up.isupper() and up in self.sfx:
            return self.sfx[up]
        return None

    # ---------------------------------------------------------- فارسی
    def apply_names(self, fa: str) -> str:
        for en, pers in self.names.items():
            if not en:
                continue
            fa = re.sub(rf"\b{re.escape(en)}\b", pers, fa, flags=re.I)
        return fa

    def colloquialize(self, fa: str, src: str = "") -> str:
        """اعمال قواعدِ گفتاری روی خروجی فارسی."""
        t = normalize_fa(fa or "")
        if not t:
            return t
        # نیم‌فاصله‌ی افتاده را اول برگردان تا قواعد بعدی درست عمل کنند
        for pat, repl in INSERT_ZWNJ_RULES:
            t = pat.sub(repl, t)
        if self.register == "colloquial":
            for pat, repl in RULES_COLLOQUIAL:
                t = pat.sub(repl, t)
            for pat, repl in STRONG_RULES:
                t = pat.sub(repl, t)
        if self.register in ("colloquial", "neutral"):
            for pat, repl in PHRASE_RULES:
                t = pat.sub(repl, t)
        for pat, repl in SAFE_RULES:
            t = pat.sub(repl, t)
        t = self.apply_names(t)
        t = self._match_punctuation(t, src)
        return t.strip()

    @staticmethod
    def _match_punctuation(fa: str, src: str) -> str:
        """حفظ نشانه‌گذاریِ حساس به لحن (! ? …)."""
        if not src:
            return fa
        s = src.strip()
        if s.endswith("!"):
            fa = fa.rstrip(".") .rstrip()
            if not fa.endswith(("!", "؟", "?")):
                fa += "!"
        elif s.endswith("?"):
            fa = fa.rstrip(".") .rstrip()
            if not fa.endswith(("؟", "?", "!")):
                fa += "؟"
        elif s.endswith("…") or s.endswith("..."):
            fa = fa.rstrip()
            if not fa.endswith(("…", ".")):
                fa += "…"
        if s.isupper() and len(s) > 2 and not fa.endswith("!"):
            fa += "!"
        return fa


def build_colloquializer(register: str = "colloquial", path: str | Path | None = None) -> Colloquializer:
    return Colloquializer.from_file(path, register=register)
