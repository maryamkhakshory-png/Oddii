"""کارگرِ ترجمه در یک پردازه‌ی جدا.

چرا؟ مدلِ NLLB حدود ۱.۳ گیگابایت حافظه می‌گیرد و پایتون بعد از آزادسازی،
این حافظه را به سیستم‌عامل پس نمی‌دهد. با اجرای ترجمه در یک پردازه‌ی موقت،
همه چیز بعد از اتمام کار کاملاً آزاد می‌شود — روی ماشین‌های کم‌رم حیاتی است.

    python -m nlp.translate_worker --in texts.json --out out.json
"""

from __future__ import annotations

import argparse
import os
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    ap.add_argument("--model-dir", required=True)
    ap.add_argument("--tokenizer-dir", default="")
    ap.add_argument("--src-lang", default="eng_Latn")
    ap.add_argument("--tgt-lang", default="pes_Arab")
    ap.add_argument("--beam", type=int, default=4)
    ap.add_argument("--intra-threads", type=int, default=1)
    ap.add_argument("--batch", type=int, default=8,
                    help="اندازه‌ی دسته درونِ این پردازه (اوج حافظه را محدود می‌کند)")
    a = ap.parse_args()

    from nlp.translator import NllbCt2Translator

    # حافظه‌ی هسته‌ی ترجمه را محدود کن (روی ماشین‌های ۲ گیگابایتی حیاتی است)
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MALLOC_ARENA_MAX", "2")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    texts = json.loads(Path(a.inp).read_text(encoding="utf-8"))
    tr = NllbCt2Translator(
        model_dir=a.model_dir,
        tokenizer_dir=a.tokenizer_dir or None,
        src_lang=a.src_lang, tgt_lang=a.tgt_lang, beam_size=a.beam,
        inter_threads=1, intra_threads=max(1, a.intra_threads),
    )
    # مدل یک بار بالا می‌آید و متن‌ها در دسته‌های کوچک ترجمه می‌شوند؛
    # اینطوری هم از بالا آمدنِ دوباره جلوگیری می‌شود هم اوج حافظه ثابت می‌ماند.
    chunk = max(1, int(a.batch))
    out: list = []
    for i in range(0, len(texts), chunk):
        out.extend(tr.translate_batch(texts[i:i + chunk]))
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
