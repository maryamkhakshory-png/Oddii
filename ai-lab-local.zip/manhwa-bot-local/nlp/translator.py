"""موتور ترجمه — چند بَک‌اِندِ قابل تعویض.

    nllb-ct2  ← پیش‌فرض: CTranslate2 + NLLB-200 (int8) روی CPU، آفلاین و رایگان
    marian    ← جایگزین: transformers + torch (برای محیط‌هایی مثل Colab)
    llm       ← صیقلِ خروجی با یک مدل زبانی محلی/رایگان
    identity  ← فقط برای تست (بدون ترجمه)

همه‌ی بَک‌اندها یک قرارداد ساده دارند: translate_batch(list[str]) -> list[str]
"""

from __future__ import annotations

import json
import os
import re
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional, Sequence

# فقط روی نشانه‌های پایان جمله می‌شکنیم؛ خطِ جدید را به فاصله تبدیل می‌کنیم
# چون OCR بالن‌ها را خط‌به‌خط می‌دهد و ترجمه‌ی تکه‌تکه بی‌معنا می‌شود.
_SENT_SPLIT = re.compile(r"(?<=[.!?؟…])[\s\u200c]+")


def flatten(text: str) -> str:
    """یک‌خطی کردن متن (برای ترجمه؛ حروف‌چینی بعداً دوباره می‌شکند)."""
    return " ".join((text or "").split())


def split_sentences(text: str) -> List[str]:
    text = flatten(text)
    if not text:
        return []
    return [p.strip() for p in _SENT_SPLIT.split(text) if p and p.strip()]


class Translator(ABC):
    name = "base"

    @abstractmethod
    def translate_batch(self, texts: Sequence[str]) -> List[str]: ...

    def translate(self, text: str) -> str:
        return self.translate_batch([text])[0] if text else ""

    def warmup(self) -> None:
        pass


# ------------------------------------------------------- نشانه‌سازِ سبکِ NLLB
class NllbTokenizer:
    """نشانه‌سازِ NLLB بدون بار کردنِ `transformers`.

    کتابخانه‌ی `transformers` فقط برای همین کار حدود ۲۶۰ مگابایت حافظه می‌گیرد؛
    `tokenizers` (هسته‌ی راست) همان خروجی را با حدود ۴۰ مگابایت می‌دهد.
    خروجی دقیقاً برابرِ `AutoTokenizer(src_lang=...)` است:
        [کد_زبان] + نشانه‌ها + [</s>]
    """

    def __init__(self, model_dir: str | Path, src_lang: str = "eng_Latn"):
        from tokenizers import Tokenizer

        model_dir = Path(model_dir)
        tj = model_dir / "tokenizer.json"
        if not tj.exists():          # در صورت نبود، از transformers کمک بگیر
            raise FileNotFoundError(str(tj))
        self._tk = Tokenizer.from_file(str(tj))
        self.src_lang = src_lang
        sp = self._tk.get_vocab()
        self.eos_id = sp.get("</s>", 2)
        self.src_lang_id = sp.get(src_lang, None)

    # -- همان قراردادِ کدِ قبلی --
    def tokenize(self, text: str) -> List[str]:
        ids = self._tk.encode(text or "", add_special_tokens=False).ids
        if self.src_lang_id is not None:
            ids = [self.src_lang_id] + ids
        ids = ids + [self.eos_id]
        return [self._tk.id_to_token(i) for i in ids]

    def convert_tokens_to_ids(self, tokens: Sequence[str]) -> List[int]:
        out = []
        for t in tokens:
            i = self._tk.token_to_id(t)
            if i is not None:
                out.append(i)
        return out

    def decode(self, ids: Sequence[int], skip_special_tokens: bool = True) -> str:
        return self._tk.decode(list(ids), skip_special_tokens=skip_special_tokens)


# --------------------------------------------------------------------- NLLB
class NllbCt2Translator(Translator):
    """NLLB-200 با CTranslate2 — سریع روی CPU، حافظه کم (int8)."""

    name = "nllb-ct2"

    def __init__(self, model_dir: str | Path, tokenizer_dir: str | Path | None = None,
                 src_lang: str = "eng_Latn", tgt_lang: str = "pes_Arab",
                 beam_size: int = 4, max_decoding_length: int = 200,
                 inter_threads: int = 1, intra_threads: int = 2, **kw):
        import ctranslate2

        self.model_dir = str(model_dir)
        self.tok_dir = str(tokenizer_dir or model_dir)
        self.src_lang, self.tgt_lang = src_lang, tgt_lang
        self.beam_size, self.max_decoding_length = beam_size, max_decoding_length
        self.tokenizer = self._make_tokenizer(self.tok_dir, src_lang)
        self.model = ctranslate2.Translator(
            self.model_dir, device="cpu", inter_threads=max(1, inter_threads),
            intra_threads=max(1, intra_threads),
        )

    @staticmethod
    def _make_tokenizer(tok_dir: str, src_lang: str):
        """نشانه‌سازِ سبک؛ اگر `tokenizers` در دسترس نبود، سراغ transformers."""
        try:
            return NllbTokenizer(tok_dir, src_lang=src_lang)
        except Exception:
            from transformers import AutoTokenizer

            return AutoTokenizer.from_pretrained(tok_dir, src_lang=src_lang,
                                                 local_files_only=True)

    def warmup(self) -> None:
        try:
            self.translate("Hello!")
        except Exception:
            pass

    def _translate_sentences(self, sents: Sequence[str]) -> List[str]:
        if not sents:
            return []
        encoded = []
        for s in sents:
            if hasattr(self.tokenizer, "tokenize"):      # نشانه‌سازِ سبکِ خودمان
                encoded.append(self.tokenizer.tokenize(s))
            else:                                        # transformers
                ids = self.tokenizer(s, add_special_tokens=True)["input_ids"]
                encoded.append(self.tokenizer.convert_ids_to_tokens(ids))
        try:
            results = self.model.translate_batch(
                encoded, target_prefix=[[self.tgt_lang]] * len(encoded),
                beam_size=self.beam_size, max_decoding_length=self.max_decoding_length,
            )
        except Exception:
            # بعضی نسخه‌ها کد زبان را بدون پیشوند می‌خواهند
            results = self.model.translate_batch(
                encoded, target_prefix=[["▁" + self.tgt_lang]] * len(encoded),
                beam_size=self.beam_size, max_decoding_length=self.max_decoding_length,
            )
        out = []
        for r in results:
            hyp = r.hypotheses[0] if r.hypotheses else []
            if hyp and hyp[0].strip("▁") == self.tgt_lang:
                hyp = hyp[1:]
            ids = self.tokenizer.convert_tokens_to_ids(hyp)
            out.append(self.tokenizer.decode(ids, skip_special_tokens=True).strip())
        return out

    def translate_batch(self, texts: Sequence[str]) -> List[str]:
        flat: List[str] = []
        spans: List[tuple] = []
        for t in texts:
            sents = split_sentences(t or "")
            start = len(flat)
            flat.extend(sents)
            spans.append((start, len(flat), "\n" if "\n" in (t or "") else " "))
        if not flat:
            return [""] * len(texts)
        translated = self._translate_sentences(flat)
        res = []
        for (a, b, joiner) in spans:
            parts = translated[a:b]
            # مدل گاهی نقطه‌ی آخرِ جمله‌ی میانی را می‌اندازد — برش گردان
            for k in range(len(parts) - 1):
                p = parts[k].rstrip()
                if p and p[-1] not in ".!؟?…،,":
                    parts[k] = p + "."
            res.append(joiner.join(parts).strip())
        return res


# ------------------------------------------------------------------- Marian
class MarianTranslator(Translator):
    """ترجمه با transformers + torch (مثل Helsinki-NLP/opus-mt-en-fa)."""

    name = "marian"

    def __init__(self, model_name: str = "Helsinki-NLP/opus-mt-tc-big-en-fa", **kw):
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
        self.model.eval()

    def translate_batch(self, texts: Sequence[str]) -> List[str]:
        out = []
        for t in texts:
            sents = split_sentences(t) or [t]
            parts = []
            for s in sents:
                batch = self.tokenizer([s], return_tensors="pt", truncation=True)
                gen = self.model.generate(**batch, max_new_tokens=180, num_beams=4)
                parts.append(self.tokenizer.decode(gen[0], skip_special_tokens=True))
            out.append(" ".join(parts).strip())
        return out


# ----------------------------------------------------------------- Identity
class IdentityTranslator(Translator):
    """بدون ترجمه — فقط برای تست کردن خط لوله روی CPU ضعیف."""

    name = "identity"

    def translate_batch(self, texts: Sequence[str]) -> List[str]:
        return [t or "" for t in texts]


# ------------------------------------------------------- ترجمه در پردازه‌ی جدا
class SubprocessNllbTranslator(Translator):
    """همان NLLB، ولی در یک پردازه‌ی موقت — حافظه بعد از کار کاملاً آزاد می‌شود."""

    name = "nllb-ct2(worker)"

    def __init__(self, model_dir: str | Path, tokenizer_dir: str | Path | None = None,
                 src_lang: str = "eng_Latn", tgt_lang: str = "pes_Arab",
                 beam_size: int = 4, root: str | Path | None = None,
                 timeout: int = 3600, batch_size: int = 8):
        import subprocess

        self._subprocess = subprocess
        self.model_dir = str(model_dir)
        self.tokenizer_dir = str(tokenizer_dir or model_dir)
        self.src_lang, self.tgt_lang = src_lang, tgt_lang
        self.beam_size = beam_size
        self.batch_size = max(1, int(batch_size))
        self.root = str(root or Path(__file__).resolve().parents[1])
        self.timeout = timeout
        self.tmp_dir = Path(self.root) / "data" / "tmp"
        self.tmp_dir.mkdir(parents=True, exist_ok=True)

    def translate_batch(self, texts: Sequence[str]) -> List[str]:
        import json
        import time

        if not texts:
            return []
        tag = f"{int(time.time()*1000)}"
        inp = self.tmp_dir / f"in_{tag}.json"
        out = self.tmp_dir / f"out_{tag}.json"
        inp.write_text(json.dumps(list(texts), ensure_ascii=False), encoding="utf-8")
        cmd = [
            sys.executable, "-m", "nlp.translate_worker",
            "--in", str(inp), "--out", str(out),
            "--model-dir", self.model_dir, "--tokenizer-dir", self.tokenizer_dir,
            "--src-lang", self.src_lang, "--tgt-lang", self.tgt_lang,
            "--beam", str(self.beam_size), "--batch", str(self.batch_size),
        ]
        env = dict(os.environ)
        env["PYTHONPATH"] = self.root + os.pathsep + env.get("PYTHONPATH", "")
        try:
            res = self._subprocess.run(cmd, cwd=self.root, env=env,
                                       capture_output=True, timeout=self.timeout)
            if out.exists():
                data = json.loads(out.read_text(encoding="utf-8"))
                if len(data) == len(texts):
                    return data
            tail = (res.stderr or b"").decode("utf-8", "ignore")[-400:]
            rc = res.returncode
            hint = " (احتمالاً کمبود حافظه)" if rc == -9 or rc == 137 else ""
            raise RuntimeError(f"خروجی نامعتبر از کارگر ترجمه (کد {rc}){hint}\n{tail}")
        finally:
            for f in (inp, out):
                try:
                    f.unlink()
                except Exception:
                    pass


# -------------------------------------------------------------------- Cache
class CachedTranslator(Translator):
    """لایه‌ی کش روی هر موتور ترجمه (جلوگیری از ترجمه‌ی تکراری)."""

    def __init__(self, inner: Translator, cache_path: str | Path | None = None):
        self.inner = inner
        self.cache_path = Path(cache_path) if cache_path else None
        self.cache: Dict[str, str] = {}
        self._load()

    @property
    def name(self) -> str:  # type: ignore[override]
        return self.inner.name

    def _load(self) -> None:
        if self.cache_path and self.cache_path.exists():
            try:
                self.cache = json.loads(self.cache_path.read_text(encoding="utf-8"))
            except Exception:
                self.cache = {}

    def save(self) -> None:
        if self.cache_path:
            try:
                self.cache_path.parent.mkdir(parents=True, exist_ok=True)
                self.cache_path.write_text(
                    json.dumps(self.cache, ensure_ascii=False, indent=0), encoding="utf-8")
            except Exception:
                pass

    def translate_batch(self, texts: Sequence[str]) -> List[str]:
        todo, idx = [], []
        out: List[Optional[str]] = []
        key_prefix = f"{self.inner.name}|"
        for i, t in enumerate(texts):
            k = key_prefix + (t or "")
            if (t or "") == "":
                out.append("")
            elif k in self.cache:
                out.append(self.cache[k])
            else:
                out.append(None)
                todo.append(t)
                idx.append(i)
        if todo:
            res = self.inner.translate_batch(todo)
            for j, i in enumerate(idx):
                out[i] = res[j]
                self.cache[key_prefix + (todo[j] or "")] = res[j]
        if len(self.cache) % 25 == 0:
            self.save()
        return [o if o is not None else "" for o in out]


# ------------------------------------------------------------------- Factory
def build_translator(cfg, log=None, low_memory: bool = False) -> Translator:
    engine = str(getattr(cfg, "engine", "nllb-ct2")).lower()
    tr: Optional[Translator] = None
    if engine in ("nllb-ct2", "nllb", "ct2"):
        if low_memory:
            # روی ماشین کم‌رم: مدل در پردازه‌ای جدا بار و بعد کاملاً آزاد می‌شود
            try:
                tr = SubprocessNllbTranslator(
                    model_dir=cfg.model_dir, tokenizer_dir=cfg.tokenizer_dir,
                    src_lang=cfg.src_lang, tgt_lang=cfg.tgt_lang,
                    beam_size=cfg.beam_size,
                    batch_size=int(getattr(cfg, "batch_size", 8) or 8))
            except Exception as e:
                if log:
                    log.warning(f"ترجمه در پردازه‌ی جدا نشد ({e})")
        if tr is None:
            try:
                tr = NllbCt2Translator(
                    model_dir=cfg.model_dir, tokenizer_dir=cfg.tokenizer_dir,
                    src_lang=cfg.src_lang, tgt_lang=cfg.tgt_lang, beam_size=cfg.beam_size,
                    max_decoding_length=cfg.max_decoding_length,
                    inter_threads=cfg.inter_threads, intra_threads=cfg.intra_threads,
                )
            except Exception as e:
                if log:
                    log.warning(f"CT2/NLLB بالا نیامد ({e}) — سراغ گزینه‌ی بعدی")
    if tr is None and engine in ("nllb-ct2", "nllb", "ct2", "marian"):
        try:
            tr = MarianTranslator()
        except Exception as e:
            if log:
                log.warning(f"Marian هم در دسترس نیست ({e})")
    if tr is None:
        tr = IdentityTranslator()
        if log:
            log.warning("هیچ موتور ترجمه‌ای نبود — از حالت identity استفاده می‌شود")
    if getattr(cfg, "cache", True):
        tr = CachedTranslator(tr, Path(cfg.__dict__.get("_cache_path", "data/cache/translations.json")))
    return tr
