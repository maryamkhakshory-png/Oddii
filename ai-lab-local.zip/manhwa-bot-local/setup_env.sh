#!/usr/bin/env bash
# Idempotent bootstrap for a fresh/reset workspace: Python deps + free local models.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
mkdir -p logs
exec > >(tee -a "$ROOT/logs/setup.log") 2>&1

PYTHON_BIN="${PYTHON_BIN:-python3}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: $PYTHON_BIN is not installed." >&2
  exit 1
fi

if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  echo "### Creating project virtual environment"
  "$PYTHON_BIN" -m venv "$ROOT/.venv"
fi
V="$ROOT/.venv/bin"

export PIP_DISABLE_PIP_VERSION_CHECK=1
export PIP_NO_INPUT=1
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export HF_HUB_DISABLE_TELEMETRY=1

echo "### Upgrading pip/build tools"
"$V/python" -m pip install --upgrade pip setuptools wheel

echo "### Installing project requirements"
"$V/python" -m pip install -r "$ROOT/requirements.txt"
echo "### Installing the official prebuilt llama.cpp CPU wheel (no C++ compilation)"
"$V/python" -m pip install --only-binary=llama-cpp-python \
  --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu \
  "llama-cpp-python>=0.3.16,<1.0"

echo "### Verifying imports"
"$V/python" - <<'PY'
import av, arabic_reshaper, ctranslate2, cv2, fastapi, faster_whisper
import llama_cpp, numpy, PIL, piper, requests, rapidocr_onnxruntime
import sentencepiece, transformers, yaml
print("All required Python imports are ready.")
print("llama_cpp:", getattr(llama_cpp, "__version__", "installed"))
PY

echo "### Downloading free, open local assets (NLLB + Qwen GGUF + font + Piper voice)"
"$V/python" "$ROOT/scripts/download_assets.py"

echo "### Setup complete"
echo "Run the bot with: bash scripts/run_bot.sh"
