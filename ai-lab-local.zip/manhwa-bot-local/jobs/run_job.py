"""اجراکننده‌ی فازبندی‌شده‌ی کارها (هر فاز در یک پردازه‌ی جدا).

چرا این شکل؟ روی یک دستگاه ۲ گیگابایتی، نگه‌داشتنِ همزمانِ
    OCR (≈۲۵۰MB) + مدل ترجمه (≈۱.۱GB) + بافرهای تصویر
ممکن نیست و کرنل پردازه را می‌کشد. با جدا کردنِ فازها، اوجِ مصرف برابرِ
سنگین‌ترین فاز است نه مجموعِ آن‌ها:

    ocr        ← فقط OCR؛ ناحیه‌ها را در regions.json می‌نویسد
    translate  ← فقط مدل ترجمه؛ همان فایل را بروز می‌کند
    render     ← فقط پاک‌سازی و حروف‌چینی؛ تصویر/زیپ خروجی را می‌سازد

    python -m jobs.run_job ocr       --job data/work/job1
    python -m jobs.run_job translate --job data/work/job1
    python -m jobs.run_job render    --job data/work/job1
"""

from __future__ import annotations

import argparse
import gc
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# هسته‌های سنگین را کوچک نگه دار
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MALLOC_ARENA_MAX", "2")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


def _log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def _cfg():
    from core.config import load_config

    cfg_path = os.environ.get("MANHWA_CONFIG") or str(ROOT / "config.yaml")
    return load_config(cfg_path)


def _job(job_dir: Path) -> dict:
    return json.loads((job_dir / "job.json").read_text(encoding="utf-8"))


def _save(job_dir: Path, data: dict) -> None:
    tmp = job_dir / "job.json.tmp"
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(job_dir / "job.json")


def _pages(job_dir: Path, job: dict):
    from core.utils import list_images

    src = Path(job["src"])
    if src.is_dir():
        return list_images(src)
    return [src]


# ------------------------------------------------------------------- فاز ۱
def phase_ocr(job_dir: Path) -> dict:
    from core.utils import extract_archive, imread
    from vision.pipeline import ManhwaPipeline

    job = _job(job_dir)
    cfg = _cfg()
    pipe = ManhwaPipeline(cfg, log=None, with_ocr=True, with_translator=False)

    src = Path(job["src"])
    pages = _pages(job_dir, job)
    if src.is_file() and src.suffix.lower() in (".zip", ".cbz"):
        work = job_dir / "in"
        work.mkdir(exist_ok=True)
        pages = list_images(extract_archive(src, work))[: int(job.get("max_pages", 60))]

    per_page = []
    for i, p in enumerate(pages, 1):
        _log(f"خواندن {p.name} ({i}/{len(pages)})")
        try:
            img = imread(p)
            regions = pipe._find_regions(img)
        except Exception as e:
            _log(f"خطا در {p.name}: {type(e).__name__}: {e}")
            regions = []
        per_page.append({"page": str(p), "regions": ManhwaPipeline.regions_to_json(regions)})
        del img
        gc.collect()

    (job_dir / "regions.json").write_text(
        json.dumps(per_page, ensure_ascii=False), encoding="utf-8")
    job["ocr_engine"] = pipe.ocr_name
    job["pages"] = len(per_page)
    job["region_count"] = sum(len(x["regions"]) for x in per_page)
    _save(job_dir, job)
    _log(f"OCR تمام شد: {job['pages']} صفحه، {job['region_count']} ناحیه")
    return job


# ------------------------------------------------------------------- فاز ۲
def phase_translate(job_dir: Path, batch_size: int = 8) -> dict:
    from nlp.colloquial import build_colloquializer
    from nlp.translator import build_translator
    from vision.pipeline import ManhwaPipeline

    job = _job(job_dir)
    cfg = _cfg()
    per_page = json.loads((job_dir / "regions.json").read_text(encoding="utf-8"))
    regions = ManhwaPipeline.regions_from_json(
        [r for pg in per_page for r in pg["regions"]])
    _log(f"ترجمه‌ی {len(regions)} ناحیه")

    if regions:
        from nlp.filters import looks_translatable

        colloq = build_colloquializer(getattr(cfg.translation, "register", "colloquial"))
        tr = build_translator(cfg.translation, None, low_memory=True)
        _log(f"موتور ترجمه: {tr.name}")

        flat = [r.source.replace("\n", " ").strip() for r in regions]
        allowed = [i for i, r in enumerate(regions) if looks_translatable(r.source)]
        allowed_set = set(allowed)
        for i, r in enumerate(regions):
            if i not in allowed_set:
                r.translated, r.kind = "", "skip"
        done = {}
        for i in allowed:
            hit = colloq.lookup_direct(flat[i])
            if hit:
                done[i] = hit
        todo = [i for i in allowed if i not in done]

        # کلِ دسته یک‌جا به کارگر می‌رود؛ کارگر خودش آن را تکه‌تکه می‌کند
        # تا مدل فقط یک بار بالا بیاید و اوجِ حافظه ثابت بماند.
        if todo:
            _log(f"ترجمه‌ی {len(todo)} ناحیه با مدل...")
            outs = tr.translate_batch([colloq.preprocess_en(flat[i]) for i in todo])
            for i, o in zip(todo, outs):
                done[i] = o

        for i, r in enumerate(regions):
            r.translated = colloq.colloquialize(done.get(i, ""), src=flat[i])

        (job_dir / "regions.json").write_text(
            json.dumps(_rebuild(per_page, regions), ensure_ascii=False), encoding="utf-8")
        job["translator"] = tr.name
        _save(job_dir, job)
    _log("ترجمه تمام شد")
    return job


def _rebuild(per_page, regions):
    """ناحیه‌های ترجمه‌شده را به همان ساختارِ صفحه‌به‌صفحه برمی‌گرداند."""
    from vision.pipeline import ManhwaPipeline

    flat = ManhwaPipeline.regions_to_json(regions)
    out, k = [], 0
    for pg in per_page:
        n = len(pg["regions"])
        out.append({"page": pg["page"], "regions": flat[k:k + n]})
        k += n
    return out


# ------------------------------------------------------------------- فاز ۳
def phase_render(job_dir: Path) -> dict:
    import gc as _gc
    from core.utils import imread, imwrite, make_zip
    from vision.pipeline import ManhwaPipeline

    job = _job(job_dir)
    cfg = _cfg()
    # فونت به‌صورت چت‌به‌چت انتخاب می‌شود و فقط روی فازِ رندر اثر دارد.
    custom_font = Path(job.get("font_path", ""))
    if custom_font.is_file():
        cfg.render.font_path = str(custom_font.resolve())
    pipe = ManhwaPipeline(cfg, log=None, with_ocr=False, with_translator=False)
    per_page = json.loads((job_dir / "regions.json").read_text(encoding="utf-8"))

    out_dir = job_dir / "out"
    out_dir.mkdir(exist_ok=True)
    files, n_regions = [], 0

    for i, pg in enumerate(per_page, 1):
        p = Path(pg["page"])
        regions = ManhwaPipeline.regions_from_json(pg["regions"])
        n_regions += len(regions)
        _log(f"نوشتن {p.name} ({i}/{len(per_page)})")
        try:
            img = pipe.render_regions(imread(p), regions)
            out = out_dir / (p.stem + "_fa" + (p.suffix.lower() or ".jpg"))
            imwrite(out, img, quality=92)
            files.append(out)
        except Exception as e:
            _log(f"خطا در {p.name}: {type(e).__name__}: {e}")
        del img
        _gc.collect()

    result = {
        "ok": bool(files),
        "pages": len(files),
        "regions": n_regions,
        "files": [str(f) for f in files],
    }
    if job.get("kind") == "archive" or len(files) > 1:
        zp = job_dir / (Path(job["src"]).stem + "_fa.zip")
        make_zip(files, zp)
        result["zip"] = str(zp)
    (job_dir / "result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    job["result"] = result
    _save(job_dir, job)
    _log(f"حروف‌چینی تمام شد: {result['pages']} خروجی، {result['regions']} ناحیه")
    return job


PHASES = {"ocr": phase_ocr, "translate": phase_translate, "render": phase_render}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("phase", choices=sorted(PHASES))
    ap.add_argument("--job", required=True)
    ap.add_argument("--batch", type=int, default=8)
    a = ap.parse_args()
    job_dir = Path(a.job)
    try:
        if a.phase == "translate":
            PHASES[a.phase](job_dir, a.batch)
        else:
            PHASES[a.phase](job_dir)
        return 0
    except Exception as e:
        _log(f"شکست در فاز {a.phase}: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        try:
            job = _job(job_dir)
            job["error"] = f"{type(e).__name__}: {e}"
            _save(job_dir, job)
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
