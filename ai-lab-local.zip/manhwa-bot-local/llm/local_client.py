"""کلاینتِ محلیِ چت با llama.cpp؛ نه API، نه کلید، نه ارسال متن به سرویس بیرونی.

مدلِ GGUF فقط در یک پردازه‌ی فرزند هنگام پاسخ‌گویی بار می‌شود و سپس آزاد می‌شود؛
بنابراین کنار پردازه‌ی ترجمه‌ی NLLB در RAM نمی‌ماند.
"""

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class LocalLLM:
    model_path: str = str(ROOT / "models/llm/Qwen3.5-0.8B-Q4_K_M.gguf")
    model: str = "Qwen3.5-0.8B-Q4_K_M (محلی)"
    n_ctx: int = 2048
    n_threads: int = 1
    temperature: float = 0.65
    max_tokens: int = 320
    timeout: int = 240

    @classmethod
    def from_config(cls, cfg) -> "LocalLLM":
        model_path = Path(getattr(
            cfg, "model_path", "models/llm/Qwen3.5-0.8B-Q4_K_M.gguf"))
        if not model_path.is_absolute():
            model_path = ROOT / model_path
        return cls(
            model_path=str(model_path),
            model=f"{getattr(cfg, 'model', 'Qwen3.5 local')} (محلی)",
            n_ctx=int(getattr(cfg, "n_ctx", 2048)),
            n_threads=max(1, int(getattr(cfg, "n_threads", 1))),
            temperature=float(getattr(cfg, "temperature", 0.65)),
            max_tokens=int(getattr(cfg, "max_tokens", 320)),
            timeout=int(getattr(cfg, "timeout", 240)),
        )

    def available(self) -> bool:
        return Path(self.model_path).is_file() and importlib.util.find_spec("llama_cpp") is not None

    def chat(self, messages: Sequence[Dict[str, str]], max_tokens: Optional[int] = None,
             temperature: Optional[float] = None, **_kwargs) -> str:
        if not self.available():
            return ""
        payload: Dict[str, Any] = {
            "messages": list(messages),
            "max_tokens": int(max_tokens or self.max_tokens),
            "temperature": float(temperature if temperature is not None else self.temperature),
        }
        cmd = [
            sys.executable, "-m", "llm.local_worker",
            "--model", self.model_path,
            "--n-ctx", str(self.n_ctx),
            "--n-threads", str(self.n_threads),
        ]
        env = dict(os.environ)
        env.update({"OMP_NUM_THREADS": str(self.n_threads),
                    "TOKENIZERS_PARALLELISM": "false",
                    "PYTHONPATH": str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")})
        try:
            proc = subprocess.run(
                cmd, cwd=str(ROOT), env=env,
                input=json.dumps(payload, ensure_ascii=False),
                capture_output=True, text=True, timeout=self.timeout,
            )
        except subprocess.TimeoutExpired:
            return ""
        if proc.returncode != 0:
            return ""
        try:
            result = json.loads(proc.stdout.strip().splitlines()[-1])
            return str(result.get("text") or "").strip()
        except Exception:
            return ""

    def complete(self, prompt: str, system: str = "", **kwargs) -> str:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        return self.chat(messages, **kwargs)
