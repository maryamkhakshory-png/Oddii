"""مهارت‌های مدل زبانی: کدنویسی، صیقل ترجمه، گفتگو.

نکته‌ی مهم طراحی: هر مهارت باید «خراب‌نشدنی» باشد — اگر مدل زبانی در دسترس
نبود یا جواب بد داد، خروجیِ جایگزینِ معقول برمی‌گردد و خط لوله نمی‌شکند.
"""

from __future__ import annotations

import ast
import re
from typing import Dict, List, Sequence, Tuple

from .client import LLMClient

CODE_FENCE = re.compile(r"```(?:[a-zA-Z0-9_+-]*)\n(.*?)```", re.DOTALL)

SYSTEM_CODER = (
    "You are a senior software engineer. Answer with ONE fenced code block only. "
    "No explanation, no prose, no markdown outside the block. "
    "The code must be complete, runnable, dependency-light and Python 3.10+ compatible "
    "unless the user asks for another language. Add short Persian comments when helpful."
)

SYSTEM_POLISHER = (
    "You are a Persian subtitle editor for comics/manhwa. "
    "Rewrite the given Persian draft so it sounds natural, spoken and colloquial (عامیانه), "
    "keeping the meaning, the tone and the length. Keep it short enough to fit a speech balloon. "
    "Reply with the rewritten Persian line only, nothing else."
)

SYSTEM_CHAT = (
    "تو یک دستیار صمیمی، دقیق و کمک‌کننده‌ای. اگر کاربر فارسی می‌نویسد، با فارسیِ "
    "محاوره‌ای، روان و درست جواب بده؛ رسمی و کتابی ننویس. کوتاه و مستقیم باش و "
    "اطلاعاتی را که نمی‌دانی، با اطمینان جعل نکن. اگر کاربر به زبان دیگری نوشت، "
    "به همان زبان پاسخ بده."
)


def extract_code(text: str) -> str:
    m = CODE_FENCE.search(text or "")
    if m:
        return m.group(1).strip()
    t = (text or "").strip()
    return t


def check_python(code: str) -> Tuple[bool, str]:
    """بررسی نحوی کد پایتون بدون اجرای آن."""
    try:
        ast.parse(code or "")
        return True, ""
    except SyntaxError as e:
        return False, f"خط {e.lineno}: {e.msg}"


# ------------------------------------------------------------------ کدنویسی
def write_code(client: LLMClient, task: str, language: str = "python") -> Dict[str, str]:
    """نوشتن کد بر اساس یک درخواست."""
    if not client or not client.available():
        return {"ok": False, "code": "", "error": "مدل زبانیِ محلی در دسترس نیست", "notes": ""}
    system = SYSTEM_CODER
    if language and language.lower() != "python":
        system = system.replace("Python 3.10+ compatible", f"{language} compatible")
    raw = client.complete(
        f"زبان: {language}\nدرخواست:\n{task}\n\n"
        f"فقط یک بلاک کد بده که این کار را کامل انجام بدهد.",
        system=system,
        max_tokens=max(512, client.max_tokens * 2),
        temperature=0.2,
    )
    code = extract_code(raw)
    if not code:
        return {"ok": False, "code": "", "error": "مدل پاسخی نداد", "notes": raw[:400]}
    notes = ""
    if language.lower() in ("python", "py", ""):
        ok, err = check_python(code)
        notes = "سینتکس پایتون بررسی شد: سالم ✅" if ok else f"⚠️ {err}"
    else:
        notes = "برای زبان‌های غیرپایتون بررسی نحو انجام نشد"
    return {"ok": True, "code": code, "error": "", "notes": notes}


# ------------------------------------------------------- صیقلِ ترجمه
def polish_batch(client: LLMClient, sources: Sequence[str], drafts: Sequence[str],
                 register: str = "colloquial") -> List[str]:
    """صیقل یک دسته ترجمه با مدل زبانی؛ در صورت خطا همان پیش‌نویس برمی‌گردد."""
    out = list(drafts)
    if not client or not client.available() or not sources:
        return out
    for i, (src, draft) in enumerate(zip(sources, drafts)):
        if not draft:
            continue
        prompt = (
            f"English: {src}\nPersian draft: {draft}\n"
            f"Register: {register}\nRewritten Persian:"
        )
        res = client.complete(prompt, system=SYSTEM_POLISHER,
                              max_tokens=200, temperature=0.3).strip().strip('"')
        res = re.sub(r"^(?:فارسی|بازنویسی|پاسخ)\s*[:：]\s*", "", res)
        if res and len(res) < 400:
            out[i] = res
    return out


# ------------------------------------------------------------------ گفتگو
def chat(client: LLMClient, message: str, history: Sequence[Dict[str, str]] | None = None) -> str:
    msgs: List[Dict[str, str]] = [{"role": "system", "content": SYSTEM_CHAT}]
    for h in (history or [])[-8:]:
        if h.get("role") in ("user", "assistant") and h.get("content"):
            msgs.append({"role": h["role"], "content": h["content"]})
    msgs.append({"role": "user", "content": message})
    return client.chat(msgs, temperature=0.6)
