"""کارگرِ موقتِ llama.cpp؛ مدل بعد از هر جواب با خروجِ پردازه از RAM آزاد می‌شود."""

from __future__ import annotations

import argparse
import json
import re
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--n-ctx", type=int, default=2048)
    parser.add_argument("--n-threads", type=int, default=1)
    args = parser.parse_args()
    payload = json.load(sys.stdin)

    from llama_cpp import Llama

    llm = Llama(
        model_path=args.model,
        n_ctx=args.n_ctx,
        n_threads=args.n_threads,
        n_batch=128,
        use_mmap=True,
        use_mlock=False,
        verbose=False,
    )
    response = llm.create_chat_completion(
        messages=payload.get("messages", []),
        temperature=float(payload.get("temperature", 0.65)),
        max_tokens=int(payload.get("max_tokens", 320)),
        top_p=0.9,
        repeat_penalty=1.08,
    )
    text = (((response.get("choices") or [{}])[0].get("message") or {}).get("content") or "")
    # Some model templates return empty/visible reasoning tags; never send those to Telegram.
    text = re.sub(r"<think>.*?</think>", "", str(text), flags=re.DOTALL)
    text = re.sub(r"^\s*assistant\s*", "", text).strip()
    print(json.dumps({"text": text}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        # جزئیات فقط به stderr؛ خروجی stdout رزروِ JSON است.
        print(f"local_worker error: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)
