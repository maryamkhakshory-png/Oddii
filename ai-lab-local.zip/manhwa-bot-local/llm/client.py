"""کلاینتِ سازگار با مهارت‌های چت.

پیش‌فرضِ پروژه llama.cpp محلی است (بدون API key). این کلاسِ OpenAI-compatible
برای سازگاریِ ابزارهای قدیمی نگه داشته شده؛ Telegram/CLI از backend محلی استفاده می‌کنند.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

import requests

PRESETS = {
    "ollama": ("http://localhost:11434/v1", "ollama"),
    "lmstudio": ("http://localhost:1234/v1", "lm-studio"),
    "localai": ("http://localhost:8080/v1", "local-ai"),
    "openrouter": ("https://openrouter.ai/api/v1", ""),
    "custom": ("", ""),
}


@dataclass
class LLMClient:
    backend: str = "ollama"
    base_url: str = ""
    api_key: str = ""
    model: str = "Qwen3.5-0.8B-Q4_K_M"
    temperature: float = 0.4
    max_tokens: int = 512
    timeout: int = 90
    enabled: bool = False
    _ok: Optional[bool] = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        preset_url, preset_key = PRESETS.get(str(self.backend).lower(), ("", ""))
        if not self.base_url:
            self.base_url = preset_url
        if not self.api_key:
            self.api_key = preset_key

    @classmethod
    def from_config(cls, cfg) -> "LLMClient":
        backend = str(getattr(cfg, "backend", "")).lower()
        if backend in {"local", "local-llama.cpp", "llama.cpp"}:
            # Keep existing pipeline/CLI consumers on the same keyless local backend.
            from llm.local_client import LocalLLM
            return LocalLLM.from_config(cfg)
        return cls(
            backend=getattr(cfg, "backend", "ollama"),
            base_url=getattr(cfg, "base_url", ""),
            api_key=getattr(cfg, "api_key", ""),
            model=getattr(cfg, "model", "Qwen3.5-0.8B-Q4_K_M"),
            temperature=getattr(cfg, "temperature", 0.4),
            max_tokens=getattr(cfg, "max_tokens", 512),
            timeout=getattr(cfg, "timeout", 90),
            enabled=bool(getattr(cfg, "enabled", False)),
        )

    # ------------------------------------------------------------- وضعیت
    @property
    def url(self) -> str:
        return f"{self.base_url.rstrip('/')}/chat/completions"

    def available(self) -> bool:
        if not self.enabled or not self.base_url:
            return False
        if self._ok is not None:
            return self._ok
        try:
            r = requests.get(f"{self.base_url.rstrip('/')}/models",
                             headers=self._headers(), timeout=8)
            self._ok = 200 <= r.status_code < 300
        except Exception:
            self._ok = False
        return bool(self._ok)

    def _headers(self) -> Dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    # ------------------------------------------------------------- فراخوانی
    def chat(self, messages: Sequence[Dict[str, str]], max_tokens: Optional[int] = None,
             temperature: Optional[float] = None, json_mode: bool = False) -> str:
        """ارسال گفتگو و گرفتن پاسخ. در صورت خطا رشته‌ی خالی برمی‌گردد."""
        if not self.available():
            return ""
        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": list(messages),
            "temperature": float(temperature if temperature is not None else self.temperature),
            "max_tokens": int(max_tokens or self.max_tokens),
            "stream": False,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        try:
            r = requests.post(self.url, headers=self._headers(), json=payload, timeout=self.timeout)
            if r.status_code >= 400:
                return ""
            data = r.json()
            return (((data.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
        except Exception:
            return ""

    def complete(self, prompt: str, system: str = "", **kw) -> str:
        msgs: List[Dict[str, str]] = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        return self.chat(msgs, **kw)
