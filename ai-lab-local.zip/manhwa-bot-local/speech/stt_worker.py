"""پردازه‌ی جدا برای تبدیل پیام صوتی به متن فارسی با Whisper محلی.

مدل فقط موقع دریافت voice بار می‌شود و با پایان پردازه آزاد می‌شود؛
این کمک می‌کند حافظه‌ی مدلِ گفتار کنار NLLB انباشته نشود.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("audio", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--model", default="base")
    parser.add_argument("--language", default="fa")
    args = parser.parse_args()

    from faster_whisper import WhisperModel

    model = WhisperModel(args.model, device="cpu", compute_type="int8",
                         cpu_threads=1, num_workers=1)
    segments, info = model.transcribe(
        str(args.audio), language=args.language, task="transcribe",
        beam_size=1, best_of=1, vad_filter=True,
        condition_on_previous_text=False,
    )
    text = " ".join(s.text.strip() for s in segments if s.text.strip()).strip()
    payload = {"text": text, "language": getattr(info, "language", args.language)}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    tmp = args.out.with_suffix(args.out.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    tmp.replace(args.out)
    print("تبدیل صدا تمام شد", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
