"""تبدیل متن به گفتار — دو مسیرِ کاملاً رایگان.

    piper  ← آفلاین و متن‌باز (پیش‌فرض؛ مدل ۶۰ مگابایتی، کیفیت خوب)
    edge   ← صدای طبیعی‌ترِ Microsoft Edge (نیاز به اینترنت؛ بعضی IPها را بلاک می‌کند)

هیچ‌کدام کلیدِ پولی نمی‌خواهند.
"""

from __future__ import annotations

import asyncio
import wave
from pathlib import Path
from typing import List, Optional

ROOT = Path(__file__).resolve().parents[1]

PIPER_DIR = ROOT / "models" / "piper"
DEFAULT_PIPER_VOICE = "fa_IR-amir-medium"

EDGE_VOICES_FA = {
    "dilara": "fa-IR-DilaraNeural",   # زن
    "farid": "fa-IR-FaridNeural",     # مرد
}


def _piper_paths(voice: str):
    return PIPER_DIR / f"{voice}.onnx", PIPER_DIR / f"{voice}.onnx.json"


def piper_available(voice: str = DEFAULT_PIPER_VOICE) -> bool:
    onnx, cfg = _piper_paths(voice)
    return onnx.exists() and cfg.exists()


# ------------------------------------------------------------------ Piper
def _piper_sync(text: str, out_path: str, voice: str) -> Optional[str]:
    from piper import PiperVoice

    onnx, cfgp = _piper_paths(voice)
    if not onnx.exists():
        return None
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    model = PiperVoice.load(str(onnx), config_path=str(cfgp) if cfgp.exists() else None)
    with wave.open(out_path, "wb") as f:
        model.synthesize_wav(text, f)   # خودش نرخ نمونه‌برداری و قالب را تنظیم می‌کند
    return out_path


# ------------------------------------------------------------------- Edge
async def _edge_async(text: str, out_path: str, voice: str, rate: str, volume: str) -> str:
    import edge_tts

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    comm = edge_tts.Communicate(text, voice, rate=rate, volume=volume)
    await comm.save(out_path)
    return out_path


def _edge_sync(text: str, out_path: str, voice: str, rate: str, volume: str) -> Optional[str]:
    try:
        return asyncio.run(_edge_async(text, out_path, voice, rate, volume))
    except RuntimeError:  # event loop از قبل فعال است
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(_edge_async(text, out_path, voice, rate, volume))
        finally:
            loop.close()


def telegram_voice_file(path: str | Path) -> Optional[str]:
    """تبدیل WAV پِیپر به OGG/Opus تا تلگرام آن را مثل voice note پخش کند.

    فایلِ MP3/M4A/OGG از سرویس‌های دیگر همان‌طور که هست برگردانده می‌شود.
    PyAV (وابستگیِ faster-whisper) کدکِ libopus را دارد و نیازی به ffmpeg بیرونی نیست.
    """
    path = Path(path)
    if path.suffix.lower() != ".wav":
        return str(path)
    out_path = path.with_suffix(".ogg")
    try:
        import av

        source = av.open(str(path))
        target = av.open(str(out_path), mode="w", format="ogg")
        stream = target.add_stream("libopus", rate=48000)
        stream.layout = "mono"
        resampler = av.AudioResampler(format="fltp", layout="mono", rate=48000)
        for frame in source.decode(audio=0):
            for converted in resampler.resample(frame):
                for packet in stream.encode(converted):
                    target.mux(packet)
        for converted in resampler.resample(None):
            for packet in stream.encode(converted):
                target.mux(packet)
        for packet in stream.encode(None):
            target.mux(packet)
        target.close()
        source.close()
        if out_path.exists() and out_path.stat().st_size > 100:
            return str(out_path)
    except Exception:
        try:
            out_path.unlink(missing_ok=True)
        except Exception:
            pass
    return None


# ------------------------------------------------------------------- عمومی
def speak(text: str, out_path: str, voice: str = DEFAULT_PIPER_VOICE,
          engine: str = "auto", rate: str = "+0%", volume: str = "+0%") -> Optional[str]:
    """تبدیل متن به گفتار.

    engine:
        auto   → اول Piper (اگر مدل باشد)، بعد edge
        piper  → فقط آفلاین
        edge   → فقط آنلاین (نامِ صدا مثل fa-IR-DilaraNeural)
    """
    text = (text or "").strip()
    if not text:
        return None
    out_path = str(out_path)
    engine = (engine or "auto").lower()

    if engine in ("auto", "piper") and piper_available(voice if engine == "piper" else DEFAULT_PIPER_VOICE):
        v = voice if engine == "piper" else DEFAULT_PIPER_VOICE
        try:
            if _piper_sync(text, out_path, v):
                return out_path
        except Exception:
            if engine == "piper":
                return None

    if engine in ("auto", "edge"):
        ev = voice if voice.startswith("fa-") else EDGE_VOICES_FA.get(voice, "fa-IR-DilaraNeural")
        try:
            return _edge_sync(text, out_path, ev, rate, volume)
        except Exception:
            return None
    return None


async def list_edge_voices(lang: str = "fa") -> List[dict]:
    import edge_tts

    vs = await edge_tts.list_voices()
    return [v for v in vs if str(v.get("Locale", "")).lower().startswith(lang.lower())]
