#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v python3.11 >/dev/null 2>&1; then
  echo "Install Python 3.11 first, then run this file again."
  exit 1
fi
python3.11 scripts/setup_local.py
