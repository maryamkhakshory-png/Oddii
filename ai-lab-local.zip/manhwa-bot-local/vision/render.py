"""حروف‌چینی فارسی داخل بالن: شکستن خط، اندازه‌ی خودکار فونت، راست‌به‌چپ.

وابستگی‌ها: Pillow + arabic-reshaper + python-bidi (همه سبک و آفلاین).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import arabic_reshaper
import numpy as np
from bidi.algorithm import get_display
from PIL import Image, ImageColor, ImageDraw, ImageFont

from .text_style import TextStyle

try:  # ترجیحاً اتصال حروف فارسی با نیم‌فاصله درست انجام شود
    from hazm import Normalizer  # type: ignore

    _NORMALIZER = Normalizer()
except Exception:  # hazm اختیاری است
    _NORMALIZER = None


# ------------------------------------------------------------------ آماده‌سازی متن
_SUFFIX = r"(ها|های|تر|ترین|ام|ات|اش|مان|تان|شان)"


def normalize_fa(text: str) -> str:
    """نرمال‌سازیِ امن و تکرارپذیر: ی/ک عربی، کشیده، نیم‌فاصله، فاصله‌های اضافه.

    این تابع باید «خنثی» باشد: اجرای دوباره‌اش روی خروجی، نتیجه را خراب نکند.
    """
    if not text:
        return ""
    t = text
    t = t.replace("ي", "ی").replace("ى", "ی").replace("ك", "ک").replace("ۀ", "ه‌ی")
    t = t.replace("ؤ", "و").replace("إ", "ا").replace("أ", "ا")
    t = t.replace("ـ", "")  # کشیده
    t = re.sub(r"[ \t\u00a0]+", " ", t)
    t = re.sub(r"\s*\u200c\s*", "\u200c", t)  # فاصله‌ی دورِ نیم‌فاصله را بردار
    t = " ".join(t.split())
    try:
        if _NORMALIZER is not None:
            t = _NORMALIZER.normalize(t)
    except Exception:
        pass
    # پسوندها را با نیم‌فاصله بچسبان: «بچه ها» → «بچه‌ها»
    t = re.sub(r"(?<=\S) " + _SUFFIX + r"\b", "\u200c\\1", t)
    # «می/نمی/بی» جداافتاده را بچسبان
    t = re.sub(r"\b(نمی|می|بی) (?=[\u0600-\u06FF])", "\\1\u200c", t)
    # فاصله‌ی قبل از نشانه‌گذاری
    t = re.sub(r"\s+([.!؟?،,:;])", r"\1", t)
    return t.strip()


def display(text: str) -> str:
    """تبدیل متن فارسیِ منطقی به رشته‌ی آماده‌ی ترسیم (ترتیب دیداری)."""
    if not text:
        return ""
    try:
        # حتی اگر خط با واژه‌ی لاتین (مثل TSK/Louis) شروع شود، بالن فارسی RTL است.
        # تعیینِ خودکارِ جهت، رشته‌ی مختلط را LTR می‌کند و ترتیبِ جمله به‌هم می‌ریزد.
        return get_display(arabic_reshaper.reshape(text), base_dir="R")
    except Exception:
        return text


def load_font(path: str, size: int) -> ImageFont.FreeTypeFont:
    """بارگذاری فونت برای متنِ ازپیش‌آماده‌شده‌ی فارسی.

    `display()` خودش حروف را شکل می‌دهد و ترتیبِ دیداری را می‌سازد؛ اگر Pillow
    دوباره موتورِ RAQM را روی همان رشته اجرا کند، حروف/ترتیب دو بار پردازش
    می‌شوند و فارسی وارونه یا به‌هم‌ریخته درمی‌آید. BASIC عمداً shaping دوباره
    را خاموش می‌کند؛ اندازه‌گیری و رسم هر دو از همین تابع استفاده می‌کنند.
    """
    return ImageFont.truetype(
        str(path), int(size), layout_engine=ImageFont.Layout.BASIC)


# ------------------------------------------------------------------ شکستن خط
def _word_width(draw: ImageDraw.ImageDraw, word: str, font) -> float:
    return draw.textlength(display(word), font=font)


def wrap_logical(draw, text: str, font, max_width: float) -> List[List[str]]:
    """شکستن به خط‌ها با حفظ ترتیب منطقی (برای درست درآمدن راست‌به‌چپ)."""
    lines: List[List[str]] = []
    for raw_line in text.split("\n"):
        words = [w for w in raw_line.split() if w]
        if not words:
            lines.append([])
            continue
        cur: List[str] = []
        cur_w = 0.0
        for w in words:
            ww = _word_width(draw, w, font)
            if cur and cur_w + ww + _word_width(draw, " ", font) > max_width:
                lines.append(cur)
                cur, cur_w = [w], ww
            else:
                cur.append(w)
                cur_w += ww + _word_width(draw, " ", font)
        if cur:
            lines.append(cur)
    return [l for l in lines if l]


@dataclass
class FitResult:
    size: int
    lines: List[str]      # رشته‌های آماده‌ی ترسیم (ترتیب دیداری)
    line_height: int
    block_h: int
    ok: bool


def fit_text(font_path: str, text: str, box_w: int, box_h: int, cfg,
             base_size: float = 0.0,
             stroke_width_ratio: Optional[float] = None) -> FitResult:
    """پیدا کردن اندازه‌ی فونت که متن در جعبه جا بشود.

    اگر base_size داده شود (ارتفاعِ متنِ اصلیِ انگلیسی)، اندازه‌ی شروع بر اساس آن
    است — طبیعی‌تر از این است که اندازه را از ارتفاعِ بالن حساب کنیم.
    """
    canvas = Image.new("RGB", (10, 10))
    draw = ImageDraw.Draw(canvas)

    pad_ratio = float(getattr(cfg, "padding_ratio", 0.14))
    max_w = max(8, int(box_w * (1 - pad_ratio)))
    max_h = max(8, int(box_h * (1 - pad_ratio * 0.9)))
    spacing = float(getattr(cfg, "line_spacing", 0.34))

    lo, hi = int(getattr(cfg, "min_font", 10)), int(getattr(cfg, "max_font", 90))
    if base_size and base_size > 0:
        # اندازه‌ی مبنا برابر/کمی کوچک‌تر از متنِ انگلیسی است؛ بالاتر نمی‌رویم.
        suggested = int(max(1, min(hi, round(base_size))))
    else:
        suggested = int(max(lo, min(hi, box_h * float(getattr(cfg, "font_size_ratio", 0.28)))))

    def try_size(size: int, candidate: str = text) -> FitResult:
        font = load_font(font_path, size)
        line_gap = int(size * spacing)
        logical_lines = wrap_logical(draw, candidate, font, max_w)
        lines = [" ".join(line) for line in logical_lines]
        if not lines:
            return FitResult(size, [], size + line_gap, 0, True)
        ratio = (getattr(cfg, "stroke_width_ratio", 0.0)
                 if stroke_width_ratio is None else stroke_width_ratio)
        stroke_w = max(0, int(round(size * float(ratio))))
        boxes = [draw.textbbox((0, 0), display(line), font=font, stroke_width=stroke_w)
                 for line in lines]
        widths = [box[2] - box[0] for box in boxes]
        widest = max(widths, default=0)
        # اندازه‌گیریِ bbox واقعی مهم است: در بعضی فونت‌های فارسی، glyph از
        # اندازه‌ی اسمیِ فونت بلندتر است و textlength فقط عرض را می‌سنجد.
        line_height = max(box[3] - box[1] for box in boxes) + line_gap
        tops = [i * line_height + box[1] for i, box in enumerate(boxes)]
        bottoms = [i * line_height + box[3] for i, box in enumerate(boxes)]
        block = max(bottoms) - min(tops)
        ok = block <= max_h and widest <= max_w + 1
        return FitResult(size, lines, line_height, block, ok)

    # حداکثر حدود ۲۵٪ از اندازه‌ی متنِ اصلی کوچک‌تر می‌شویم؛ فونتِ ناخوانای ۴px
    # را به متنِ کامل ترجیح نمی‌دهیم. در صورتِ نیاز، انتهای جمله با … کوتاه می‌شود.
    floor = min(max(1, suggested), max(lo, round(suggested * 0.75)))
    for size in range(max(1, suggested), floor - 1, -1):
        result = try_size(size)
        if result.ok:
            return result

    # اگر متنِ کامل جا نشد، واژه‌ها را از انتها کم می‌کنیم تا متنِ کوتاه‌شده داخل بالن بماند.
    words = text.split()
    original_count = len(words)
    while words:
        candidate = " ".join(words)
        if len(words) < original_count:
            candidate = candidate.rstrip(" ،؛,.!?؟") + "…"
        result = try_size(floor, candidate)
        if result.ok:
            return result
        words.pop()
    return try_size(floor, "…")


# ------------------------------------------------------------------ ترسیم
def draw_text_block(img_bgr: np.ndarray, box: Tuple[int, int, int, int], text: str, cfg,
                    base_size: float = 0.0,
                    style: Optional[TextStyle] = None) -> np.ndarray:
    """نوشتن متن فارسی در یک مستطیل روی تصویرِ BGR.

    اگر سبکِ نوشته‌ی مبدأ با اطمینان تشخیص داده شده باشد، رنگ، دورخط و گرادیان
    ساده روی ماسکِ حروف فارسی اعمال می‌شوند؛ در غیر این صورت، رفتار قبلی حفظ می‌شود.
    """
    if not text or img_bgr.size == 0:
        return img_bgr
    x, y, w, h = box
    H, W = img_bgr.shape[:2]
    x, y = max(0, int(x)), max(0, int(y))
    w, h = min(int(w), W - x), min(int(h), H - y)
    if w <= 2 or h <= 2:
        return img_bgr

    text = normalize_fa(text)
    font_path = str(getattr(cfg, "font_path", ""))
    cfg_stroke_ratio = float(getattr(cfg, "stroke_width_ratio", 0.0))
    style_stroke_ratio = float(style.stroke_width_ratio) if style else 0.0
    if style and style.stroke_color and style_stroke_ratio <= 0:
        style_stroke_ratio = 0.06
    stroke_ratio = style_stroke_ratio if style_stroke_ratio > 0 else cfg_stroke_ratio
    try:
        fit = fit_text(font_path, text, w, h, cfg, base_size=base_size,
                       stroke_width_ratio=stroke_ratio)
    except Exception:
        return img_bgr
    if not fit.lines or not fit.ok:
        # اگر حتی سه‌نقطه هم در بالنِ بسیار ریز جا نشد، چیزی نمی‌نویسیم تا بیرون نزند.
        return img_bgr

    pil = Image.fromarray(img_bgr[..., ::-1].copy())
    draw = ImageDraw.Draw(pil)
    font = load_font(font_path, fit.size)
    color = str(style.color if style and style.color else getattr(cfg, "color", "#000000"))
    stroke_w = max(0, int(round(fit.size * stroke_ratio)))
    if style and style.stroke_color:
        stroke_fill = str(style.stroke_color)
    else:
        stroke_fill = str(getattr(cfg, "stroke_color", "#FFFFFF"))

    text_boxes = [draw.textbbox((0, 0), display(line), font=font, stroke_width=stroke_w)
                  for line in fit.lines]
    top_offsets = [i * fit.line_height + box[1]
                   for i, box in enumerate(text_boxes)]
    bottom_offsets = [i * fit.line_height + box[3]
                      for i, box in enumerate(text_boxes)]
    actual_top = min(top_offsets)
    actual_bottom = max(bottom_offsets)
    anchor_top = y + (h - (actual_bottom - actual_top)) // 2 - actual_top

    align = str(getattr(cfg, "align", "center"))
    placements = []
    for i, (line, bbox) in enumerate(zip(fit.lines, text_boxes)):
        disp = display(line)
        left, _top, right, _bottom = bbox
        text_w = right - left
        if align == "right":
            content_left = x + w - text_w - int(w * 0.06)
        elif align == "left":
            content_left = x + int(w * 0.06)
        else:
            content_left = x + (w - text_w) / 2
        lx = content_left - left
        ly = anchor_top + i * fit.line_height
        placements.append((disp, lx, ly, bbox))

    special_style = bool(style and (style.color or style.stroke_color or style.gradient_colors))
    if not special_style:
        for disp, lx, ly, _bbox in placements:
            if stroke_w:
                draw.text((lx, ly), disp, font=font, fill=color,
                          stroke_width=stroke_w, stroke_fill=stroke_fill)
            else:
                draw.text((lx, ly), disp, font=font, fill=color)
        return np.array(pil)[..., ::-1].copy()

    # لایه‌ها فقط به اندازه‌ی خودِ نوشته ساخته می‌شوند؛ تصویرهای بلندِ وب‌تون
    # به همین دلیل یک ماسک/گرادیانِ چندصد مگابایتیِ تمام‌صفحه نمی‌سازند.
    global_bounds = []
    for _disp, lx, ly, bbox in placements:
        left, top, right, bottom = bbox
        global_bounds.append((int(lx + left), int(ly + top),
                              int(lx + right), int(ly + bottom)))
    margin = max(2, stroke_w + 1)
    mx0 = max(0, min(b[0] for b in global_bounds) - margin)
    my0 = max(0, min(b[1] for b in global_bounds) - margin)
    mx1 = min(W, max(b[2] for b in global_bounds) + margin)
    my1 = min(H, max(b[3] for b in global_bounds) + margin)
    if mx1 <= mx0 or my1 <= my0:
        return np.array(pil)[..., ::-1].copy()
    mask_w, mask_h = mx1 - mx0, my1 - my0
    fill_mask = Image.new("L", (mask_w, mask_h), 0)
    fill_draw = ImageDraw.Draw(fill_mask)
    stroke_mask = Image.new("L", (mask_w, mask_h), 0) if stroke_w else None
    stroke_draw = ImageDraw.Draw(stroke_mask) if stroke_mask is not None else None
    for disp, lx, ly, _bbox in placements:
        local_pos = (lx - mx0, ly - my0)
        fill_draw.text(local_pos, disp, font=font, fill=255)
        if stroke_draw is not None:
            stroke_draw.text(local_pos, disp, font=font, fill=255,
                             stroke_width=stroke_w, stroke_fill=255)

    if stroke_mask is not None:
        try:
            pil.paste(ImageColor.getrgb(stroke_fill), (mx0, my0), stroke_mask)
        except ValueError:
            pil.paste((0, 0, 0), (mx0, my0), stroke_mask)

    if style and style.gradient_colors and global_bounds:
        gx0 = max(0, min(b[0] for b in global_bounds) - mx0)
        gy0 = max(0, min(b[1] for b in global_bounds) - my0)
        gx1 = min(mask_w, max(b[2] for b in global_bounds) - mx0)
        gy1 = min(mask_h, max(b[3] for b in global_bounds) - my0)
        c0 = np.asarray(ImageColor.getrgb(style.gradient_colors[0]), dtype=np.float32)
        c1 = np.asarray(ImageColor.getrgb(style.gradient_colors[1]), dtype=np.float32)
        if style.gradient_axis == "horizontal":
            t = np.clip((np.arange(mask_w, dtype=np.float32) - gx0) / max(1, gx1 - gx0), 0, 1)
            row = c0[None, :] * (1 - t[:, None]) + c1[None, :] * t[:, None]
            gradient = np.repeat(row[None, :, :], mask_h, axis=0)
        else:
            t = np.clip((np.arange(mask_h, dtype=np.float32) - gy0) / max(1, gy1 - gy0), 0, 1)
            col = c0[None, :] * (1 - t[:, None]) + c1[None, :] * t[:, None]
            gradient = np.repeat(col[:, None, :], mask_w, axis=1)
        gradient_img = Image.fromarray(np.clip(gradient, 0, 255).astype(np.uint8), "RGB")
        pil.paste(gradient_img, (mx0, my0), fill_mask)
    else:
        try:
            pil.paste(ImageColor.getrgb(color), (mx0, my0), fill_mask)
        except ValueError:
            pil.paste((0, 0, 0), (mx0, my0), fill_mask)

    return np.array(pil)[..., ::-1].copy()
