"""خط لوله‌ی اصلی: تصویر/زیپِ مانها → تشخیص متن → ترجمه → بازنویسی روی تصویر.

ترتیب کار روی هر صفحه:
    1. پیدا کردن بالن‌ها (یا دسته‌بندی کادرهای OCR اگر بالن پیدا نشد)
    2. OCR داخل هر ناحیه
    3. ترجمه (ابتدا واژه‌نامه‌ی مستقیم، بعد مدل)
    4. عامیانه‌سازی
    5. پاک کردن متن اصلی
    6. حروف‌چینی فارسی (راست‌به‌چپ، اندازه‌ی خودکار)
"""

from __future__ import annotations

import gc
import json
import time
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable, List, Optional, Sequence, Tuple

import cv2
import numpy as np

try:  # هم به صورت پکیج و هم اسکریپت قابل اجرا باشد
    from core.utils import (clean_dir, extract_archive, free_ram_mb, imread,
                            imwrite, list_images, make_zip, natural_key)
    from llm.skills import polish_batch
    from nlp.colloquial import build_colloquializer
    from nlp.filters import looks_translatable
    from nlp.translator import build_translator, flatten
except ImportError:  # pragma: no cover
    from ..core.utils import (clean_dir, extract_archive, free_ram_mb, imread,
                              imwrite, list_images, make_zip, natural_key)
    from ..llm.skills import polish_batch
    from ..nlp.colloquial import build_colloquializer
    from ..nlp.filters import looks_translatable
    from ..nlp.translator import build_translator, flatten

from .bubbles import Bubble, detect_bubbles, expand_to_balloon, inset_box
from .inpaint import clean_region
from .ocr import (OcrBox, build_ocr, dedupe_boxes, group_boxes, merge_text,
                  prepare_for_ocr, union_bbox)
from .render import draw_text_block
from .text_style import detect_text_style

Progress = Callable[[int, int, str], None]


@dataclass
class TextRegion:
    draw_box: Tuple[int, int, int, int]      # جایی که متن فارسی نوشته می‌شود
    erase_box: Tuple[int, int, int, int]     # جایی که متن انگلیسی پاک می‌شود
    source: str
    translated: str = ""
    conf: float = 0.0
    kind: str = "bubble"
    src_height: float = 0.0   # ارتفاع متن اصلی (برای انتخاب اندازه‌ی فونت)


@dataclass
class PageResult:
    name: str
    ok: bool = True
    error: str = ""
    image: Optional[np.ndarray] = None
    regions: List[TextRegion] = field(default_factory=list)
    seconds: float = 0.0

    def to_dict(self) -> dict:
        return {
            "name": self.name, "ok": self.ok, "error": self.error, "seconds": round(self.seconds, 2),
            "regions": [
                {"source": r.source, "translated": r.translated,
                 "box": list(r.draw_box), "conf": round(float(r.conf), 3), "kind": r.kind}
                for r in self.regions
            ],
        }


class ManhwaPipeline:
    def __init__(self, cfg, log=None, llm=None, with_ocr: bool = True,
                 with_translator: bool = True):
        self.cfg = cfg
        self.log = log
        self.low_mem = bool(getattr(cfg, "use_low_memory", False)) or not with_translator
        # OCR تنبل بار می‌شود: در فازِ حروف‌چینی اصلاً لازم نیست
        self._ocr = None if not with_ocr else None
        self._with_ocr = with_ocr
        self._translator = None
        self._translator_name = ""
        if not self.low_mem:      # روی ماشین کم‌رم، ترجمه را دیرتر بار می‌کنیم
            self._ensure_translator()
        self.colloq = build_colloquializer(getattr(cfg.translation, "register", "colloquial"))
        self.llm = llm
        self.render_cfg = replace(cfg.render, font_path=str(cfg.font_path))
        if self.log:
            self.log.info("حالت کم‌حافظه: %s | OCR: %s", self.low_mem,
                          self._ocr.name if self._ocr is not None else "تنبل")

    # ---------- بارگذاریِ تنبلِ OCR ----------
    @property
    def ocr(self):
        if self._ocr is None:
            if not self._with_ocr:
                raise RuntimeError("این نمونه بدون موتور OCR ساخته شده است")
            self._ocr = build_ocr(self.cfg.ocr.engine, self.cfg.ocr.langs,
                                  self.cfg.ocr.min_conf)
        return self._ocr

    @property
    def ocr_name(self) -> str:
        return self._ocr.name if self._ocr is not None else "none"

    # ---------- بارگذاری/آزادسازیِ موتور ترجمه ----------
    def _ensure_translator(self):
        if self._translator is None:
            self._translator = build_translator(self.cfg.translation, self.log,
                                              low_memory=self.low_mem)
            self._translator_name = self._translator.name
            if self.log:
                self.log.info(f"موتور ترجمه بار شد: {self._translator_name}")
        return self._translator

    def _release_translator(self):
        if self._translator is None:
            return
        try:
            save = getattr(self._translator, "save", None)
            if callable(save):
                save()
        except Exception:
            pass
        self._translator = None
        gc.collect()

    @property
    def translator(self):
        return self._ensure_translator()

    # ------------------------------------------------------------ یک تصویر
    def process_image(self, img: np.ndarray, name: str = "page") -> PageResult:
        t0 = time.time()
        res = PageResult(name=name)
        try:
            if img is None or img.size == 0:
                raise ValueError("تصویر خالی است")
            regions = self._find_regions(img)
            regions = [r for r in regions if r.source.strip()]
            if not regions:
                res.image = img
                res.seconds = time.time() - t0
                if self.log:
                    self.log.info(f"{name}: متنی پیدا نشد")
                return res

            self._translate_regions(regions)
            if self.low_mem:
                self._release_translator()   # جا برای بافرهای تصویر باز شود
            out = self.render_regions(img.copy(), regions)
            res.image = out
            res.regions = regions
        except Exception as e:
            res.ok = False
            res.error = f"{type(e).__name__}: {e}"
            if self.log:
                self.log.error(f"{name}: {res.error}")
        res.seconds = time.time() - t0
        if self.log and res.ok:
            self.log.info(f"{name}: {len(res.regions)} ناحیه در {res.seconds:.1f} ثانیه")
        gc.collect()   # روی ماشین‌های کم‌رم مهم است
        return res

    def process_path(self, path: str | Path) -> PageResult:
        return self.process_image(imread(path), name=Path(path).name)

    # --------------------------------------------- نوشتنِ ترجمه روی تصویر
    def render_regions(self, img: np.ndarray, regions: Sequence[TextRegion]) -> np.ndarray:
        """پاک کردن متن اصلی و حروف‌چینی فارسی — بدون نیاز به OCR یا مدل ترجمه.

        سبکِ رنگی/دورخط پیش از پاک‌سازی از تصویرِ مبدأ نمونه‌برداری می‌شود؛
        متنِ ساده‌ی سیاه‌وسفید همچنان از تشخیص روشن/تیره‌ی بالن استفاده می‌کند.
        """
        styles = [detect_text_style(img, r.erase_box, r.src_height)
                  if r.translated else None for r in regions]
        out = img
        for r, style in zip(regions, styles):
            if not r.translated:
                continue
            out = self._erase(out, r)
            base = r.src_height * 0.88 if r.src_height else 0.0
            out = draw_text_block(out, r.draw_box, r.translated,
                                  self._render_cfg_for(out, r), base_size=base,
                                  style=style)
        return out

    # ------------------------------------------------- ذخیره/بازیابیِ ناحیه‌ها
    @staticmethod
    def regions_to_json(regions: Sequence[TextRegion]) -> list:
        return [{
            "draw_box": [int(v) for v in r.draw_box],
            "erase_box": [int(v) for v in r.erase_box],
            "source": r.source, "translated": r.translated,
            "conf": float(r.conf), "kind": r.kind, "src_height": float(r.src_height),
        } for r in regions]

    @staticmethod
    def regions_from_json(data) -> List[TextRegion]:
        out = []
        for d in data or []:
            out.append(TextRegion(
                draw_box=tuple(int(v) for v in d["draw_box"]),
                erase_box=tuple(int(v) for v in d["erase_box"]),
                source=d.get("source", ""), translated=d.get("translated", ""),
                conf=float(d.get("conf", 0.0)), kind=d.get("kind", "auto"),
                src_height=float(d.get("src_height", 0.0)),
            ))
        return out

    # -------------------------------------------------- تشخیص ناحیه‌های متن
    def _ocr_page(self, img: np.ndarray) -> List[OcrBox]:
        """OCR کل صفحه؛ صفحه‌های خیلی بلند (وب‌تون) کاشی‌بندی می‌شوند."""
        h, w = img.shape[:2]
        upscale = float(self.cfg.ocr.upscale)
        max_side = int(self.cfg.ocr.max_side)
        max_pixels = int(getattr(self.cfg.ocr, "max_pixels", 2_500_000))
        min_side = int(getattr(self.cfg.ocr, "min_side", 620))
        tile, overlap = 1500, 150
        boxes: List[OcrBox] = []
        if h <= tile * 1.35:
            prepared, s = prepare_for_ocr(img, upscale, max_side, max_pixels, min_side)
            boxes = self._map_back(self._ocr_with_retry(prepared), s, (0, 0))
        else:
            y = 0
            while y < h:
                y1 = min(h, y + tile)
                strip = img[y:y1]
                prepared, s = prepare_for_ocr(strip, upscale, max_side, max_pixels, min_side)
                boxes.extend(self._map_back(self._ocr_with_retry(prepared), s, (0, y)))
                del strip, prepared
                if y1 >= h:
                    break
                y = y1 - overlap
        min_conf = float(self.cfg.ocr.min_conf)
        return dedupe_boxes([b for b in boxes if b.conf >= min_conf])

    def _find_regions(self, img: np.ndarray) -> List[TextRegion]:
        """پیدا کردن ناحیه‌های متنی.

        برخلاف روش‌های رایج، از «متن» شروع می‌کنیم نه از «بالن»:
        اول OCR روی کل صفحه اجرا می‌شود، بعد کادرهای متنی را به بالن‌ها نسبت
        می‌دهیم (اگر بالن تشخیص داده شده باشد) و در نهایت مرزِ واقعیِ بالن را
        از روی خطِ دورش پیدا می‌کنیم. این روی صفحه‌های کاملاً سفید هم جواب می‌دهد.
        """
        boxes = self._ocr_page(img)
        if not boxes:
            return []

        bubbles: List[Bubble] = []
        if getattr(self.cfg.bubbles, "enabled", True):
            try:
                bubbles = detect_bubbles(img, self.cfg.bubbles)
            except Exception as e:
                if self.log:
                    self.log.debug(f"تشخیص بالن ناموفق: {e}")

        regions: List[TextRegion] = []
        used = [False] * len(boxes)

        # --- کادرهایی که داخل یک بالنِ تشخیص‌داده‌شده افتاده‌اند ---
        for b in bubbles:
            idxs = [i for i, bx in enumerate(boxes)
                    if not used[i] and self._inside(bx.center, b.bbox)]
            if not idxs:
                continue
            for i in idxs:
                used[i] = True
            group = [boxes[i] for i in idxs]
            text = merge_text(group)
            if not text.strip():
                continue
            erase = union_bbox(group, pad=5)
            if erase[2] < 10 or erase[3] < 8:
                continue
            draw = self._safe_draw(img, erase, b.bbox)
            regions.append(TextRegion(draw_box=draw, erase_box=erase, source=text,
                                      kind=b.kind, src_height=self._line_height(group),
                                      conf=float(np.mean([x.conf for x in group]))))

        # --- باقی‌مانده: دسته‌بندی بر اساس نزدیکی ---
        rest = [bx for i, bx in enumerate(boxes) if not used[i]]
        for grp in group_boxes(rest):
            if not grp:
                continue
            text = merge_text(grp)
            if not text.strip():
                continue
            erase = union_bbox(grp, pad=6)
            if erase[2] < 10 or erase[3] < 8:
                continue
            draw = self._safe_draw(img, erase, None)
            regions.append(TextRegion(draw_box=draw, erase_box=erase, source=text,
                                      kind="auto", src_height=self._line_height(grp),
                                      conf=float(np.mean([x.conf for x in grp]))))

        return self._reading_order(regions, img.shape[0])

    # ------------------------------------------------------------- کمکی‌ها
    @staticmethod
    def _line_height(group: Sequence[OcrBox]) -> float:
        if not group:
            return 0.0
        hs = sorted(float(b.height) for b in group)
        return float(hs[len(hs) // 2])

    @staticmethod
    def _inside(point: Tuple[float, float], box: Tuple[int, int, int, int]) -> bool:
        x, y = point
        bx, by, bw, bh = box
        return bx <= x <= bx + bw and by <= y <= by + bh

    def _safe_draw(self, img: np.ndarray, text_box: Tuple[int, int, int, int],
                   bubble_box: Optional[Tuple[int, int, int, int]]) -> Tuple[int, int, int, int]:
        """گسترش کادرِ متن تا مرزِ بالن، با تضمین اینکه متن داخلش بماند."""
        cand = expand_to_balloon(img, text_box, fallback=bubble_box)
        tx, ty, tw, th = text_box
        cx, cy, cw, ch = cand
        iw = max(0, min(tx + tw, cx + cw) - max(tx, cx))
        ih = max(0, min(ty + th, cy + ch) - max(ty, cy))
        cover = (iw * ih) / max(1.0, tw * th)
        if cover < 0.80 or cw < tw * 0.9 or ch < th * 0.9:
            pad = int(max(tw, th) * 0.25)
            cand = (max(0, tx - pad), max(0, ty - pad), tw + 2 * pad, th + 2 * pad)
        return cand

    def _reading_order(self, regions: List[TextRegion], page_h: int) -> List[TextRegion]:
        band = max(24, int(page_h * 0.05))
        manga = str(getattr(self.cfg.bubbles, "reading_order", "webtoon")).lower() == "manga"

        def key(r: TextRegion):
            x, y, w, h = r.draw_box
            return (y // band, -x if manga else x)

        return sorted(regions, key=key)

    @staticmethod
    def _map_back(boxes: Sequence[OcrBox], scale: float,
                  offset: Tuple[int, int]) -> List[OcrBox]:
        """برگرداندن مختصات از فضایِ بزرگ‌نمایی‌شده به تصویر اصلی."""
        if not boxes:
            return []
        if abs(scale - 1.0) < 1e-6 and offset == (0, 0):
            return list(boxes)
        out = []
        for b in boxes:
            pts = b.box.astype(np.float32).copy()
            pts /= float(scale)
            pts[:, 0] += offset[0]
            pts[:, 1] += offset[1]
            out.append(OcrBox(box=pts, text=b.text, conf=b.conf))
        return out

    def _ocr_with_retry(self, img: np.ndarray) -> List[OcrBox]:
        try:
            return self.ocr.read(img)
        except Exception as e:
            if self.log:
                self.log.debug(f"OCR خطا داد: {e}")
            return []

    def _translate_regions(self, regions: List[TextRegion]) -> None:
        # واترمارک/نوشته‌های غیرلاتین را ترجمه نمی‌کنیم: اثر هنری دست‌نخورده می‌ماند
        translatable = [i for i, r in enumerate(regions)
                        if looks_translatable(getattr(r, "source", ""))]
        allowed = set(translatable)
        for i, r in enumerate(regions):
            if i not in allowed:
                r.translated = ""
                r.kind = "skip"

        direct: dict[int, str] = {}
        todo_idx: List[int] = []
        todo_src: List[str] = []
        flat = [flatten(r.source) for r in regions]   # بالن‌ها خط‌به‌خط خوانده می‌شوند
        for i in translatable:
            hit = self.colloq.lookup_direct(flat[i])
            if hit:
                direct[i] = hit
            else:
                todo_idx.append(i)
                todo_src.append(self.colloq.preprocess_en(flat[i]))
        results: List[str] = []
        if todo_src:
            bs = max(1, int(getattr(self.cfg.translation, "batch_size", 16)))
            for a in range(0, len(todo_src), bs):
                results.extend(self.translator.translate_batch(todo_src[a:a + bs]))
        draft_map = {i: results[k] for k, i in enumerate(todo_idx)}
        draft_map.update(direct)

        if self.llm is not None and getattr(self.cfg.llm, "polish_translation", False):
            idxs = list(draft_map.keys())
            polished = polish_batch(
                self.llm, [flat[i] for i in idxs],
                [draft_map[i] for i in idxs],
                register=getattr(self.cfg.translation, "register", "colloquial"),
            )
            for i, p in zip(idxs, polished):
                draft_map[i] = p

        for i, r in enumerate(regions):
            r.translated = self.colloq.colloquialize(draft_map.get(i, ""), src=flat[i])

    def _render_cfg_for(self, img: np.ndarray, r: TextRegion):
        """انتخاب رنگِ نوشته بر اساس روشناییِ زمینه (بالن تیره → متن روشن).

        نمونه‌برداری از «حلقه‌ی بیرونیِ کادرِ بالن» انجام می‌شود نه از خودِ متن؛
        وگرنه روی بالن تیره (که متنش سفید است) اشتباه تشخیص می‌دهیم.
        """
        # نمونه‌برداری از «درونِ بالن» بعد از پاک‌سازی: مطمئن‌ترین نشانه‌ی رنگِ زمینه
        # (نه از حاشیه که ممکن است روی نقاشیِ تیره افتاده باشد، نه از برچسبِ تشخیص‌گر)
        med = self._fill_brightness(img, r.erase_box, fallback_box=r.draw_box)
        kind = "dark" if med < 118 else "light"
        if kind == "dark":
            return replace(self.render_cfg, color="#FFFFFF", stroke_color="#000000")
        return self.render_cfg

    @staticmethod
    def _fill_brightness(img: np.ndarray, box: Tuple[int, int, int, int],
                         fallback_box: Tuple[int, int, int, int] | None = None) -> float:
        """روشناییِ میانه‌ی یک ناحیه (برای تشخیص رنگِ متن)."""
        H, W = img.shape[:2]
        x, y, w, h = box
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(W, x + w), min(H, y + h)
        crop = img[y0:y1, x0:x1] if (x1 - x0 > 4 and y1 - y0 > 4) else None
        if crop is None or crop.size == 0:
            if fallback_box is None:
                return 255.0
            fx, fy, fw, fh = fallback_box
            fx0, fy0 = max(0, fx), max(0, fy)
            crop = img[fy0:min(H, fy + fh), fx0:min(W, fx + fw)]
            if crop.size == 0:
                return 255.0
        gray = crop if crop.ndim == 2 else cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        return float(np.median(gray))

    @staticmethod
    def _ring_brightness(img: np.ndarray, box: Tuple[int, int, int, int]) -> float:
        """میانگین روشناییِ حاشیه‌ی یک کادر (زمینه‌ی بالن)."""
        H, W = img.shape[:2]
        x, y, w, h = box
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(W, x + w), min(H, y + h)
        if x1 - x0 < 6 or y1 - y0 < 6:
            return 255.0
        crop = img[y0:y1, x0:x1]
        inset = max(2, int(min(crop.shape[:2]) * 0.14))
        if crop.shape[0] - 2 * inset < 3 or crop.shape[1] - 2 * inset < 3:
            return float(np.median(crop))
        gray = crop if crop.ndim == 2 else cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        ring = np.concatenate([
            gray[:inset, :].ravel(), gray[-inset:, :].ravel(),
            gray[:, :inset].ravel(), gray[:, -inset:].ravel(),
        ])
        return float(np.median(ring)) if ring.size else float(np.median(gray))

    # -------------------------------------------------------------- پاک‌سازی
    def _erase(self, img: np.ndarray, r: TextRegion) -> np.ndarray:
        h, w = img.shape[:2]
        x, y, bw, bh = r.erase_box
        pad = 3
        x0, y0 = max(0, x - pad), max(0, y - pad)
        x1, y1 = min(w, x + bw + pad), min(h, y + bh + pad)
        if x1 <= x0 or y1 <= y0:
            return img
        crop = img[y0:y1, x0:x1]
        cleaned, _ = clean_region(crop, self.cfg.inpaint)
        img[y0:y1, x0:x1] = cleaned
        return img

    # ------------------------------------------------------------- آرشیو
    def process_archive(self, archive: str | Path, out_dir: str | Path,
                        out_zip: str | Path | None = None,
                        progress: Optional[Progress] = None,
                        max_pages: int = 60) -> Tuple[Path, dict]:
        archive = Path(archive)
        out_dir = Path(out_dir)
        clean_dir(out_dir)
        extracted = extract_archive(archive, out_dir / "_in")
        pages = list_images(extracted)[:max_pages]
        total = len(pages)
        results: List[PageResult] = []
        out_files: List[Path] = []
        low_mem_note = ""

        if self.low_mem:
            # سه مرحله: ۱) فقط OCR  ۲) فقط ترجمه  ۳) فقط پاک‌سازی و حروف‌چینی
            # به این ترتیب هیچ‌وقت OCR و مدل ترجمه همزمان در حافظه نیستند.
            per_page: List[Tuple[Path, List[TextRegion]]] = []
            for i, p in enumerate(pages, 1):
                if progress:
                    progress(i - 1, total, f"خواندن {p.name}")
                try:
                    img = imread(p)
                    regions = self._find_regions(img)
                except Exception as e:
                    pr = PageResult(name=p.name, ok=False, error=str(e))
                    results.append(pr)
                    continue
                per_page.append((p, regions))
                del img
                gc.collect()
            if progress:
                progress(total, total, "در حال ترجمه...")
            all_regions = [r for _, rs in per_page for r in rs]
            if all_regions:
                self._translate_regions(all_regions)
            self._release_translator()
            gc.collect()

            for i, (p, regions) in enumerate(per_page, 1):
                if progress:
                    progress(i, total, f"نوشتن {p.name}")
                pr = PageResult(name=p.name, regions=regions)
                try:
                    img = self.render_regions(imread(p), regions)
                    out_file = out_dir / (p.stem + "_fa" + p.suffix.lower())
                    imwrite(out_file, img)
                    out_files.append(out_file)
                    pr.seconds = 0.0
                except Exception as e:
                    pr.ok, pr.error = False, str(e)
                del img
                gc.collect()
                results.append(pr)
        else:
            for i, p in enumerate(pages, 1):
                free_mb = free_ram_mb()
                if 0 < free_mb < 320:
                    low_mem_note = f" (توقف در صفحه‌ی {i}: حافظه کم بود)"
                    if self.log:
                        self.log.warning(f"حافظه کم است ({free_mb:.0f}MB)؛ ادامه متوقف شد")
                    break
                if progress:
                    progress(i - 1, total, f"در حال پردازش {p.name}")
                pr = self.process_path(p)
                results.append(pr)
                if pr.ok and pr.image is not None:
                    out_file = out_dir / (p.stem + "_fa" + p.suffix.lower())
                    imwrite(out_file, pr.image)
                    out_files.append(out_file)
                pr.image = None
                gc.collect()
                if progress:
                    progress(i, total, f"{p.name} تمام شد")
        sidecar = out_dir / "translation.json"
        sidecar.write_text(
            json.dumps([r.to_dict() for r in results], ensure_ascii=False, indent=2),
            encoding="utf-8")
        zip_path = Path(out_zip) if out_zip else out_dir.parent / f"{archive.stem}_fa.zip"
        make_zip(out_files, zip_path)
        stats = {
            "pages": total,
            "regions": sum(len(r.regions) for r in results),
            "failed": sum(1 for r in results if not r.ok),
            "seconds": round(sum(r.seconds for r in results), 2),
            "note": low_mem_note,
            "ocr": self.ocr_name,
            "translator": self._translator_name or "lazy",
            "sidecar": str(sidecar),
        }
        return zip_path, stats
