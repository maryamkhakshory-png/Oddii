"""تشخیص بالن‌های گفتار (speech balloon) — پیاده‌سازی دستی با OpenCV.

ایده:
    1. جداسازی نواحیِ بسیار روشن (کاغذ سفید داخل بالن) و نواحیِ بسیار تیره (بالن افکار)
    2. عملیات ریخت‌شناسی برای پُر کردن حروف سیاهِ داخل بالن و گرفتن یک blob یکپارچه
    3. پیدا کردن کانتورها و فیلتر کردن بر اساس مساحت، نسبتِ مرکب (ink) و هندسه
    4. ادغام کادرهای هم‌پوشان و مرتب‌سازی به ترتیب خواندن

این بخش عمداً «الگوریتمی» نوشته شده (نه یک مدل یادگیری عمیق) تا روی CPU ضعیف هم
سریع باشد و وابستگی اضافه‌ای نداشته باشد.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence, Tuple

import cv2
import numpy as np

try:  # هم به صورت پکیج و هم اسکریپت قابل اجرا باشد
    from core.utils import resize_max
except ImportError:  # pragma: no cover
    from ..core.utils import resize_max


@dataclass
class Bubble:
    bbox: Tuple[int, int, int, int]  # x, y, w, h
    kind: str = "light"              # light | dark
    score: float = 0.0

    @property
    def area(self) -> int:
        return max(1, self.bbox[2] * self.bbox[3])

    @property
    def center(self) -> Tuple[int, int]:
        x, y, w, h = self.bbox
        return x + w // 2, y + h // 2


def _iou(a: Tuple[int, int, int, int], b: Tuple[int, int, int, int]) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    x0, y0 = max(ax, bx), max(ay, by)
    x1, y1 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    iw, ih = max(0, x1 - x0), max(0, y1 - y0)
    inter = iw * ih
    if inter == 0:
        return 0.0
    union = aw * ah + bw * bh - inter
    return inter / max(1.0, union)


def _containment(a: Tuple[int, int, int, int], b: Tuple[int, int, int, int]) -> float:
    """چقدر از a داخل b است (برای حذف کادرهای تودرتو)."""
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    x0, y0 = max(ax, bx), max(ay, by)
    x1, y1 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    inter = max(0, x1 - x0) * max(0, y1 - y0)
    return inter / max(1.0, aw * ah)


def merge_boxes(boxes: Sequence[Tuple[int, int, int, int]], iou_thr: float = 0.25) -> List[Tuple[int, int, int, int]]:
    boxes = list(boxes)
    changed = True
    while changed:
        changed = False
        out: List[Tuple[int, int, int, int]] = []
        for b in boxes:
            merged = False
            for i, o in enumerate(out):
                if _iou(b, o) > iou_thr or _containment(b, o) > 0.85 or _containment(o, b) > 0.85:
                    x0 = min(b[0], o[0])
                    y0 = min(b[1], o[1])
                    x1 = max(b[0] + b[2], o[0] + o[2])
                    y1 = max(b[1] + b[3], o[1] + o[3])
                    out[i] = (x0, y0, x1 - x0, y1 - y0)
                    merged = True
                    changed = True
                    break
            if not merged:
                out.append(b)
        boxes = out
    return boxes


def _contour_ink_ratio(mask: np.ndarray, gray: np.ndarray, dark: bool) -> float:
    """نسبت پیکسل‌های «مرکب» داخل یک کانتور.

    dark=True یعنی بالن تیره است و متن داخلش روشن است (و برعکس).
    """
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return 0.0
    region = gray[ys, xs]
    if region.size == 0:
        return 0.0
    med = float(np.median(region))
    std = float(np.std(region)) or 1.0
    thr = med - 1.2 * std if dark else med + 1.2 * std
    ink = (region < thr) if not dark else (region > thr)
    # برای بالن‌های تیره خودِ پس‌زمینه تیره است؛ از آستانه مطلق استفاده کن
    if dark:
        hi = float(np.percentile(region, 80))
        ink = region > max(hi, med + 1.0 * std)
    return float(ink.mean())


def _candidate_boxes(mask: np.ndarray, gray: np.ndarray, dark: bool, cfg) -> List[Tuple[int, int, int, int]]:
    h, w = gray.shape[:2]
    page = float(h * w)
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes: List[Tuple[int, int, int, int]] = []
    k = max(3, int(min(h, w) * 0.02))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    for c in cnts:
        area = cv2.contourArea(c)
        if area <= 0:
            continue
        ratio = area / page
        if ratio < cfg.min_area_ratio or ratio > cfg.max_area_ratio:
            continue
        x, y, bw, bh = cv2.boundingRect(c)
        if bw < 28 or bh < 22:
            continue
        aspect = bw / max(1.0, bh)
        if aspect < 0.14 or aspect > 9.0:
            continue
        if bw > 0.97 * w and bh > 0.97 * h:
            continue  # کل صفحه
        cm = np.zeros((h, w), np.uint8)
        cv2.drawContours(cm, [c], -1, 255, -1)
        cm = cv2.erode(cm, kernel, iterations=1)
        filled = cm[y : y + bh, x : x + bw]
        if filled.size == 0 or filled.mean() < 8:
            continue
        ink = _contour_ink_ratio(filled, gray, dark)
        if ink < cfg.min_ink_ratio or ink > cfg.max_ink_ratio:
            continue
        hull = cv2.convexHull(c)
        solidity = area / max(1.0, cv2.contourArea(hull))
        if solidity < 0.45:
            continue
        boxes.append((x, y, bw, bh))
    return boxes


def detect_bubbles(img: np.ndarray, cfg) -> List[Bubble]:
    """پیدا کردن بالن‌های گفتار روی یک صفحه."""
    h0, w0 = img.shape[:2]
    work = resize_max(img, 1100)
    h, w = work.shape[:2]
    sx, sy = w0 / max(1, w), h0 / max(1, h)

    gray = cv2.cvtColor(work, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 3)

    hi_pct = float(np.percentile(gray, 88))
    lo_pct = float(np.percentile(gray, 10))
    thr_light = int(np.clip(max(hi_pct, 190), 150, 245))
    thr_dark = int(np.clip(min(lo_pct + 30, 110), 20, 130))

    k = max(5, int(min(h, w) * 0.022))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))

    found: List[Bubble] = []

    # --- بالن‌های روشن ---
    light = (gray >= thr_light).astype(np.uint8) * 255
    light = cv2.morphologyEx(light, cv2.MORPH_CLOSE, kernel)
    light = cv2.morphologyEx(light, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    for (x, y, bw, bh) in _candidate_boxes(light, gray, dark=False, cfg=cfg):
        found.append(Bubble((int(x * sx), int(y * sy), int(bw * sx), int(bh * sy)), "light"))

    # --- بالن‌های تیره (افکار) ---
    if getattr(cfg, "dark_bubbles", True):
        darkm = (gray <= thr_dark).astype(np.uint8) * 255
        darkm = cv2.morphologyEx(darkm, cv2.MORPH_CLOSE, kernel)
        darkm = cv2.morphologyEx(darkm, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
        for (x, y, bw, bh) in _candidate_boxes(darkm, gray, dark=True, cfg=cfg):
            found.append(Bubble((int(x * sx), int(y * sy), int(bw * sx), int(bh * sy)), "dark"))

    if not found:
        return []

    # ادغام + حذف تودرتوها
    merged = merge_boxes([b.bbox for b in found])
    merged = [b for b in merged if b[2] * b[3] >= cfg.min_area_ratio * h0 * w0 * 0.5]

    # حذف کادرهایی که کاملاً داخل کادر بزرگ‌ترند
    final: List[Tuple[int, int, int, int]] = []
    for b in sorted(merged, key=lambda z: z[2] * z[3], reverse=True):
        if all(_containment(b, o) < 0.8 for o in final):
            final.append(b)

    pad = int(getattr(cfg, "padding", 4))
    bubbles = [
        Bubble((max(0, b[0] - pad), max(0, b[1] - pad), b[2] + 2 * pad, b[3] + 2 * pad), "light")
        for b in final
    ]
    return sort_reading_order(bubbles, h0, cfg)


def sort_reading_order(bubbles: List[Bubble], page_h: int, cfg) -> List[Bubble]:
    """مرتب‌سازی به ترتیب خواندن.

    webtoon (مانها/مانگای رنگی): بالا به پایین، در هر ردیف چپ به راست
    manga (مانگای ژاپنی): بالا به پایین، در هر ردیف راست به چپ
    """
    band = max(24, int(page_h * 0.05))

    def key(b: Bubble):
        x, y, w, h = b.bbox
        row = y // band
        if str(getattr(cfg, "reading_order", "webtoon")).lower() == "manga":
            return (row, -x)
        return (row, x)

    return sorted(bubbles, key=key)


def enclosing_outline(img: np.ndarray, box: Tuple[int, int, int, int],
                      pad_ratio: float = 1.1, min_contain: float = 0.75,
                      max_grow: float = 1.9, max_ring_std: float = 32.0):
    """پیدا کردن «خط دورِ» بالن با استفاده از یک کادرِ متنی که داخل آن است.

    ایده: متن را (که از OCR داریم) به عنوان دانه می‌گیریم و دور تا دورش به دنبال
    نزدیک‌ترین کانتورِ بسته می‌گردیم که آن را در بر بگیرد — همان خطِ دورِ بالن.
    این روش روی صفحه‌های کاملاً سفید هم کار می‌کند (برخلاف روشنایی‌محور).
    """
    H, W = img.shape[:2]
    x, y, w, h = box
    if w <= 0 or h <= 0:
        return None
    pad_x, pad_y = int(w * pad_ratio), int(h * pad_ratio)
    x0, y0 = max(0, x - pad_x), max(0, y - pad_y)
    x1, y1 = min(W, x + w + pad_x), min(H, y + h + pad_y)
    roi = img[y0:y1, x0:x1]
    if roi.size == 0 or roi.shape[0] < 8 or roi.shape[1] < 8:
        return None

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 3)
    # خطِ دور = پیکسل‌های تیره‌تر از آستانه
    thr = float(np.percentile(gray, 22))
    dark = (gray <= max(0, thr)).astype(np.uint8) * 255
    # هسته‌ی کوچک: فقط روزنه‌های ریزِ خط را می‌بندد و خط را به نقاشی نمی‌چسباند
    dark = cv2.morphologyEx(dark, cv2.MORPH_CLOSE,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    cnts, _ = cv2.findContours(dark, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None

    cx, cy = (x + w / 2.0) - x0, (y + h / 2.0) - y0
    best, best_area, best_c = None, float("inf"), None
    for c in cnts:
        try:
            if cv2.pointPolygonTest(c, (float(cx), float(cy)), False) <= 0:
                continue
        except Exception:
            continue
        rx, ry, rw, rh = cv2.boundingRect(c)
        if rw < w * min_contain or rh < h * min_contain:
            continue
        if rw > w * max_grow or rh > h * max_grow:
            continue  # خیلی بزرگ — احتمالاً کانتورِ نقاشی یا کل پنل است
        if rw >= (x1 - x0) * 0.98 and rh >= (y1 - y0) * 0.98:
            continue  # مرزِ محدوده است، نه بالن
        a = float(cv2.contourArea(c))
        if a < best_area:
            best_area, best, best_c = a, (rx, ry, rw, rh), c
    if best is None or best_c is None:
        return None

    # اعتبارسنجی: نوارِ باریکِ داخلِ خطِ دور باید یک‌دست باشد (درونِ بالن ساده است،
    # روی نقاشی پر از خط و رنگ است)
    mask = np.zeros(gray.shape, np.uint8)
    cv2.drawContours(mask, [best_c], -1, 255, -1)
    band = max(4, int(0.15 * min(best[2], best[3])))
    ring = cv2.subtract(mask, cv2.erode(mask, np.ones((band, band), np.uint8)))
    vals = gray[ring > 0]
    if vals.size < 40:
        return None
    if float(np.std(vals)) > max_ring_std:
        return None
    return (x0 + best[0], y0 + best[1], best[2], best[3])


def inset_box(box: Tuple[int, int, int, int], fx: float = 0.10, fy: float = 0.16):
    """کوچک کردن کادر برای اینکه متن به خطِ دور نچسبد."""
    x, y, w, h = box
    ix, iy = max(2, int(w * fx)), max(2, int(h * fy))
    return (x + ix, y + iy, max(6, w - 2 * ix), max(6, h - 2 * iy))


def expand_to_balloon(img: np.ndarray, text_box: Tuple[int, int, int, int],
                      fallback: Tuple[int, int, int, int] | None = None):
    """کادرِ متن را تا مرزِ بالن گسترش بده (اگر خطِ دوری پیدا شد)."""
    out = enclosing_outline(img, text_box)
    if out is None:
        out = fallback or text_box
    return inset_box(out)


def crop_bubble(img: np.ndarray, bubble: Bubble, pad: int = 6) -> Tuple[np.ndarray, Tuple[int, int]]:
    """برش دادن بالن از تصویر به همراه آفست (برای برگرداندن مختصات)."""
    h, w = img.shape[:2]
    x, y, bw, bh = bubble.bbox
    x0, y0 = max(0, x - pad), max(0, y - pad)
    x1, y1 = min(w, x + bw + pad), min(h, y + bh + pad)
    return img[y0:y1, x0:x1], (x0, y0)
