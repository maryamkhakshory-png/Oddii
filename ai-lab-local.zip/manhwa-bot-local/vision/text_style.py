"""Lightweight source-style estimation for translated comic lettering.

This is deliberately heuristic and dependency-light. It samples the OCR crop
before inpainting and estimates saturated fill, a contrasting outline, and a
simple two-colour gradient. Plain black/white dialogue returns no override so
the renderer can keep its existing light/dark balloon contrast behaviour.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np


@dataclass(frozen=True)
class TextStyle:
    color: Optional[str] = None
    stroke_color: Optional[str] = None
    stroke_width_ratio: float = 0.0
    gradient_colors: Optional[Tuple[str, str]] = None
    gradient_axis: str = "vertical"  # vertical | horizontal


def _hex(rgb: np.ndarray) -> str:
    values = np.clip(np.rint(rgb), 0, 255).astype(np.uint8).tolist()
    return "#%02X%02X%02X" % tuple(values)


def _median_rgb(rgb: np.ndarray, mask: np.ndarray) -> Optional[np.ndarray]:
    pixels = rgb[mask]
    if pixels.size == 0:
        return None
    return np.median(pixels.astype(np.float32), axis=0)


def detect_text_style(img_bgr: np.ndarray, box: Tuple[int, int, int, int],
                      source_height: float = 0.0) -> Optional[TextStyle]:
    """Estimate source lettering style in an OCR crop (BGR image, xywh box).

    The detector keeps neutral monochrome dialogue on the normal auto-colour
    path. For stylised lettering it returns the dominant fill colour, a clear
    adjacent outline colour, and (when well-separated) a two-stop gradient.
    """
    if img_bgr is None or img_bgr.size == 0:
        return None
    H, W = img_bgr.shape[:2]
    x, y, w, h = (int(v) for v in box)
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(W, x + w), min(H, y + h)
    if x1 - x0 < 8 or y1 - y0 < 8:
        return None
    crop = img_bgr[y0:y1, x0:x1]
    if crop.ndim == 2:
        crop = cv2.cvtColor(crop, cv2.COLOR_GRAY2BGR)
    if crop.ndim != 3 or crop.shape[2] < 3:
        return None

    ch, cw = crop.shape[:2]
    bgr = crop[..., :3]
    rgb = bgr[..., ::-1].copy()
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    sat = hsv[..., 1].astype(np.float32)
    lum = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)

    # The outer band is mostly balloon/background because erase_box includes
    # a small OCR margin. A robust median tolerates a few glyph pixels there.
    band = max(2, min(ch, cw) // 6)
    ring = np.zeros((ch, cw), dtype=bool)
    ring[:band, :] = ring[-band:, :] = True
    ring[:, :band] = ring[:, -band:] = True
    bg_rgb = np.median(rgb[ring].astype(np.float32), axis=0)
    bg_sat = float(np.median(sat[ring]))
    diff = np.linalg.norm(rgb.astype(np.float32) - bg_rgb[None, None, :], axis=2)
    foreground = diff > 38.0
    if int(foreground.sum()) < 5:
        return None

    eroded3 = cv2.erode(foreground.astype(np.uint8), np.ones((3, 3), np.uint8), iterations=1) > 0
    eroded5 = cv2.erode(foreground.astype(np.uint8), np.ones((5, 5), np.uint8), iterations=1) > 0
    # A stronger erosion often removes a thin outline while retaining the fill;
    # fall back for small/thin lettering where it would erase the glyph.
    if int(eroded5.sum()) >= max(3, int(foreground.sum() * 0.08)):
        core = eroded5
    elif int(eroded3.sum()) >= max(3, int(foreground.sum() * 0.12)):
        core = eroded3
    else:
        core = foreground
    core_sat = core & (sat >= max(50.0, bg_sat + 18.0)) & (diff > 32.0)
    color_count = int(core_sat.sum())
    color_style = color_count >= max(4, int(core.sum() * 0.10))
    fill_rgb = _median_rgb(rgb, core_sat) if color_style else None

    # If a large neutral centre is surrounded by a vivid colour, treat the
    # neutral pixels as the fill and the vivid band as a coloured outline.
    neutral_core = core & (sat < 48.0) & (diff > 32.0)
    neutral_count = int(neutral_core.sum())
    neutral_rgb = _median_rgb(rgb, neutral_core)
    neutral_lum = float(np.median(lum[neutral_core])) if neutral_count else 255.0
    neutral_fill = (color_style and neutral_count >= max(4, int(color_count * 0.80))
                    and (neutral_lum < 85.0 or neutral_lum > 215.0))
    neutral_outline_rgb = None
    if neutral_fill:
        neutral_outline_rgb = _median_rgb(rgb, core_sat)
        color_style = False
        fill_rgb = None

    # Estimate a two-stop fill only when saturated pixels clearly change colour
    # across the text; otherwise keep the stable single-colour median.
    gradient = None
    gradient_axis = "vertical"
    if color_style:
        best_distance = 0.0
        for axis in ("vertical", "horizontal"):
            coords = np.where(core_sat)[0 if axis == "vertical" else 1]
            split = (float(coords.min()) + float(coords.max())) / 2.0
            first_mask = core_sat & ((np.indices(core_sat.shape)[0 if axis == "vertical" else 1]) <= split)
            second_mask = core_sat & ~first_mask
            first_count, second_count = int(first_mask.sum()), int(second_mask.sum())
            if first_count < 4 or second_count < 4:
                continue
            first_rgb = _median_rgb(rgb, first_mask)
            second_rgb = _median_rgb(rgb, second_mask)
            if first_rgb is None or second_rgb is None:
                continue
            distance = float(np.linalg.norm(first_rgb - second_rgb))
            if distance > max(48.0, best_distance):
                best_distance = distance
                gradient = (_hex(first_rgb), _hex(second_rgb))
                gradient_axis = axis
        if best_distance < 48.0:
            gradient = None

    # A contrasting band next to the fill is a useful cue for outline/sticker
    # lettering. Avoid treating the balloon itself as an outline by considering
    # only foreground edge pixels adjacent to the eroded fill core.
    dilated_core = cv2.dilate(core.astype(np.uint8), np.ones((5, 5), np.uint8), iterations=1) > 0
    boundary = foreground & dilated_core & ~core
    stroke_color = None
    if neutral_outline_rgb is not None and neutral_rgb is not None:
        if float(np.linalg.norm(neutral_outline_rgb - neutral_rgb)) > 52.0:
            stroke_color = _hex(neutral_outline_rgb)
    if int(boundary.sum()) >= 3:
        dark_edge = boundary & (lum < 85.0)
        bright_edge = boundary & (lum > 215.0) & (diff > 50.0)
        edge_sat = boundary & (sat > max(55.0, bg_sat + 20.0))
        core_rgb = _median_rgb(rgb, core)
        choices = []
        # Neutral antialiasing can look like a black/white border, so only use
        # these grayscale cues around a detected coloured fill.
        if color_style:
            for edge_mask, candidate in ((dark_edge, np.asarray([23, 23, 23], dtype=np.float32)),
                                         (bright_edge, np.asarray([255, 255, 255], dtype=np.float32))):
                if int(edge_mask.sum()) < 3 or core_rgb is None:
                    continue
                edge_rgb = _median_rgb(rgb, edge_mask)
                if edge_rgb is not None and float(np.linalg.norm(edge_rgb - core_rgb)) > 48.0:
                    choices.append((int(edge_mask.sum()), edge_mask, candidate))
        if int(edge_sat.sum()) >= 4 and core_rgb is not None:
            edge_rgb = _median_rgb(rgb, edge_sat)
            if edge_rgb is not None and float(np.linalg.norm(edge_rgb - core_rgb)) > 52.0:
                choices.append((int(edge_sat.sum()), edge_sat, edge_rgb))
        if choices:
            count, _chosen_mask, chosen_rgb = max(choices, key=lambda item: item[0])
            if count >= max(3, int(boundary.sum() * 0.08)):
                stroke_color = chosen_rgb if isinstance(chosen_rgb, str) else _hex(chosen_rgb)

    # A plain monochrome fill should use the existing dark/light balloon logic.
    if not color_style and stroke_color is None:
        return None

    src_h = max(8.0, float(source_height or h))
    # Roughly preserve a 1–2 px source outline without letting it dominate
    # small translated lettering.
    stroke_ratio = min(0.12, max(0.035, 1.5 / src_h)) if stroke_color else 0.0
    # Do not add a noisy auto-outline to extremely tiny OCR crops.
    if stroke_color and min(ch, cw) < 9:
        stroke_ratio = 0.04

    return TextStyle(
        color=_hex(fill_rgb) if fill_rgb is not None else None,
        stroke_color=stroke_color,
        stroke_width_ratio=stroke_ratio,
        gradient_colors=gradient,
        gradient_axis=gradient_axis,
    )
