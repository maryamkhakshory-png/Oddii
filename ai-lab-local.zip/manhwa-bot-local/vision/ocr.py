"""لایه‌ی OCR با پشتیبانی از چند موتور مختلف (افزونه‌محور).

پیش‌فرض: RapidOCR (مدل‌های ONNX سبک، بدون نیاز به PyTorch و GPU)
اگر نصب نباشد، به ترتیب سراغ PaddleOCR / EasyOCR / Tesseract می‌رویم.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

import cv2
import numpy as np

from core.utils import resize_max


@dataclass
class OcrBox:
    """یک خط/کلمه‌ی شناسایی‌شده روی تصویر."""

    box: np.ndarray  # (4,2) مختصات چهارگوش
    text: str
    conf: float

    @property
    def bbox(self) -> Tuple[int, int, int, int]:
        xs, ys = self.box[:, 0], self.box[:, 1]
        x0, x1 = int(xs.min()), int(xs.max())
        y0, y1 = int(ys.min()), int(ys.max())
        return x0, y0, max(1, x1 - x0), max(1, y1 - y0)

    @property
    def center(self) -> Tuple[float, float]:
        return float(self.box[:, 0].mean()), float(self.box[:, 1].mean())

    @property
    def height(self) -> float:
        return float(self.box[:, 1].max() - self.box[:, 1].min())


class OcrEngine:
    """قراردادِ مشترکِ همه‌ی موتورهای OCR."""

    name = "base"

    def read(self, img: np.ndarray) -> List[OcrBox]:  # pragma: no cover
        raise NotImplementedError


class RapidOcrEngine(OcrEngine):
    """RapidOCR بر پایه ONNXRuntime — سبک، آفلاین، مناسب CPU ضعیف."""

    name = "rapid"

    def __init__(self, langs: Sequence[str] = ("en",), min_conf: float = 0.45):
        self.langs = list(langs)
        self.min_conf = min_conf
        self._ocr = None

    def _load(self):
        if self._ocr is None:
            from rapidocr_onnxruntime import RapidOCR

            try:
                self._ocr = RapidOCR()
            except TypeError:
                self._ocr = RapidOCR(lang=self.langs[0]) if self.langs else RapidOCR()
        return self._ocr

    def read(self, img: np.ndarray) -> List[OcrBox]:
        engine = self._load()
        res = engine(img)
        if isinstance(res, tuple):
            res = res[0]
        if isinstance(res, dict):
            res = res.get("result") or res.get("texts") or []
        if not res:
            return []
        out: List[OcrBox] = []
        for item in res:
            try:
                box, text, score = item[0], item[1], float(item[2])
            except Exception:
                continue
            text = (text or "").strip()
            if not text or score < self.min_conf:
                continue
            out.append(OcrBox(box=np.asarray(box, dtype=np.float32), text=text, conf=score))
        return out


class PaddleOcrEngine(OcrEngine):
    name = "paddle"

    def __init__(self, langs=("en",), min_conf: float = 0.45):
        self.langs, self.min_conf, self._ocr = list(langs), min_conf, None

    def _load(self):
        if self._ocr is None:
            from paddleocr import PaddleOCR

            self._ocr = PaddleOCR(use_angle_cls=False, lang=self.langs[0], show_log=False)
        return self._ocr

    def read(self, img: np.ndarray) -> List[OcrBox]:
        res = self._load().ocr(img, cls=False)
        out = []
        for line in res or []:
            for item in line or []:
                try:
                    box, (text, score) = item[0], item[1]
                except Exception:
                    continue
                if score < self.min_conf or not str(text).strip():
                    continue
                out.append(OcrBox(np.asarray(box, dtype=np.float32), str(text).strip(), float(score)))
        return out


class EasyOcrEngine(OcrEngine):
    name = "easy"

    def __init__(self, langs=("en",), min_conf: float = 0.45):
        self.langs, self.min_conf, self._r = list(langs), min_conf, None

    def _load(self):
        if self._r is None:
            import easyocr

            self._r = easyocr.Reader(self.langs, gpu=False, verbose=False)
        return self._r

    def read(self, img: np.ndarray) -> List[OcrBox]:
        res = self._load().readtext(img)
        out = []
        for box, text, score in res or []:
            if float(score) < self.min_conf or not str(text).strip():
                continue
            pts = np.asarray(box, dtype=np.float32).reshape(-1, 2)
            out.append(OcrBox(pts, str(text).strip(), float(score)))
        return out


class NullOcrEngine(OcrEngine):
    """موتور خنثی برای زمانی که OCR نصب نیست (فقط برای تست خط لوله)."""

    name = "none"

    def read(self, img: np.ndarray) -> List[OcrBox]:
        return []


def build_ocr(engine: str = "rapid", langs=("en",), min_conf: float = 0.45) -> OcrEngine:
    engine = (engine or "rapid").lower()
    table = {
        "rapid": RapidOcrEngine,
        "paddle": PaddleOcrEngine,
        "easy": EasyOcrEngine,
        "none": NullOcrEngine,
    }
    order = [engine] + [e for e in ("rapid", "paddle", "easy", "none") if e != engine]
    last_err: Optional[Exception] = None
    for name in order:
        try:
            eng = table[name](langs=langs, min_conf=min_conf)
            if name != "none":
                eng._load()  # زودتر بفهمیم نصب است یا نه
            return eng
        except Exception as e:  # نصب نیست → بعدی
            last_err = e
            continue
    raise RuntimeError(f"هیچ موتور OCR ای پیدا نشد: {last_err}")


# ------------------------------------------------------------------ کمکی‌ها
def group_boxes(boxes: Sequence[OcrBox], gap: int = 12) -> List[List[OcrBox]]:
    """دسته‌بندی کادرهای OCR به بلوک‌های متنی.

    معیار: دو کادر به یک بلوک تعلق دارند اگر
      * فاصله‌ی عمودی‌شان از حدودِ یک خط بیشتر نباشد، و
      * بازه‌ی افقی‌شان هم‌پوشانیِ معناداری داشته باشد
    """
    boxes = sorted(boxes, key=lambda b: (b.bbox[1], b.bbox[0]))
    groups: List[List[OcrBox]] = []
    for b in boxes:
        x, y, w, h = b.bbox
        placed = False
        for g in groups:
            gx = min(i.bbox[0] for i in g)
            gy = min(i.bbox[1] for i in g)
            gw = max(i.bbox[0] + i.bbox[2] for i in g) - gx
            gh = max(i.bbox[1] + i.bbox[3] for i in g) - gy
            line = max(gh, h, 8)
            vgap = y - (gy + gh)
            if vgap > line * 0.95 or (y + h) < gy - line * 0.95:
                continue
            # هم‌پوشانی افقی
            ov = min(x + w, gx + gw) - max(x, gx)
            if ov <= 0.25 * min(w, gw):
                continue
            g.append(b)
            placed = True
            break
        if not placed:
            groups.append([b])
    return groups


def union_bbox(boxes: Sequence[OcrBox], pad: int = 4) -> Tuple[int, int, int, int]:
    x0 = min(b.bbox[0] for b in boxes)
    y0 = min(b.bbox[1] for b in boxes)
    x1 = max(b.bbox[0] + b.bbox[2] for b in boxes)
    y1 = max(b.bbox[1] + b.bbox[3] for b in boxes)
    return x0 - pad, y0 - pad, (x1 - x0) + 2 * pad, (y1 - y0) + 2 * pad


def merge_text(boxes: Sequence[OcrBox]) -> str:
    """چسباندن متن چند کادر به هم: خط‌ها از بالا به پایین، داخل خط چپ به راست."""
    if not boxes:
        return ""
    boxes = sorted(boxes, key=lambda b: (b.bbox[1], b.bbox[0]))
    lines: List[List[OcrBox]] = []
    for b in boxes:
        if not lines:
            lines.append([b])
            continue
        ref = lines[-1][0]
        if abs(b.bbox[1] - ref.bbox[1]) <= max(6, 0.6 * ref.bbox[3]):
            lines[-1].append(b)
        else:
            lines.append([b])
    out = []
    for line in lines:
        out.append(" ".join(x.text for x in sorted(line, key=lambda z: z.bbox[0])))
    return "\n".join(out).strip()


def prepare_for_ocr(crop: np.ndarray, scale: float, max_side: int = 1600,
                    max_pixels: int = 5_000_000, min_side: int = 740) -> Tuple[np.ndarray, float]:
    """آماده‌سازی یک برش برای OCR: اندازه‌ی بهینه.

    سه محدودیت را همزمان رعایت می‌کند:
      * ضلعِ کوچک از min_side کمتر نشود (متن درشت بماند)
      * تعداد پیکسل‌ها از max_pixels بیشتر نشود (سرعت روی CPU ضعیف)
      * ضلعِ بزرگ از max_side بیشتر نشود
    """
    scale = max(0.5, float(scale))
    if crop.size == 0:
        return crop, 1.0
    h, w = crop.shape[:2]
    s = scale
    if min(h, w) * s < min_side:
        s = min_side / max(1.0, min(h, w))
    if (h * s) * (w * s) > max_pixels:
        s = max(0.25, (max_pixels / float(h * w)) ** 0.5)
    if max(h, w) * s > max_side * 1.6:  # سقف سخت برای اطمینان
        s = min(s, (max_side * 1.6) / max(h, w))
    img = crop
    if abs(s - 1.0) > 0.02:
        img = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)
    return img, s


def box_iou(a: "OcrBox", b: "OcrBox") -> float:
    ax, ay, aw, ah = a.bbox
    bx, by, bw, bh = b.bbox
    x0, y0 = max(ax, bx), max(ay, by)
    x1, y1 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    iw, ih = max(0, x1 - x0), max(0, y1 - y0)
    inter = iw * ih
    if inter == 0:
        return 0.0
    return inter / max(1.0, aw * ah + bw * bh - inter)


def dedupe_boxes(boxes: Sequence[OcrBox], iou_thr: float = 0.55) -> List[OcrBox]:
    """حذف کادرهای تکراری (مثلاً از هم‌پوشانیِ کاشی‌ها در صفحه‌های بلند)."""
    out: List[OcrBox] = []
    for b in sorted(boxes, key=lambda z: -z.conf):
        if all(box_iou(b, o) < iou_thr for o in out):
            out.append(b)
    return out
