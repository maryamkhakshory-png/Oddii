"""پاک کردن متن اصلی از روی تصویر (بدون مدل یادگیری عمیق).

روش:
    ماسکِ «مرکب» را از روی تفاوت روشنایی با پس‌زمینه می‌سازیم، مؤلفه‌های خیلی بزرگ
    (نقاشی/خطِ دور بالن) را حذف می‌کنیم و بعد بسته به یکنواختیِ پس‌زمینه،
    یا با رنگِ غالب پُر می‌کنیم (برای بالن‌های سفید) یا با cv2.inpaint بازسازی
    می‌کنیم (برای متن روی نقاشی).
"""

from __future__ import annotations

from typing import Tuple

import cv2
import numpy as np


def text_mask(crop: np.ndarray, offset: int = 42, dilate: int = 3) -> Tuple[np.ndarray, bool]:
    """ساخت ماسک پیکسل‌های متن. خروجی: (ماسک uint8 0/255، پس‌زمینه روشن است؟)"""
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop
    if gray.size == 0:
        return np.zeros(gray.shape, np.uint8), True

    med = float(np.median(gray))
    bright_bg = med > 118
    if bright_bg:
        mask = (gray < max(0, med - offset)).astype(np.uint8) * 255
    else:
        mask = (gray > min(255, med + offset)).astype(np.uint8) * 255

    # حاشیه‌ی بالن را کنار بگذار (چند پیکسل دور تا دور)
    border = max(2, int(min(crop.shape[:2]) * 0.06))
    inner = np.zeros(gray.shape, np.uint8)
    inner[border:-border, border:-border] = 255
    mask = cv2.bitwise_and(mask, inner)

    # فقط مؤلفه‌های کوچک (حروف) را نگه دار؛ لکه‌های بزرگ نقاشی‌اند نه متن
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    region_area = float(gray.shape[0] * gray.shape[1])
    keep = np.zeros(mask.shape, np.uint8)
    for i in range(1, n):
        a = stats[i, cv2.CC_STAT_AREA]
        hh = stats[i, cv2.CC_STAT_HEIGHT]
        ww = stats[i, cv2.CC_STAT_WIDTH]
        if a < 6:
            continue
        if a > 0.30 * region_area:
            continue
        if hh > 0.95 * gray.shape[0] and ww > 0.95 * gray.shape[1]:
            continue
        keep[labels == i] = 255

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    keep = cv2.morphologyEx(keep, cv2.MORPH_CLOSE, k)
    if dilate > 0:
        keep = cv2.dilate(keep, k, iterations=int(dilate))
    return keep, bright_bg


def clean_region(crop: np.ndarray, cfg) -> Tuple[np.ndarray, np.ndarray]:
    """پاک کردن متن از یک برش. خروجی: (تصویر تمیز، ماسک استفاده‌شده)"""
    if crop.size == 0:
        return crop, np.zeros(crop.shape[:2], np.uint8)
    mask, bright_bg = text_mask(
        crop, offset=int(getattr(cfg, "threshold_offset", 42)), dilate=int(getattr(cfg, "dilate", 3))
    )
    if mask.sum() == 0:
        return crop, mask

    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if crop.ndim == 3 else crop
    bg_pixels = gray[mask == 0]
    bg_color = float(np.median(bg_pixels)) if bg_pixels.size else float(np.median(gray))
    uniform = float(np.std(bg_pixels)) < 20 if bg_pixels.size else True

    method = str(getattr(cfg, "method", "auto"))
    if method == "auto":
        method = "fill" if uniform else "inpaint"

    if method == "fill":
        filled = crop.copy()
        color = 255 if bright_bg else bg_color
        if crop.ndim == 3:
            filled[mask > 0] = (color, color, color)
        else:
            filled[mask > 0] = color
        out = filled
    else:
        radius = int(getattr(cfg, "radius", 5))
        out = cv2.inpaint(crop, mask, radius, cv2.INPAINT_TELEA)

    # لبه‌ها را نرم کن که ردّ مستطیل نماند
    alpha = cv2.GaussianBlur((mask > 0).astype(np.float32), (0, 0), 1.2)[..., None]
    out = (crop.astype(np.float32) * (1 - alpha) + out.astype(np.float32) * alpha).astype(np.uint8)
    return out, mask
