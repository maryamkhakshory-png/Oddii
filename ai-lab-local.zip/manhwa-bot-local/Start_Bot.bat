@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please double-click Setup_Windows.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" scripts\start_local.py
if errorlevel 1 pause
