"""ربات تلگرام — با ارتباطِ مستقیم به Bot API (بدون واسطه‌ی سنگین).

چرا بدون python-telegram-bot؟
    چون با یک حلقه‌ی ساده و شفاف، هر پیامی که می‌رسد در لاگ دیده می‌شود و اگر
    خطایی رخ بدهد همان‌جا ثبت می‌شود — عیب‌یابی روی سرورهای کوچک خیلی راحت‌تر است.

دستورها:
    /start  /help            راهنما
    /mode                    تغییر لحن (عامیانه/متعادل/رسمی)
    /lang                    تغییر زبان مبدأ
    /say <متن>               تبدیل متن به voice note فارسی (Piper)
    /voice on|off            پاسخِ صوتیِ خودکار به متن
    /font                    مشاهده/تنظیم فونتِ همین چت
    /menu                    نمایش دکمه‌های سریع
    /code <درخواست>          نوشتن کد با مدلِ محلی
    /ping                    بررسیِ فوریِ زنده بودن
    /status                  وضعیت سیستم
    /id                      شناسه‌ی چتِ تو

فایل‌ها:
    عکس              → همان صفحه با بالن‌های فارسی
    ZIP / CBZ        → کل فصل، زیپِ ترجمه‌شده
    TTF / OTF        → فعال کردن فونتِ اختصاصیِ چت
    voice            → تبدیل به متنِ فارسی و پاسخ
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

os.environ.setdefault("MALLOC_ARENA_MAX", "2")
os.environ.setdefault("OMP_NUM_THREADS", "2")

from core.config import load_config  # noqa: E402
from core.logging_setup import setup  # noqa: E402
from core.utils import (ARCHIVE_EXTS, IMAGE_EXTS, human_bytes,  # noqa: E402
                        imwrite)

CFG = load_config()
LOG = setup(CFG.log_level, name="ai-lab.bot")

API = "https://api.telegram.org/bot{token}/{method}"
FILE_API = "https://api.telegram.org/file/bot{token}/{path}"

REGISTERS = {"عامیانه": "colloquial", "متعادل": "neutral", "رسمی": "formal"}
FONT_EXTS = {".ttf", ".otf", ".ttc"}
LANGS = {
    "انگلیسی": "eng_Latn", "ژاپنی": "jpn_Jpan", "کره‌ای": "kor_Hang",
    "چینی": "zho_Hans", "عربی": "ara_Arab", "فرانسوی": "fra_Latn",
    "آلمانی": "deu_Latn", "اسپانیایی": "spa_Latn", "ترکی": "tur_Latn",
}


def _inline_keyboard(rows):
    return {"inline_keyboard": rows}


MENU_ROWS = [
    [{"text": "🖼 ترجمه‌ی عکس", "callback_data": "menu:photo"},
     {"text": "📚 ترجمه‌ی فصل", "callback_data": "menu:chapter"}],
    [{"text": "💬 گفت‌وگو", "callback_data": "menu:chat"},
     {"text": "🎙 ویس", "callback_data": "menu:voice"}],
    [{"text": "🎭 انتخابِ لحن", "callback_data": "menu:mode"},
     {"text": "🌐 زبانِ مبدأ", "callback_data": "menu:lang"}],
    [{"text": "🔤 فونت", "callback_data": "menu:font"},
     {"text": "🔊 صدایِ خودکار", "callback_data": "menu:voice_toggle"}],
    [{"text": "📊 وضعیت", "callback_data": "menu:status"},
     {"text": "ℹ️ راهنما", "callback_data": "menu:help"}],
]


# ------------------------------------------------------------------ کلاینت
class Telegram:
    def __init__(self, token: str, timeout: int = 60):
        self.token = token
        self.timeout = timeout
        self.session = requests.Session()
        self.lock = threading.Lock()
        # تلاشِ دوباره در سطحِ اتصال (نه در سطحِ درخواستِ منطقی)
        try:
            from requests.adapters import HTTPAdapter
            from urllib3.util.retry import Retry

            retry = Retry(total=1, connect=1, read=1, backoff_factor=0.4,
                          status_forcelist=(502, 503, 504),
                          allowed_methods=frozenset(["GET", "POST"]))
            self.session.mount("https://", HTTPAdapter(max_retries=retry))
            self.session.mount("http://", HTTPAdapter(max_retries=retry))
        except Exception:
            pass

    def call(self, method: str, data: dict | None = None, files: dict | None = None,
             timeout: int | None = None, retries: int = 2) -> dict:
        """فراخوانیِ Bot API با تلاشِ دوباره روی خطاهای شبکه.

        روی اینترنتِ ناپایدار، `getUpdates` گاهی ReadTimeout می‌دهد؛
        بدون تلاشِ دوباره، هر بار تا نیم دقیقه پیام‌ها معطل می‌مانند.
        """
        url = API.format(token=self.token, method=method)
        last = ""
        for attempt in range(retries + 1):
            try:
                with self.lock:      # نشست بین نخِ اصلی و نخِ کار مشترک است
                    if files:
                        r = self.session.post(url, data=data or {}, files=files,
                                              timeout=timeout or self.timeout)
                    else:
                        r = self.session.post(url, json=data or {},
                                              timeout=timeout or self.timeout)
                out = r.json() if r.content else {}
                if out.get("ok"):
                    return out
                # خطایِ تلگرام (مثلاً ۴۲۹ یا آرگومانِ غلط): تلاشِ دوباره فایده ندارد
                LOG.warning(f"Telegram {method}: {out.get('error_code')} "
                            f"{out.get('description')}")
                return out
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                if attempt < retries:
                    time.sleep(0.6 * (attempt + 1))
                    continue
                LOG.warning(f"Telegram {method} خطا: {last}")
                return {"ok": False, "error": last}
        return {"ok": False, "error": last}

    # ---- فرستادن ----
    def send_message(self, chat_id, text, reply_markup=None):
        if not text:
            return None
        data = {"chat_id": chat_id, "text": text[:4000]}
        if reply_markup:
            data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        return self.call("sendMessage", data)

    def edit_message(self, chat_id, message_id, text):
        return self.call("editMessageText",
                         {"chat_id": chat_id, "message_id": message_id, "text": text[:4000]})

    def send_photo(self, chat_id, path, caption=""):
        with open(path, "rb") as f:
            return self.call("sendPhoto", {"chat_id": chat_id, "caption": caption[:1000]},
                             files={"photo": (Path(path).name, f)}, timeout=180)

    def send_document(self, chat_id, path, caption=""):
        with open(path, "rb") as f:
            return self.call("sendDocument", {"chat_id": chat_id, "caption": caption[:1000]},
                             files={"document": (Path(path).name, f)}, timeout=300)

    def send_audio(self, chat_id, path, title=""):
        with open(path, "rb") as f:
            return self.call("sendAudio", {"chat_id": chat_id, "title": title[:200]},
                             files={"audio": (Path(path).name, f)}, timeout=180)

    def send_voice(self, chat_id, path, caption=""):
        with open(path, "rb") as f:
            return self.call("sendVoice", {"chat_id": chat_id,
                                            "caption": caption[:1000]},
                             files={"voice": (Path(path).name, f)}, timeout=180)

    def delete_message(self, chat_id, message_id):
        return self.call("deleteMessage", {"chat_id": chat_id,
                                            "message_id": message_id}, timeout=15)

    def send_action(self, chat_id, action="typing"): 
        return self.call("sendChatAction", {"chat_id": chat_id, "action": action}, timeout=15)

    def answer_callback(self, callback_id, text=""):
        return self.call("answerCallbackQuery",
                         {"callback_query_id": callback_id, "text": text[:180]}, timeout=15)

    def get_file_path(self, file_id) -> str | None:
        out = self.call("getFile", {"file_id": file_id}, timeout=30)
        return ((out.get("result") or {}).get("file_path") if out.get("ok") else None)

    def download_file(self, file_id, dest: Path) -> bool:
        fp = self.get_file_path(file_id)
        if not fp:
            return False
        url = FILE_API.format(token=self.token, path=fp)
        try:
            with self.session.get(url, stream=True, timeout=300) as r:
                r.raise_for_status()
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(dest, "wb") as f:
                    for chunk in r.iter_content(1 << 16):
                        f.write(chunk)
            return True
        except Exception as e:
            LOG.error(f"دانلود فایل ناموفق: {e}")
            return False


# ------------------------------------------------------------------ هسته
class Bot:
    def __init__(self, token: str):
        self.tg = Telegram(token)
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="job")
        self.state = {"llm": None, "llms": {}, "history": {},
                      "last_texts": None, "last_regions": None,
                      "started": time.time(), "register": CFG.translation.register,
                      "busy": False}

    # ------------------------------------------------------------ وضعیت
    # نکته‌ی مهم: این ربات «خودش» هیچ مدل سنگینی را بار نمی‌کند.
    # کارهای سنگین در پردازه‌های جدا اجرا می‌شوند (jobs/run_job.py) تا
    # حافظه بعد از هر فاز کاملاً آزاد شود و ربات همیشه پاسخ‌گو بماند.

    def llm(self):
        if self.state["llm"] is None:
            from llm.local_client import LocalLLM
            self.state["llm"] = LocalLLM.from_config(CFG.llm)
        return self.state["llm"]

    def _llm_for_chat(self, _chat_id):
        # همه‌ی چت‌ها از مدلِ محلیِ همین میزبان استفاده می‌کنند؛ هیچ کلیدی ذخیره نمی‌شود.
        return self.llm()

    # ---- حلقه‌ی اصلی ----
    def run(self):
        me = self.tg.call("getMe", timeout=20).get("result") or {}
        LOG.info(f"ربات آماده: @{me.get('username')} ({me.get('first_name')})")
        offset = 0
        errors = 0
        last_seen = time.time()
        while True:
            try:
                # timeout کوتاه‌تر = اگر اینترنت قطع شود، زودتر برمی‌گردیم
                out = self.tg.call("getUpdates",
                                   {"offset": offset, "timeout": 15,
                                    "allowed_updates": ["message", "callback_query"]},
                                   timeout=28)
                if not out.get("ok"):
                    errors += 1
                    time.sleep(min(10, 1 + errors))
                    continue
                errors = 0
                for upd in out.get("result", []):
                    offset = max(offset, int(upd["update_id"]) + 1)
                    last_seen = time.time()
                    try:
                        self.on_update(upd)
                    except Exception:
                        LOG.error("خطا در پردازش پیام:\n" + traceback.format_exc())
                # ضربانِ حیات: ثابت می‌کند حلقه زنده است، حتی اگر کسی پیام ندهد
                if time.time() - last_seen > 120:
                    last_seen = time.time()
                    LOG.info(f"زنده‌ام؛ {len(self.executor._threads)} نخِ کار، "
                             f"در انتظار پیام")
            except KeyboardInterrupt:
                LOG.info("توقف با دستور کاربر.")
                break
            except Exception:
                LOG.error("خطا در حلقه‌ی اصلی:\n" + traceback.format_exc())
                time.sleep(2)

    # ---- توزیع پیام ----
    def on_update(self, upd: dict):
        if "callback_query" in upd:
            self.on_callback(upd["callback_query"])
            return
        msg = upd.get("message") or upd.get("edited_message")
        if not msg:
            return
        chat_id = (msg.get("chat") or {}).get("id")
        user = (msg.get("from") or {}).get("first_name", "")
        text = (msg.get("text") or "").strip()
        # کلیدِ API که از طریق /connect می‌آید هرگز در لاگ ثبت نشود.
        lower_text = text.lower()
        safe_text = ("[کلید API پنهان شد]"
                     if lower_text.startswith("/connect") or "sk-or-v1-" in lower_text
                     else text[:60])
        LOG.info(f"← پیام از {user} ({chat_id}): {safe_text!r}"
                 f"{' [عکس]' if msg.get('photo') else ''}"
                 f"{' [فایل]' if msg.get('document') else ''}"
                 f"{' [صدا]' if (msg.get('voice') or msg.get('audio')) else ''}")

        if msg.get("photo") or msg.get("document"):
            queued = self.state.get("busy", False)
            if msg.get("photo"):
                fn = self.job_photo
            else:
                filename = (msg.get("document") or {}).get("file_name", "")
                fn = (self.job_font_upload if Path(filename).suffix.lower() in FONT_EXTS
                      else self.job_document)
            self.executor.submit(fn, chat_id, msg)
            if queued:
                self.tg.send_message(
                    chat_id, "⏳ یک کار دیگر در حال انجام است؛ به‌نوبت انجامش می‌دهم.")
        elif msg.get("voice") or msg.get("audio"):
            self.executor.submit(self.job_voice, chat_id, msg)
        elif text.startswith("/"): 
            self.on_command(chat_id, text, msg)
        elif text:
            self.executor.submit(self.job_text, chat_id, text)
        else:
            self.tg.send_message(chat_id, "عکس یا فایلِ فصل (ZIP/CBZ) بفرست تا ترجمه‌اش کنم.")

    def on_command(self, chat_id, text, msg):
        parts = text.split(None, 1)
        cmd = parts[0].split("@")[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""
        if cmd in {"/connect", "/disconnect"}:
            self.tg.send_message(
                chat_id,
                "💬 این نسخه از مدلِ محلی استفاده می‌کند و API key نمی‌خواهد. "
                "برای دیدنِ وضعیتِ مدل: /status؛ برای گفتگو فقط پیام بفرست.")
            return

        fn = {
            "/start": self.cmd_start, "/menu": self.cmd_menu,
            "/help": self.cmd_help, "/mode": self.cmd_mode,
            "/lang": self.cmd_lang, "/status": self.cmd_status, "/id": self.cmd_id,
            "/say": self.cmd_say, "/code": self.cmd_code, "/texts": self.cmd_texts,
            "/ping": self.cmd_ping, "/font": self.cmd_font,
            "/voice": self.cmd_voice,
        }.get(cmd)
        if fn is None:
            self.tg.send_message(chat_id, "این دستور را نمی‌شناسم. /help را ببین.")
            return
        if cmd in ("/say", "/code"):
            self.executor.submit(self._safe, fn, chat_id, arg)
        else:
            self._safe(fn, chat_id, arg)

    def _safe(self, fn, *args):
        try:
            fn(*args)
        except Exception:
            LOG.error("خطا در اجرای فرمان:\n" + traceback.format_exc())
            try:
                self.tg.send_message(args[0], "⚠️ یک خطای داخلی رخ داد. جزئیات در لاگ ثبت شد.")
            except Exception:
                pass

    def _chat_dir(self, chat_id) -> Path:
        path = CFG.work_dir_path / "bot" / str(chat_id)
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            os.chmod(path, 0o700)
        except OSError:
            pass
        return path

    def _font_settings_path(self, chat_id) -> Path:
        return self._chat_dir(chat_id) / "font.json"

    def _font_path_for_chat(self, chat_id) -> Path:
        try:
            data = json.loads(self._font_settings_path(chat_id).read_text(encoding="utf-8"))
            path = Path(data.get("font_path", ""))
            if path.is_file() and path.suffix.lower() in FONT_EXTS:
                return path
        except Exception:
            pass
        return CFG.font_path

    def _save_font_path(self, chat_id, path: Path | None) -> None:
        settings = self._font_settings_path(chat_id)
        data = {"font_path": str(path.resolve())} if path else {}
        tmp = settings.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(settings)
        os.chmod(settings, 0o600)

    def _voice_settings_path(self, chat_id) -> Path:
        return self._chat_dir(chat_id) / "voice.json"

    def _voice_enabled(self, chat_id) -> bool:
        try:
            data = json.loads(self._voice_settings_path(chat_id).read_text(encoding="utf-8"))
            return bool(data.get("auto_reply", False))
        except Exception:
            return False

    def _save_voice_enabled(self, chat_id, enabled: bool) -> None:
        path = self._voice_settings_path(chat_id)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({"auto_reply": bool(enabled)}, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(path)
        os.chmod(path, 0o600)

    # ---- فرمان‌ها ----
    def cmd_start(self, chat_id, _arg=""):
        self.tg.send_message(
            chat_id,
            "سلام! 👋 من مانها‌گردان هستم.\n"
            "بالن‌های انگلیسی را می‌خوانم، پاک می‌کنم و فارسیِ عامیانه می‌نویسم.\n"
            "چت هم با یک مدلِ محلی انجام می‌شود؛ API key لازم نیست.\n\n"
            "از دکمه‌های زیر استفاده کن یا /menu را بزن:",
            reply_markup=_inline_keyboard(MENU_ROWS))

    def cmd_menu(self, chat_id, _arg=""):
        self.tg.send_message(chat_id, "منوی سریع — یک کار را انتخاب کن:",
                             reply_markup=_inline_keyboard(MENU_ROWS))

    def cmd_help(self, chat_id, _arg=""):
        self.tg.send_message(
            chat_id,
            "📖 راهنما\n"
            "/menu  →  نمایش دکمه‌های سریع\n"
            "/mode  →  انتخاب لحن: عامیانه / متعادل / رسمی\n"
            "/lang  →  انتخاب زبان مبدأ\n"
            "/say <متن>  →  فرستادنِ گفتارِ فارسی\n"
            "/voice on|off  →  پاسخِ صوتیِ خودکار به چت\n"
            "/code <درخواست>  →  نوشتن کد با مدلِ محلی\n"
            "/status  →  وضعیت ربات و مدل‌ها\n"
            "/ping  →  آیا زنده‌ام؟\n"
            "/font  →  فونتِ فعال؛ /font default برای بازگشت\n"
            "/id  →  شناسه‌ی چت\n\n"
            "🎙 ویس بفرست تا متن و پاسخِ صوتی بگیری.\n"
            "📄 عکس بفرست تا همان صفحه ترجمه شود.\n"
            "🗜 ZIP/CBZ بفرست تا کل فصل ترجمه شود.\n"
            "🔤 فایل TTF/OTF را به‌صورت فایل بفرست تا فونتِ شخصی فعال شود.\n"
            "💬 گفت‌وگو کاملاً محلی است؛ متن به سرویسِ چتِ بیرونی فرستاده نمی‌شود.")

    def cmd_mode(self, chat_id, _arg=""):
        rows = [[{"text": k, "callback_data": f"mode:{v}"}] for k, v in REGISTERS.items()]
        self.tg.send_message(chat_id, "لحن ترجمه را انتخاب کن:",
                             reply_markup=_inline_keyboard(rows))

    def cmd_lang(self, chat_id, _arg=""):
        items = list(LANGS.items())
        rows = [[{"text": k, "callback_data": f"lang:{v}"} for k, v in items[i:i + 3]]
                for i in range(0, len(items), 3)]
        self.tg.send_message(chat_id, "زبان مبدأ را انتخاب کن:",
                             reply_markup=_inline_keyboard(rows))

    def cmd_id(self, chat_id, _arg=""):
        self.tg.send_message(chat_id, f"شناسه‌ی چتِ تو: `{chat_id}`")

    def cmd_ping(self, chat_id, _arg=""):
        up = int(time.time() - self.state["started"])
        busy = "یک کار در صف است ⏳" if self.state.get("busy") else "بیکار"
        self.tg.send_message(
            chat_id, f"🏓 پونگ! زنده‌ام ({up // 60} دقیقه، {busy})\n"
                     f"مدل ترجمه فقط هنگام کار، در پردازه‌ای جدا بالا می‌آید.")

    def cmd_voice(self, chat_id, arg=""):
        value = arg.strip().lower()
        if value in {"on", "روشن", "فعال"}:
            self._save_voice_enabled(chat_id, True)
        elif value in {"off", "خاموش", "غیرفعال"}:
            self._save_voice_enabled(chat_id, False)
        enabled = self._voice_enabled(chat_id)
        label = "روشن" if enabled else "خاموش"
        self.tg.send_message(
            chat_id, f"🔊 پاسخِ صوتی برای پیام‌های متنی: {label}\n"
                     "روشن/خاموش: /voice on یا /voice off\n"
                     "پیامِ صوتی را همیشه به متن تبدیل می‌کنم؛ پاسخِ صوتیِ آن هم فرستاده می‌شود.\n"
                     "صدای فعلی Piper است: رایگان و آفلاین.")

    def cmd_font(self, chat_id, arg=""):
        if arg.strip().lower() in {"default", "reset", "پیش‌فرض", "پيش‌فرض"}:
            self._save_font_path(chat_id, None)
            self.tg.send_message(chat_id, "✅ فونتِ پیش‌فرضِ وزیرمتن دوباره فعال شد.")
            return
        active = self._font_path_for_chat(chat_id)
        label = "وزیرمتن (پیش‌فرض)" if active.resolve() == CFG.font_path.resolve() else active.name
        self.tg.send_message(
            chat_id, f"🔤 فونتِ فعال: {label}\n"
                     "برای عوض‌کردن، فایل فونت را با گزینه‌ی «ارسال به‌صورت فایل» بفرست.\n"
                     "فرمت‌های پشتیبانی‌شده: TTF / OTF / TTC\n"
                     "برای برگشت: /font default")

    def cmd_status(self, chat_id, _arg=""):
        up = int(time.time() - self.state["started"])
        try:
            llm = self._llm_for_chat(chat_id)
            llm_txt = (llm.model + " ✅") if llm.available() else "مدل نصب نیست؛ روی میزبان bash setup_env.sh را اجرا کن"
        except Exception:
            llm_txt = "مدلِ محلی نصب نیست؛ روی میزبان bash setup_env.sh را اجرا کن"
        busy = "در حال انجام یک کار" if self.state.get("busy") else "آماده"
        txt = (f"🟢 روشن ({up // 60} دقیقه) — {busy}\n"
               f"🔎 OCR: {CFG.ocr.engine}\n"
               f"🌐 ترجمه: {CFG.translation.engine} "
               f"({CFG.translation.src_lang} → {CFG.translation.tgt_lang})\n"
               f"🎭 لحن: {self.state.get('register')}\n"
               f"🧠 مدل زبانی: {llm_txt}\n"
               f"🔤 فونت: {self._font_path_for_chat(chat_id).name}\n"
               f"🧩 اجرا: هر کار در پردازه‌ی جدا (کم‌مصرف)")
        self.tg.send_message(chat_id, txt)

    def cmd_texts(self, chat_id, _arg=""):
        p = self.state.get("last_texts")
        if not p or not Path(p).exists():
            self.tg.send_message(chat_id, "هنوز فصلی ترجمه نکرده‌ام.")
            return
        self.tg.send_document(chat_id, p, "متن‌های ترجمه‌شده")

    def _send_voice_text(self, chat_id, text, title="پاسخِ صوتی"):
        from speech.tts import speak, telegram_voice_file

        engine = str(getattr(CFG.tts, "engine", "auto"))
        is_wav = engine in ("auto", "piper")
        out = CFG.work_dir_path / "tts" / f"{chat_id}_{int(time.time() * 1000)}.{ 'wav' if is_wav else 'mp3' }"
        path = speak(text, str(out), voice=CFG.tts.voice, engine=engine)
        if not path or not Path(path).is_file() or Path(path).stat().st_size < 100:
            self.tg.send_message(chat_id, "⚠️ تولید صدا ناموفق بود؛ دوباره امتحان کن.")
            return False
        voice_path = telegram_voice_file(path) if str(path).lower().endswith(".wav") else path
        if voice_path:
            sent = self.tg.send_voice(chat_id, voice_path)
        else:
            sent = self.tg.send_document(chat_id, path, title)
        return bool(sent and sent.get("ok"))

    def cmd_say(self, chat_id, arg):
        if not arg:
            self.tg.send_message(chat_id, "چه بگویم؟ مثال: /say سلام، حالت چطوره؟")
            return
        self.tg.send_action(chat_id, "record_voice")
        self._send_voice_text(chat_id, arg, "گفتار فارسی")

    def cmd_code(self, chat_id, arg):
        from llm.skills import write_code

        if not arg:
            self.tg.send_message(chat_id, "چه کدی بنویسم؟")
            return
        llm = self._llm_for_chat(chat_id)
        if not llm.available():
            self.tg.send_message(
                chat_id,
                "🧩 مدلِ محلی هنوز نصب نیست. روی میزبان `bash setup_env.sh` را اجرا کن؛ "
                "کلیدِ سرویسِ بیرونی لازم نیست.")
            return
        self.tg.send_action(chat_id, "typing")
        res = write_code(llm, arg)
        if not res["ok"]:
            self.tg.send_message(chat_id, f"⚠️ {res['error']}")
            return
        self.tg.send_message(chat_id, f"💻 کد:\n\n{res['code'][:3500]}\n\n{res['notes']}")

    def on_callback(self, cb: dict):
        cid = cb.get("id")
        data = cb.get("data") or ""
        msg = cb.get("message") or {}
        chat_id = (msg.get("chat") or {}).get("id")
        message_id = msg.get("message_id")
        self.tg.answer_callback(cid)
        if ":" not in data:
            return
        kind, val = data.split(":", 1)
        if kind == "menu":
            if val == "photo":
                self.tg.send_message(chat_id, "🖼 حالا تصویرِ صفحه را بفرست تا ترجمه‌اش کنم.")
            elif val == "chapter":
                self.tg.send_message(chat_id, "📚 فایلِ فصل را به‌صورت ZIP یا CBZ بفرست.")
            elif val == "chat":
                self.tg.send_message(chat_id, "💬 پیامِ متنی‌ات را بفرست؛ پاسخ با مدلِ محلی ساخته می‌شود.")
            elif val == "voice":
                self.tg.send_message(chat_id, "🎙 یک پیامِ صوتی بفرست؛ آن را متن می‌کنم و پاسخ می‌دهم.")
            elif val == "voice_toggle":
                enabled = not self._voice_enabled(chat_id)
                self._save_voice_enabled(chat_id, enabled)
                self.cmd_voice(chat_id)
            else:
                actions = {
                    "mode": self.cmd_mode, "lang": self.cmd_lang,
                    "font": self.cmd_font, "status": self.cmd_status,
                    "help": self.cmd_help,
                }
                fn = actions.get(val)
                if fn:
                    self._safe(fn, chat_id, "")
            return
        if kind == "mode" and val in REGISTERS.values():
            self.state["register"] = val
            pipe = self.state.get("pipeline")
            if pipe:
                pipe.cfg.translation.register = val
                pipe.colloq.register = val
            label = next((k for k, v in REGISTERS.items() if v == val), val)
            self.tg.edit_message(chat_id, message_id, f"✅ لحن روی «{label}» تنظیم شد.")
        elif kind == "lang" and val in LANGS.values():
            CFG.translation.src_lang = val
            pipe = self.state.get("pipeline")
            if pipe:
                pipe.cfg.translation.src_lang = val
            label = next((k for k, v in LANGS.items() if v == val), val)
            self.tg.edit_message(chat_id, message_id, f"✅ زبان مبدأ: {label}")

    # ---- کارها ----
    def _exec_phase(self, phase: str, job_dir: Path, chat_id: int, timeout: int) -> bool:
        """اجرای یک فاز در پردازه‌ای جدا؛ خروجی‌اش را هم زنده می‌فرستیم."""
        cmd = [sys.executable, "-m", "jobs.run_job", phase, "--job", str(job_dir)]
        env = dict(os.environ)
        env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")
        env["MALLOC_ARENA_MAX"] = "2"
        env["OMP_NUM_THREADS"] = "1"
        env["TOKENIZERS_PARALLELISM"] = "false"
        env["MANHWA_CONFIG"] = str(ROOT / "config.yaml")
        import subprocess

        proc = subprocess.Popen(cmd, cwd=str(ROOT), env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1)
        try:
            for line in proc.stdout:
                line = line.rstrip()
                if not line:
                    continue
                LOG.info(f"[{phase}] {line}")
                # فقط پایانِ هر مرحله را بفرست (اسپم نشود)
                if any(k in line for k in ("تمام شد", "شکست", "خطا در")):
                    try:
                        self.tg.send_message(chat_id, "⏳ " + line.split("] ", 1)[-1])
                    except Exception:
                        pass
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            self.tg.send_message(chat_id, f"⚠️ مرحله‌ی {phase} بیش از {timeout} ثانیه طول کشید.")
            return False
        return proc.returncode == 0

    def _run_job(self, chat_id: int, job_dir: Path, kind: str) -> dict | None:
        """سه فازِ پشت‌سرهم، هر کدام در پردازه‌ی خودش."""
        self.state["busy"] = True
        t0 = time.time()
        try:
            ok = (self._exec_phase("ocr", job_dir, chat_id, 900)
                  and self._exec_phase("translate", job_dir, chat_id, 1800)
                  and self._exec_phase("render", job_dir, chat_id, 900))
            result_path = job_dir / "result.json"
            if not result_path.exists():
                self.tg.send_message(chat_id, "⚠️ خروجی ساخته نشد (جزئیات در لاگ).")
                return None
            result = json.loads(result_path.read_text(encoding="utf-8"))
            result["seconds"] = round(time.time() - t0, 1)
            result["ok"] = result.get("ok") and ok
            return result
        finally:
            self.state["busy"] = False

    def _new_job(self, chat_id: int, src: Path, kind: str) -> Path:
        job_dir = CFG.work_dir_path / "jobs" / f"{chat_id}_{int(time.time())}"
        (job_dir / "out").mkdir(parents=True, exist_ok=True)
        (job_dir / "job.json").write_text(json.dumps(
            {"kind": kind, "src": str(src), "chat_id": chat_id,
             "max_pages": int(getattr(CFG.bot, "max_pages", 60)),
             "font_path": str(self._font_path_for_chat(chat_id).resolve())},
            ensure_ascii=False, indent=2), encoding="utf-8")
        return job_dir

    def _report(self, chat_id: int, job_dir: Path, result: dict) -> None:
        """گزارشِ متنی + فایل‌های خروجی."""
        self.state["last_regions"] = str(job_dir / "regions.json")
        self.state["last_texts"] = str(job_dir / "regions.json")
        try:
            per_page = json.loads((job_dir / "regions.json").read_text(encoding="utf-8"))
            lines = []
            for pg in per_page:
                for r in pg["regions"]:
                    if r.get("translated"):
                        src = " ".join((r.get("source") or "").split())
                        lines.append(f"• {src[:44]} → {r['translated'][:60]}")
            if lines:
                body = "\n".join(lines[:14])
                if len(lines) > 14:
                    body += f"\n… و {len(lines) - 14} بالن دیگر"
                self.tg.send_message(chat_id, body[:3500])
        except Exception:
            LOG.debug(traceback.format_exc())

    def job_voice(self, chat_id, msg):
        """گفتارِ کاربر را محلی به متن تبدیل می‌کند و جواب را هم صوتی می‌فرستد."""
        try:
            item = msg.get("voice") or msg.get("audio") or {}
            size = int(item.get("file_size") or 0)
            if size > 19 * 1024 * 1024:
                self.tg.send_message(chat_id, "فایل صوتی باید کمتر از ۱۹ مگابایت باشد.")
                return
            self.tg.send_action(chat_id, "typing")
            self.tg.send_message(chat_id, "🎧 صدایت را به متن تبدیل می‌کنم؛ بارِ اول مدلِ رایگان دانلود می‌شود...")
            work = self._chat_dir(chat_id)
            ext = Path(item.get("file_name") or "voice.oga").suffix.lower()
            if ext not in {".oga", ".ogg", ".opus", ".mp3", ".m4a", ".wav", ".webm"}:
                ext = ".oga"
            stamp = int(time.time() * 1000)
            audio_path = work / f"voice_{stamp}{ext}"
            transcript_path = work / f"voice_{stamp}.json"
            if not self.tg.download_file(item.get("file_id"), audio_path):
                self.tg.send_message(chat_id, "⚠️ دریافتِ پیامِ صوتی ناموفق بود.")
                return

            cmd = [sys.executable, "-m", "speech.stt_worker", str(audio_path),
                   "--out", str(transcript_path), "--model", "small", "--language", "fa"]
            env = dict(os.environ)
            env.update({"PYTHONPATH": str(ROOT) + os.pathsep + env.get("PYTHONPATH", ""),
                        "OMP_NUM_THREADS": "1", "TOKENIZERS_PARALLELISM": "false"})
            proc = subprocess.run(cmd, cwd=str(ROOT), env=env, capture_output=True,
                                  text=True, timeout=900)
            if proc.returncode != 0 or not transcript_path.exists():
                LOG.error("Whisper ناموفق بود: " + (proc.stderr or proc.stdout)[-1800:])
                self.tg.send_message(
                    chat_id, "⚠️ نتوانستم صدا را بفهمم. یک ویس کوتاه‌تر و واضح‌تر بفرست.")
                return
            data = json.loads(transcript_path.read_text(encoding="utf-8"))
            transcript = (data.get("text") or "").strip()
            if not transcript:
                self.tg.send_message(chat_id, "صدایی/کلامی تشخیص ندادم؛ دوباره ضبط کن.")
                return
            self.tg.send_message(chat_id, f"🎙 شنیدم: {transcript[:2400]}")
            self.job_text(chat_id, transcript[:3000], voice_reply=True)
        except subprocess.TimeoutExpired:
            self.tg.send_message(chat_id, "⚠️ تبدیلِ صدا بیش از ۱۵ دقیقه طول کشید و متوقف شد.")
        except Exception:
            LOG.error("خطا در پردازش voice:\n" + traceback.format_exc())
            self.tg.send_message(chat_id, "⚠️ خطا در پردازش پیامِ صوتی.")

    def job_photo(self, chat_id, msg):
        try:
            self.tg.send_action(chat_id, "typing")
            work = CFG.work_dir_path / "bot" / str(chat_id)
            work.mkdir(parents=True, exist_ok=True)
            photo = msg["photo"][-1]
            src = work / f"in_{int(time.time())}.jpg"
            if not self.tg.download_file(photo["file_id"], src):
                self.tg.send_message(chat_id, "⚠️ دانلود تصویر ناموفق بود.")
                return
            self.tg.send_message(chat_id, "🔎 دارم بالن‌ها را می‌خوانم...")
            job_dir = self._new_job(chat_id, src, "photo")
            result = self._run_job(chat_id, job_dir, "photo")
            if not result or not result.get("files"):
                self.tg.send_message(chat_id,
                                     "🤔 متن انگلیسی‌ای روی این تصویر پیدا نکردم. "
                                     "اگر مطمئنی بالن دارد، عکس را با کیفیتِ بهتر بفرست.")
                return
            self.tg.send_message(
                chat_id, f"✅ {result['regions']} بالن در {result['seconds']:.0f} ثانیه")
            self._report(chat_id, job_dir, result)
            for f in result["files"]:
                self.send_image_smart(chat_id, Path(f))
        except Exception:
            LOG.error(traceback.format_exc())
            self.tg.send_message(chat_id, "⚠️ خطا در پردازش تصویر.")

    def job_font_upload(self, chat_id, msg):
        """دریافت TTF/OTF به‌عنوان فونتِ پیش‌فرضِ اختصاصیِ همین چت."""
        from PIL import ImageFont

        doc = msg.get("document") or {}
        name = Path(doc.get("file_name") or "font.ttf").name
        ext = Path(name).suffix.lower()
        if ext not in FONT_EXTS:
            self.tg.send_message(chat_id, "فرمتِ فونت باید TTF، OTF یا TTC باشد.")
            return
        if int(doc.get("file_size") or 0) > 20 * 1024 * 1024:
            self.tg.send_message(chat_id, "حجم فونت بیش از ۲۰ مگابایت است؛ فایل کوچک‌تری بفرست.")
            return

        folder = self._chat_dir(chat_id) / "fonts"
        folder.mkdir(parents=True, exist_ok=True)
        dest = folder / f"custom{ext}"
        tmp = folder / f"custom.upload{ext}"
        if not self.tg.download_file(doc.get("file_id"), tmp):
            self.tg.send_message(chat_id, "⚠️ دانلود فونت ناموفق بود؛ دوباره بفرست.")
            return
        try:
            # بازکردن فایل در Pillow، صحتِ ساختارِ فونت را بررسی می‌کند.
            font = ImageFont.truetype(str(tmp), 32, layout_engine=ImageFont.Layout.BASIC)
            if font.getmask("سلام قهرمان").getbbox() is None:
                raise ValueError("فونت هیچ گلیفِ قابل‌رسمی ندارد")
            tmp.replace(dest)
            self._save_font_path(chat_id, dest)
        except Exception as e:
            tmp.unlink(missing_ok=True)
            LOG.warning(f"فونتِ نامعتبر از {chat_id}: {type(e).__name__}: {e}")
            self.tg.send_message(
                chat_id, "⚠️ این فایل فونتِ قابل‌خواندن نیست. یک فایل TTF/OTF سالم بفرست.")
            return
        self.tg.send_message(
            chat_id, f"✅ فونتِ «{name}» فعال شد. از عکسِ بعدی با همین فونت استفاده می‌کنم.\n"
                     "برای برگشت به فونتِ پیش‌فرض: /font default")

    def job_document(self, chat_id, msg):
        try:
            doc = msg["document"]
            name = (doc.get("file_name") or "").lower()
            ext = Path(name).suffix.lower()
            if ext not in ARCHIVE_EXTS and ext not in IMAGE_EXTS:
                self.tg.send_message(chat_id, "فایل باید تصویر یا ZIP/CBZ باشد.")
                return
            if doc.get("file_size", 0) > CFG.bot.max_zip_mb * 1024 * 1024:
                self.tg.send_message(chat_id, f"حجم فایل بیش از {CFG.bot.max_zip_mb} مگابایت است.")
                return

            work = CFG.work_dir_path / "bot" / str(chat_id)
            work.mkdir(parents=True, exist_ok=True)
            src = work / f"{int(time.time())}_{Path(name).name}"
            self.tg.send_message(chat_id, "📥 فایل رسید، دارم آماده می‌شوم...")
            if not self.tg.download_file(doc["file_id"], src):
                self.tg.send_message(chat_id, "⚠️ دانلود ناموفق بود.")
                return

            kind = "archive" if ext in ARCHIVE_EXTS else "photo"
            job_dir = self._new_job(chat_id, src, kind)
            result = self._run_job(chat_id, job_dir, kind)
            if not result or not result.get("files"):
                self.tg.send_message(chat_id,
                                     "🤔 متن انگلیسی‌ای پیدا نکردم. فصلِ دیگری را امتحان کن.")
                return
            self.tg.send_message(
                chat_id, f"✅ تمام شد: {result['pages']} صفحه، "
                         f"{result['regions']} بالن، {result['seconds']:.0f} ثانیه")
            if result.get("zip") and Path(result["zip"]).exists():
                size = human_bytes(Path(result["zip"]).stat().st_size)
                self.tg.send_message(chat_id, f"📦 حجم فایل: {size}")
                self.tg.send_document(chat_id, result["zip"],
                                      f"📦 {result['pages']} صفحه")
            else:
                for f in result["files"][:10]:
                    self.send_image_smart(chat_id, Path(f))
            self._report(chat_id, job_dir, result)
        except Exception:
            LOG.error(traceback.format_exc())
            self.tg.send_message(chat_id, "⚠️ خطا در پردازش فصل.")

    # ------------------------------------------------ ارسالِ تصویرِ هوشمند
    def send_image_smart(self, chat_id: int, path: Path) -> None:
        """تصویرِ بلند را کامل و یک‌تکه به شکلِ فایل می‌فرستد؛ هرگز برش نمی‌زند."""
        from PIL import Image

        try:
            with Image.open(path) as im:
                w, h = im.size
                size = path.stat().st_size
                # sendPhoto محدودیتِ طول/عرض و حجم دارد؛ اگر مجاز است نمایشِ عکس بهتر است.
                if (w + h <= 9900 and max(w, h) <= 9900
                        and size < 9.5 * 1024 * 1024):
                    sent = self.tg.send_photo(chat_id, path)
                    if sent and sent.get("ok"):
                        return
                    LOG.warning(f"sendPhoto ناموفق بود؛ ارسالِ یک‌تکه به‌صورت فایل: {path.name}")

                # فایلِ بلند را به شکلِ Document بفرست تا تمامِ تصویر حفظ شود.
                upload = path
                if size >= 48 * 1024 * 1024:
                    # در صورت نیاز فقط کیفیتِ JPEG را کم می‌کنیم؛ ابعاد/تمامِ تصویر ثابت می‌ماند.
                    upload = path.with_name(path.stem + "_full.jpg")
                    rgb = im.convert("RGB")
                    try:
                        for quality in (90, 82, 74, 66, 58, 50):
                            rgb.save(upload, "JPEG", quality=quality, optimize=True)
                            if upload.stat().st_size < 48 * 1024 * 1024:
                                break
                        if upload.stat().st_size >= 48 * 1024 * 1024:
                            self.tg.send_message(chat_id,
                                "⚠️ تصویر از سقفِ حجمِ تلگرام بزرگ‌تر است؛ "
                                "نسخه‌ی فشرده هم در سقف جا نشد.")
                            return
                    finally:
                        rgb.close()

                caption = ("تصویرِ کامل، بدون برش. برای رعایت محدودیتِ تلگرام "
                           "به‌صورت فایل فرستادم؛ روی فایل بزن تا باز شود.")
                sent = self.tg.send_document(chat_id, upload, caption)
                if not sent or not sent.get("ok"):
                    self.tg.send_message(chat_id,
                        "⚠️ تلگرام نتوانست تصویرِ کامل را تحویل بگیرد. "
                        "فایلِ خروجی روی سرور ساخته شده؛ لطفاً یک‌بار عکسِ مبدأ را دوباره بفرست.")
        except Exception:
            LOG.error(traceback.format_exc())
            try:
                self.tg.send_document(chat_id, path, "خروجیِ کامل")
            except Exception:
                self.tg.send_message(chat_id, "⚠️ ارسالِ خروجی ناموفق بود.")

    def job_text(self, chat_id, text, voice_reply=False):
        from llm.skills import chat as llm_chat

        llm = self._llm_for_chat(chat_id)
        if not llm.available():
            self.tg.send_message(
                chat_id,
                "مدلِ چتِ محلی روی میزبان نصب نیست. مدیرِ سرور باید یک‌بار "
                "bash setup_env.sh را اجرا کند؛ API key لازم نیست.\n"
                "ترجمه‌ی عکس و فصل همچنان مستقل از چت کار می‌کند.")
            return
        self.tg.send_action(chat_id, "typing")
        histories = self.state.setdefault("history", {})
        history = histories.setdefault(chat_id, [])
        answer = llm_chat(llm, text, history=history)
        if not answer:
            self.tg.send_message(chat_id, "⚠️ مدلِ محلی پاسخ نداد؛ لاگ را بررسی کن و دوباره تلاش کن.")
            return
        history.extend([{"role": "user", "content": text},
                        {"role": "assistant", "content": answer}])
        del history[:-8]
        self.tg.send_message(chat_id, answer[:4000])
        if voice_reply or self._voice_enabled(chat_id):
            self._send_voice_text(chat_id, answer, "پاسخِ صوتی")


def main():
    token = (CFG.bot.token or os.getenv("TELEGRAM_TOKEN") or "").strip()
    if not token:
        print("TELEGRAM_TOKEN تنظیم نشده. از @BotFather بگیر و در .env بگذار.")
        raise SystemExit(1)
    # از وب‌هوکِ احتمالی پاک کن تا با long-polling تداخل نکند
    try:
        requests.get(f"https://api.telegram.org/bot{token}/deleteWebhook", timeout=20)
    except Exception:
        pass
    Bot(token).run()


if __name__ == "__main__":
    main()
