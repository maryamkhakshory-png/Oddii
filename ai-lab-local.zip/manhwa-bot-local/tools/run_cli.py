"""اجرای خط لوله از خط فرمان (بدون تلگرام و وب).

نمونه‌ها:
    # یک تصویر
    python tools/run_cli.py image -i data/samples/page_01.png -o out/page_01_fa.png

    # یک فصل (زیپ/سی‌بی‌زد)
    python tools/run_cli.py chapter -i chapter.cbz -o out/chapter_fa.zip

    # فقط متن‌ها را بیرون بده (بدون تغییر تصویر)
    python tools/run_cli.py text -i chapter.cbz -o out/texts.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core.config import load_config  # noqa: E402
from core.logging_setup import setup  # noqa: E402
from core.utils import imwrite, list_images  # noqa: E402
from llm.client import LLMClient  # noqa: E402
from vision.pipeline import ManhwaPipeline  # noqa: E402


def _pipeline(cfg_path: str | None):
    cfg = load_config(cfg_path)
    log = setup(cfg.log_level)
    llm = LLMClient.from_config(cfg.llm)
    if llm.available():
        log.info(f"مدل زبانی وصل است: {llm.model}")
    else:
        log.info("مدل زبانی وصل نیست — حالت کاملاً آفلاین")
    return cfg, log, ManhwaPipeline(cfg, log=log, llm=llm)


def cmd_image(a):
    cfg, log, pipe = _pipeline(a.config)
    from core.utils import imread

    res = pipe.process_image(imread(a.input), name=Path(a.input).name)
    if not res.ok:
        print("خطا:", res.error)
        return 1
    imwrite(a.output, res.image)
    print("ذخیره شد:", a.output)
    for r in res.regions:
        print(f"  • {r.source!r}\n    → {r.translated!r}")
    return 0


def cmd_chapter(a):
    cfg, log, pipe = _pipeline(a.config)

    def prog(done, total, msg):
        print(f"  [{done}/{total}] {msg}", flush=True)

    zip_path, stats = pipe.process_archive(a.input, a.work_dir, a.output,
                                           progress=prog, max_pages=a.max_pages)
    print(json.dumps(stats, ensure_ascii=False, indent=2))
    print("خروجی:", zip_path)
    return 0


def cmd_text(a):
    cfg, log, pipe = _pipeline(a.config)
    from core.utils import extract_archive, clean_dir

    out = []
    tmp = Path(a.work_dir) / "_txt"
    clean_dir(tmp)
    pages = list_images(extract_archive(a.input, tmp))
    for p in pages[: a.max_pages]:
        res = pipe.process_path(p)
        out.append(res.to_dict())
        print(f"{p.name}: {len(res.regions)} ناحیه")
        for r in res.regions:
            print(f"   {r.source!r} → {r.translated!r}")
    Path(a.output).parent.mkdir(parents=True, exist_ok=True)
    Path(a.output).write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("ذخیره شد:", a.output)
    return 0


def main():
    ap = argparse.ArgumentParser(description="خط لوله‌ی ترجمه‌ی مانها")
    ap.add_argument("--config", default=str(ROOT / "config.yaml"))
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("image")
    p1.add_argument("-i", "--input", required=True)
    p1.add_argument("-o", "--output", default="out/page_fa.png")
    p1.set_defaults(func=cmd_image)

    p2 = sub.add_parser("chapter")
    p2.add_argument("-i", "--input", required=True)
    p2.add_argument("-o", "--output", default="out/chapter_fa.zip")
    p2.add_argument("--work-dir", default="data/work")
    p2.add_argument("--max-pages", type=int, default=60)
    p2.set_defaults(func=cmd_chapter)

    p3 = sub.add_parser("text")
    p3.add_argument("-i", "--input", required=True)
    p3.add_argument("-o", "--output", default="out/texts.json")
    p3.add_argument("--work-dir", default="data/work")
    p3.add_argument("--max-pages", type=int, default=60)
    p3.set_defaults(func=cmd_text)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
