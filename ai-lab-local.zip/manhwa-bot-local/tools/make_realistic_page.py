"""ساختن صفحه‌های واقع‌گرایانه‌تر برای تست (بالن با حاشیه‌ی خالی روی نقاشی).

    python tools/make_realistic_page.py --out data/samples --pages 2
"""

from __future__ import annotations

import argparse
import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

try:
    from tools.make_sample_page import pick_font, wrap
except ImportError:
    import sys as _s; _s.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
    from tools.make_sample_page import pick_font, wrap

LAYOUT = [
    {
        "bg": "sky",
        "items": [
            {"kind": "light", "shape": "round", "box": (90, 90, 360, 200),
             "text": "Wait... is that a monster?"},
            {"kind": "light", "shape": "round", "box": (520, 300, 320, 170),
             "text": "I've never seen anything like this before..."},
            {"kind": "narration", "box": (60, 520, 400, 92),
             "text": "Meanwhile, in the royal capital..."},
            {"kind": "dark", "shape": "round", "box": (110, 700, 430, 190),
             "text": "If I die here, nobody will remember my name."},
            {"kind": "light", "shape": "round", "box": (600, 950, 220, 110),
             "text": "Run!"},
        ],
    },
    {
        "bg": "night",
        "items": [
            {"kind": "light", "shape": "round", "box": (80, 80, 300, 150),
             "text": "You again? I told you to stay away!"},
            {"kind": "light", "shape": "round", "box": (450, 260, 340, 200),
             "text": "Don't be stupid. We can't win this fight."},
            {"kind": "narration", "box": (70, 520, 460, 90),
             "text": "Three days earlier, at the southern gate."},
            {"kind": "dark", "shape": "round", "box": (120, 700, 400, 170),
             "text": "Something is wrong... I can feel it."},
            {"kind": "light", "shape": "round", "box": (560, 930, 260, 120),
             "text": "Let's go home."},
        ],
    },
]


def draw_background(draw, W, H, kind: str, rng: random.Random):
    if kind == "sky":
        for y in range(H):
            t = y / H
            draw.line([(0, y), (W, y)],
                      fill=(int(120 + 110 * t), int(160 + 70 * t), int(210 - 40 * t)))
    else:
        for y in range(H):
            t = y / H
            draw.line([(0, y), (W, y)],
                      fill=(int(20 + 40 * t), int(22 + 45 * t), int(48 + 60 * t)))
    # کوه‌ها / ساختمان‌ها
    for i in range(7):
        x = i * (W // 6) - 60
        h = rng.randint(160, 380)
        col = (int(40 + rng.randint(0, 60)), int(50 + rng.randint(0, 70)), int(70 + rng.randint(0, 70)))
        draw.polygon([(x, H), (x + W // 6, H), (x + W // 12, H - h)], fill=col)
    # رنگ‌آمیزیِ «جوهر» برای شبیه‌سازیِ بافتِ مانها
    for _ in range(400):
        x, y = rng.randint(0, W), rng.randint(0, H)
        r = rng.randint(2, 9)
        a = rng.randint(0, 40)
        draw.ellipse([x, y, x + r, y + r],
                     fill=(255, 255, 255, a) if kind != "night" else (200, 220, 255, a))


def draw_item(draw, W, H, item):
    x, y, w, h = item["box"]
    kind = item.get("kind", "light")
    shape = item.get("shape", "round")
    text = item["text"]

    if kind == "narration":
        draw.rectangle([x, y, x + w, y + h], fill=(250, 248, 240), outline=(25, 25, 30), width=3)
        bg, fg = (250, 248, 240), (20, 20, 25)
    elif kind == "dark":
        draw.rounded_rectangle([x, y, x + w, y + h], radius=int(min(w, h) * 0.4),
                               fill=(30, 30, 38), outline=(235, 235, 240), width=4)
        bg, fg = (30, 30, 38), (240, 240, 245)
    else:
        if shape == "round":
            draw.rounded_rectangle([x, y, x + w, y + h], radius=int(min(w, h) * 0.42),
                                   fill=(255, 255, 255), outline=(20, 20, 24), width=4)
            draw.polygon([(x + w // 2 - 22, y + h - 5), (x + w // 2 + 14, y + h - 5),
                          (x + w // 2 - 60, y + h + 52)], fill=(255, 255, 255),
                         outline=(20, 20, 24))
        bg, fg = (255, 255, 255), (18, 18, 22)

    # اندازه‌ی فونت طوری که متن حدود نیمی از ارتفاع بالن را بگیرد (حاشیه‌ی خالی بماند)
    max_w = w - int(w * 0.24)
    max_h = int(h * 0.62)
    size = int(h * 0.34)
    while size > 10:
        f = pick_font(size)
        lines = wrap(draw, text, f, max_w)
        if len(lines) * int(size * 1.32) <= max_h:
            break
        size -= 2
    f = pick_font(max(10, size))
    lines = wrap(draw, text, f, max_w)
    lh = int(max(10, size) * 1.32)
    ty = y + (h - len(lines) * lh) // 2
    for line in lines:
        tw = draw.textlength(line, font=f)
        draw.text((x + (w - tw) / 2, ty), line, font=f, fill=fg)
        ty += lh


def make_page(index: int, out_path: Path, seed: int = 3) -> Path:
    rng = random.Random(seed + index)
    W, H = 900, 1200
    img = Image.new("RGB", (W, H), (255, 255, 255))
    draw = ImageDraw.Draw(img, "RGBA")
    draw_background(draw, W, H, LAYOUT[index % len(LAYOUT)]["bg"], rng)
    for item in LAYOUT[index % len(LAYOUT)]["items"]:
        draw_item(draw, W, H, item)
    # حاشیه‌ی سفید دور صفحه (مثل اسکن)
    img2 = Image.new("RGB", (W + 40, H + 40), (250, 250, 252))
    img2.paste(img, (20, 20))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img2.save(out_path)
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/samples")
    ap.add_argument("--pages", type=int, default=2)
    ap.add_argument("--seed", type=int, default=3)
    a = ap.parse_args()
    out = Path(a.out)
    import zipfile

    paths = []
    for i in range(a.pages):
        p = make_page(i, out / f"real_{i+1:02d}.png", seed=a.seed)
        print("ساخته شد:", p)
        paths.append(p)
    zp = out / "real_chapter.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            z.write(p, p.name)
    print("زیپ:", zp)


if __name__ == "__main__":
    main()
