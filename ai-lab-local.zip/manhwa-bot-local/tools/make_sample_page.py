"""ساختن صفحه‌های نمونه‌ی مانها برای تست خط لوله (بدون استفاده از اثر دارای حق‌نشر).

    python tools/make_sample_page.py --out data/samples --pages 2
"""

from __future__ import annotations

import argparse
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
]

PANELS = [
    {
        "balloons": [
            {"kind": "light", "box": (60, 90, 320, 150),
             "text": "What the hell are you doing here, dude?"},
            {"kind": "light", "box": (430, 200, 320, 140),
             "text": "Shut up! I'm not going to let you escape this time!"},
        ],
        "sfx": ("BOOM!", 520, 60),
    },
    {
        "balloons": [
            {"kind": "dark", "box": (90, 330, 340, 130),
             "text": "I can't believe this is happening again..."},
            {"kind": "light", "box": (80, 700, 300, 120),
             "text": "Don't worry, I'll protect you."},
            {"kind": "light", "box": (450, 830, 300, 120),
             "text": "Guys, we have to run. Now!"},
        ],
        "sfx": None,
    },
]


def pick_font(size: int) -> ImageFont.FreeTypeFont:
    for p in FONT_CANDIDATES:
        if Path(p).exists():
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                continue
    return ImageFont.load_default()


def wrap(draw, text, font, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if draw.textlength(trial, font=font) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def draw_balloon(draw: Image.ImageDraw, box, text, kind="light"):
    x, y, w, h = box
    fill = (255, 255, 255) if kind == "light" else (28, 28, 34)
    outline = (20, 20, 20) if kind == "light" else (240, 240, 240)
    txt_color = (15, 15, 15) if kind == "light" else (245, 245, 245)
    draw.rounded_rectangle([x, y, x + w, y + h], radius=int(min(w, h) * 0.35),
                           fill=fill, outline=outline, width=4)
    # دُمِ بالن
    draw.polygon([(x + w // 2 - 18, y + h - 4), (x + w // 2 + 10, y + h - 4),
                  (x + w // 2 - 40, y + h + 46)], fill=fill, outline=outline)

    size = int(h * 0.30)
    while size > 9:
        font = pick_font(size)
        lines = wrap(draw, text, font, w - 34)
        lh = int(size * 1.30)
        if len(lines) * lh <= h - 22 and all(draw.textlength(l, font=font) <= w - 34 for l in lines):
            break
        size -= 1
    font = pick_font(max(9, size))
    lines = wrap(draw, text, font, w - 34)
    lh = int(max(9, size) * 1.30)
    ty = y + (h - len(lines) * lh) // 2
    for line in lines:
        tw = draw.textlength(line, font=font)
        draw.text((x + (w - tw) / 2, ty), line, font=font, fill=txt_color)
        ty += lh


def draw_art(draw, w, h, rng: random.Random):
    for _ in range(26):
        x0, y0 = rng.randint(0, w), rng.randint(0, h)
        x1, y1 = x0 + rng.randint(30, 220), y0 + rng.randint(30, 220)
        color = (rng.randint(150, 235), rng.randint(150, 235), rng.randint(160, 240))
        draw.ellipse([x0, y0, x1, y1], outline=color, width=3)
    draw.rectangle([0, h - 90, w, h], fill=(190, 195, 210))


def make_page(index: int, out_path: Path, seed: int = 0) -> Path:
    rng = random.Random(seed + index)
    W, H = 800, 1200
    img = Image.new("RGB", (W, H), (238, 238, 242))
    draw = ImageDraw.Draw(img)
    draw_art(draw, W, H, rng)

    spec = PANELS[index % len(PANELS)]
    for b in spec["balloons"]:
        draw_balloon(draw, b["box"], b["text"], b.get("kind", "light"))
    if spec.get("sfx"):
        text, sx, sy = spec["sfx"]
        f = pick_font(74)
        draw.text((sx, sy), text, font=f, fill=(255, 60, 40),
                  stroke_width=5, stroke_fill=(20, 20, 20))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/samples")
    ap.add_argument("--pages", type=int, default=2)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    out = Path(args.out)
    paths = []
    for i in range(args.pages):
        p = make_page(i, out / f"page_{i+1:02d}.png", seed=args.seed)
        paths.append(p)
        print("ساخته شد:", p)
    # یک زیپ هم برای تست ورودی ربات
    import zipfile

    zp = out / "sample_chapter.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            z.write(p, p.name)
    print("زیپ نمونه:", zp)


if __name__ == "__main__":
    main()
