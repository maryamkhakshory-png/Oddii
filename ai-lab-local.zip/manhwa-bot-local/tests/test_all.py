"""تست‌های پروژه — قابل اجرا با:  python -m pytest tests -q

تست‌ها عمداً «کمّی» نوشته شده‌اند (اندازه‌گیریِ پیکسلی) تا بدون نگاه کردن به
تصویر هم بشود مطمئن شد خروجی درست است.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from PIL import Image, ImageDraw, ImageFont  # noqa: E402

from core.config import load_config  # noqa: E402
from core.utils import imread  # noqa: E402
from nlp.colloquial import build_colloquializer  # noqa: E402
from vision.render import (display, draw_text_block, fit_text, load_font, normalize_fa)  # noqa: E402
from vision.text_style import TextStyle, detect_text_style  # noqa: E402

FA_CHARS = set("ابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی")

CFG = load_config()
SAMPLE = ROOT / "data" / "samples" / "page_01.png"


def has_fa(text: str) -> bool:
    return any(c in FA_CHARS for c in str(text))


def ink_ratio(img: np.ndarray, box) -> float:
    x, y, w, h = box
    H, W = img.shape[:2]
    x, y = max(0, x), max(0, y)
    crop = img[y:min(H, y + h), x:min(W, x + w)]
    if crop.size == 0:
        return 0.0
    gray = crop.mean(axis=2) if crop.ndim == 3 else crop
    return float((gray < 100).mean())


# --------------------------------------------------------------------- فونت
def test_font_has_persian_glyphs():
    """اگر فونت فارسی نداشته باشد، همه‌ی رشته‌ها هم‌عرض می‌شوند (مربع‌های خالی)."""
    font_path = CFG.font_path
    assert font_path.exists(), f"فونت پیدا نشد: {font_path}"
    canvas = Image.new("RGB", (10, 10))
    draw = ImageDraw.Draw(canvas)
    f = load_font(str(font_path), 40)
    w1 = draw.textlength(display("سلام"), font=f)
    w2 = draw.textlength(display("کتابخانه"), font=f)
    w3 = draw.textlength(display("چهار"), font=f)
    assert w1 > 10 and w2 > 10
    assert abs(w1 - w2) > 5, "عرض رشته‌ها یکسان است — احتمالاً فونت فارسی ندارد"
    assert abs(w1 - w3) > 2


def test_mixed_latin_persian_is_still_rtl():
    """واژه‌ی لاتینِ ابتدای جمله نباید جهتِ کل بالن را LTR کند."""
    import arabic_reshaper
    from bidi.algorithm import get_display

    shaped = arabic_reshaper.reshape("TSK، چطور")
    assert display("TSK، چطور") == get_display(shaped, base_dir="R")
    assert display("TSK، چطور") != get_display(shaped)


def test_fit_text_never_grows_above_english_size_and_stays_inside():
    box = (180, 72)
    fit = fit_text(str(CFG.font_path), "این متنِ فارسی باید داخل بالن جا بگیرد", *box,
                   CFG.render, base_size=24)
    assert fit.ok
    assert fit.size <= 24
    assert fit.block_h <= int(box[1] * (1 - CFG.render.padding_ratio * 0.9))


def test_fit_text_truncates_extreme_overflow_inside_box():
    fit = fit_text(str(CFG.font_path),
                   "این یک جمله‌ی خیلی خیلی خیلی بلند برای بالن کوچک است",
                   80, 35, CFG.render, base_size=22)
    assert fit.ok
    assert fit.size <= 22
    assert fit.block_h <= 35
    assert "…" in " ".join(fit.lines)


def test_pre_shaped_persian_uses_basic_layout(): 
    """متنِ reshaped+bidi نباید بارِ دوم با RAQM بازآرایی شود."""
    font_path = str(CFG.font_path)
    font = load_font(font_path, 42)
    assert font.layout_engine == ImageFont.Layout.BASIC

    def raster(f):
        image = Image.new("L", (360, 100), 0)
        ImageDraw.Draw(image).text((180, 50), display("قهرمان"),
                                   font=f, fill=255, anchor="mm")
        return np.asarray(image)

    correct = raster(font)
    raqm_font = ImageFont.truetype(
        font_path, 42, layout_engine=ImageFont.Layout.RAQM)
    # این واژه عمداً تفاوتِ shaping دوباره را آشکار می‌کند.
    assert not np.array_equal(correct, raster(raqm_font))


def test_start_menu_inline_buttons_are_wired_to_actions():
    from bots.telegram_bot import Bot

    class FakeTG:
        def __init__(self):
            self.sent = []
            self.answered = []
        def send_message(self, *args, **kwargs):
            self.sent.append((args, kwargs))
        def answer_callback(self, callback_id):
            self.answered.append(callback_id)
        def edit_message(self, *args, **kwargs):
            pass

    bot = Bot.__new__(Bot)
    bot.tg = FakeTG()
    bot.cmd_start(42)
    markup = bot.tg.sent[-1][1]["reply_markup"]["inline_keyboard"]
    buttons = {button["callback_data"] for row in markup for button in row}
    assert {"menu:photo", "menu:chapter", "menu:chat", "menu:voice",
            "menu:mode", "menu:lang", "menu:font", "menu:status"} <= buttons

    bot.on_callback({"id": "cb-1", "data": "menu:photo",
                     "message": {"message_id": 7, "chat": {"id": 42}}})
    assert bot.tg.answered == ["cb-1"]
    assert "تصویر" in bot.tg.sent[-1][0][1]


def test_bot_activates_uploaded_font_per_chat(tmp_path, monkeypatch):
    import shutil
    from bots.telegram_bot import Bot

    monkeypatch.setattr(CFG, "work_dir", str(tmp_path))

    class FakeTG:
        def __init__(self):
            self.sent = []
        def download_file(self, _file_id, dest):
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(CFG.font_path, dest)
            return True
        def send_message(self, *args):
            self.sent.append(args)
            return {"ok": True}

    bot = Bot.__new__(Bot)
    bot.tg = FakeTG()
    bot.job_font_upload(42, {"document": {
        "file_id": "fake", "file_name": "chosen.ttf", "file_size": 1234}})
    active = bot._font_path_for_chat(42)
    assert active.is_file() and active.name == "custom.ttf"
    assert "فعال شد" in bot.tg.sent[-1][1]


def test_bot_sends_tall_image_as_one_document(tmp_path):
    from bots.telegram_bot import Bot

    class FakeTG:
        def __init__(self):
            self.photos, self.documents = [], []
        def send_photo(self, *args):
            self.photos.append(args)
            return {"ok": True}
        def send_document(self, *args):
            self.documents.append(args)
            return {"ok": True}
        def send_message(self, *args):
            return {"ok": True}

    image_path = tmp_path / "long.jpg"
    Image.new("RGB", (400, 12000), "white").save(image_path, quality=90)
    bot = Bot.__new__(Bot)
    bot.tg = FakeTG()
    bot.send_image_smart(42, image_path)
    assert bot.tg.photos == []
    assert len(bot.tg.documents) == 1
    assert bot.tg.documents[0][1] == image_path
    assert "بدون برش" in bot.tg.documents[0][2]


def test_persian_rendering_produces_ink():
    img = np.full((200, 400, 3), 255, np.uint8)
    box = (10, 10, 380, 180)
    out = draw_text_block(img, box, "چه مرگته؟ برو گمشو!", CFG.render, base_size=42)
    ink_before = ink_ratio(img, box)
    ink_after = ink_ratio(out, box)
    assert ink_before < 0.01
    assert 0.01 < ink_after < 0.75, f"مقدار مرکب غیرعادی: {ink_after}"


def test_rendered_glyph_pixels_never_escape_balloon_box():
    img = np.full((100, 200, 3), 255, np.uint8)
    box = (55, 28, 72, 42)
    out = draw_text_block(
        img, box, "این یک ترجمه‌ی خیلی خیلی طولانی برای بالن کوچک است",
        CFG.render, base_size=34)
    ys, xs = np.where(np.any(out < 245, axis=2))
    assert len(xs) > 0
    x, y, w, h = box
    assert xs.min() >= x and xs.max() < x + w
    assert ys.min() >= y and ys.max() < y + h


def test_source_style_detector_finds_coloured_fill_and_dark_outline():
    font = ImageFont.truetype(str(CFG.font_path), 34)
    source = Image.new("RGB", (190, 80), "white")
    ImageDraw.Draw(source).text((24, 17), "WOW", font=font, fill="#E53935",
                                stroke_width=2, stroke_fill="#111111")
    source_bgr = np.asarray(source)[..., ::-1].copy()
    style = detect_text_style(source_bgr, (16, 9, 155, 58), source_height=34)
    assert style is not None
    assert style.color is not None and style.stroke_color is not None
    rgb = tuple(int(style.color[i:i + 2], 16) for i in (1, 3, 5))
    assert rgb[0] > rgb[1] * 1.7 and rgb[0] > rgb[2] * 1.5
    assert style.stroke_color.lower() in {"#171717", "#ffffff"}
    assert style.stroke_width_ratio > 0


def test_renderer_applies_detected_fill_outline_and_gradient():
    img = np.full((150, 300, 3), 255, np.uint8)
    style = TextStyle(color="#E53935", stroke_color="#171717",
                      stroke_width_ratio=0.06)
    out = draw_text_block(img, (35, 20, 230, 105), "چه خبر!", CFG.render,
                          base_size=42, style=style)
    red = (out[..., 2] > 130) & (out[..., 2] > out[..., 1] * 1.45)
    assert int(red.sum()) > 20

    gradient_style = TextStyle(gradient_colors=("#F02F38", "#3157D5"),
                               gradient_axis="vertical")
    gradient = draw_text_block(img, (35, 20, 230, 105), "وای!", CFG.render,
                               base_size=42, style=gradient_style)
    ink = np.any(gradient < 245, axis=2)
    ys, xs = np.where(ink)
    assert len(xs) > 10
    y_mid = (int(ys.min()) + int(ys.max())) // 2
    rows = np.indices(ink.shape)[0]
    upper = np.median(gradient[ink & (rows <= y_mid)], axis=0)
    lower = np.median(gradient[ink & (rows > y_mid)], axis=0)
    assert np.linalg.norm(upper.astype(float) - lower.astype(float)) > 20


def test_pipeline_carries_source_colour_into_persian_replacement():
    from vision.pipeline import ManhwaPipeline, TextRegion

    font = ImageFont.truetype(str(CFG.font_path), 30)
    source = Image.new("RGB", (260, 110), "white")
    ImageDraw.Draw(source).text((82, 38), "WOW", font=font, fill="#E53935",
                                stroke_width=2, stroke_fill="#111111")
    image = np.asarray(source)[..., ::-1].copy()
    pipe = ManhwaPipeline(CFG, log=None, with_ocr=False, with_translator=False)
    region = TextRegion(draw_box=(30, 14, 200, 78), erase_box=(75, 32, 115, 48),
                        source="WOW", translated="وای!", kind="auto", src_height=25)
    out = pipe.render_regions(image, [region])
    red = (out[..., 2] > 130) & (out[..., 2] > out[..., 1] * 1.45)
    assert int(red.sum()) > 20


# ------------------------------------------------------------- متن فارسی
def test_local_llm_invokes_only_local_worker(monkeypatch, tmp_path):
    import subprocess
    from llm.local_client import LocalLLM

    calls = []
    def fake_run(cmd, **kwargs):
        calls.append((cmd, kwargs))
        return subprocess.CompletedProcess(cmd, 0, '{"text":"سلام، محلی هستم."}', "")

    monkeypatch.setattr(LocalLLM, "available", lambda self: True)
    monkeypatch.setattr("llm.local_client.subprocess.run", fake_run)
    client = LocalLLM(model_path=str(tmp_path / "model.gguf"))
    answer = client.chat([{"role": "user", "content": "سلام"}])
    assert answer == "سلام، محلی هستم."
    cmd, kwargs = calls[0]
    assert "llm.local_worker" in cmd
    assert "api_key" not in kwargs["input"]
    assert kwargs["timeout"] == client.timeout


def test_llm_availability_rejects_bad_auth(monkeypatch):
    from llm.client import LLMClient

    class Response:
        status_code = 401

    monkeypatch.setattr("llm.client.requests.get", lambda *a, **k: Response())
    client = LLMClient(base_url="https://example.invalid/v1", api_key="bad",
                       enabled=True)
    assert not client.available()


def test_normalize_fa():
    assert normalize_fa("بچه ها، بیا") == "بچه‌ها، بیا"
    assert normalize_fa("مي خواهم") == "می‌خواهم"
    once = normalize_fa("کتاب های جدید")
    assert normalize_fa(once) == once, "نرمال‌سازی باید تکرارپذیر باشد"
    assert "‌" in normalize_fa("می روم")


def test_colloquial_verbs():
    c = build_colloquializer("colloquial")
    assert c.colloquialize("من نمی‌خواهم بروم") == "نمی‌خوام برم"
    assert "می‌خوام" in c.colloquialize("می‌خواهم بخوابم")
    assert "نمی‌دونم" in c.colloquialize("نمی‌دانم")
    assert c.colloquialize("او خوب است") == "او خوبه"
    assert "ممنون" in c.colloquialize("متشکرم")
    assert c.colloquialize("میتونم برم") == "می‌تونم برم"


def test_glossary_direct():
    c = build_colloquializer("colloquial")
    assert c.lookup_direct("BOOM!") == "بوم"
    assert c.lookup_direct("shut up") == "خفه شو"
    assert c.lookup_direct("Oh My God") == "وای خدای من"


def test_punctuation_kept():
    c = build_colloquializer("colloquial")
    out = c.colloquialize("خفه شو", src="Shut up!")
    assert out.endswith("!")


# ------------------------------------------------------------- خط لوله
@pytest.mark.slow
def test_pipeline_on_sample_page():
    if not SAMPLE.exists():
        pytest.skip("صفحه‌ی نمونه ساخته نشده")
    from vision.pipeline import ManhwaPipeline

    pipe = ManhwaPipeline(CFG, log=None)
    src = imread(SAMPLE)
    res = pipe.process_image(src, name="page_01.png")

    assert res.ok, res.error
    assert len(res.regions) >= 2, f"فقط {len(res.regions)} ناحیه پیدا شد"
    for r in res.regions:
        assert r.source.strip(), "متن منبع خالی است"
        assert has_fa(r.translated), f"ترجمه فارسی نیست: {r.translated!r}"
        assert len(r.translated) < 400

    out = res.image
    assert out is not None and out.shape == src.shape
    changed = [r for r in res.regions
               if not np.array_equal(src[r.draw_box[1]:r.draw_box[1] + r.draw_box[3],
                                        r.draw_box[0]:r.draw_box[0] + r.draw_box[2]],
                                     out[r.draw_box[1]:r.draw_box[1] + r.draw_box[3],
                                         r.draw_box[0]:r.draw_box[0] + r.draw_box[2]])]
    assert len(changed) >= 2, "متن روی تصویر تغییر نکرده"

    for r in res.regions:
        ink = ink_ratio(out, r.draw_box)
        assert 0.005 < ink < 0.8, f"مرکب غیرعادی در {r.draw_box}: {ink}"


@pytest.mark.slow
def test_pipeline_archive(tmp_path):
    zf = ROOT / "data" / "samples" / "sample_chapter.zip"
    if not zf.exists():
        pytest.skip("زیپ نمونه ساخته نشده")
    from vision.pipeline import ManhwaPipeline

    pipe = ManhwaPipeline(CFG, log=None)
    zip_out, stats = pipe.process_archive(zf, tmp_path / "work", tmp_path / "out.zip")
    assert zip_out.exists() and zip_out.stat().st_size > 1000
    assert stats["pages"] >= 1
    assert stats["regions"] >= 1
    assert (Path(stats["sidecar"])).exists()


# --------------------------------------------------------------------- صوت
def test_tts_offline():
    """تولید گفتار با Piper باید بدون اینترنت هم کار کند."""
    from speech.tts import piper_available, speak, telegram_voice_file

    if not piper_available():
        pytest.skip("مدل Piper دانلود نشده")
    out = ROOT / "out" / "test_voice.wav"
    p = speak("سلام، این یک تست است.", str(out))
    assert p and Path(p).exists() and Path(p).stat().st_size > 5000
    voice = telegram_voice_file(p)
    assert voice and voice.endswith(".ogg") and Path(voice).stat().st_size > 1000


# ------------------------------------------------------- فیلترِ واترمارک
def test_filters_skip_watermarks():
    """/واترمارک و نوشته‌ی غیرلاتین نباید ترجمه شوند (اثر هنری دست‌نخورده)."""
    from nlp.filters import looks_translatable

    assert looks_translatable("TSK, HOW COULD I FORGET!")
    assert looks_translatable("I HAVE PLENTY OF MONEY NOW!")
    assert not looks_translatable("终极肆意")                       # چینی
    assert not looks_translatable("腾机动漫")                       # چینی
    assert not looks_translatable("FIRESCANS.XYZ")                 # آدرس سایت
    assert not looks_translatable("!!")
    assert not looks_translatable("   ")
    assert not looks_translatable(
        "SUPPORT THE TEAM BY READING THE SERIES ON OUR WEBSITE FIRESCANS")


def test_pipeline_skips_watermark_regions():
    """بالنِ واترمارک باید ترجمه‌نشده بماند تا روی تصویر دست نخورد."""
    from vision.pipeline import ManhwaPipeline, TextRegion

    pipe = ManhwaPipeline(CFG, log=None, with_ocr=False, with_translator=False)
    regions = [
        TextRegion(draw_box=(0, 0, 50, 20), erase_box=(0, 0, 50, 20),
                   source="终极肆意", kind="auto"),
        TextRegion(draw_box=(0, 30, 50, 20), erase_box=(0, 30, 50, 20),
                   source="TIME TO SHOP!", kind="auto"),
    ]
    pipe._translate_regions(regions)
    assert regions[0].translated == ""          # رها شده
    assert regions[0].kind == "skip"
    assert has_fa(regions[1].translated)        # این یکی ترجمه شده


# ---------------------------------------------------- نشانه‌سازِ سبکِ NLLB
def test_nllb_tokenizer_matches_hf():
    """نشانه‌سازِ سبک باید همان خروجیِ AutoTokenizer را بدهد."""
    from nlp.translator import NllbTokenizer

    if not (ROOT / "models" / "nllb-600m-ct2" / "tokenizer.json").exists():
        pytest.skip("مدل ترجمه دانلود نشده")
    tk = NllbTokenizer(ROOT / "models" / "nllb-600m-ct2", src_lang="eng_Latn")
    text = "Don't worry, I will protect you."
    mine = tk.tokenize(text)
    assert mine[0] == "eng_Latn", mine[:3]
    assert mine[-1] == "</s>", mine[-3:]
    # کدگشایی باید متن را سالم برگرداند
    ids = tk.convert_tokens_to_ids(mine)
    assert "protect" in tk.decode(ids, skip_special_tokens=True).lower()


# --------------------------------------------------------- فازهای کار
@pytest.mark.slow
def test_job_phases_end_to_end(tmp_path):
    """سه فازِ جدا (OCR ← ترجمه ← حروف‌چینی) روی یک صفحه."""
    zf = ROOT / "data" / "samples" / "sample_chapter.zip"
    if not zf.exists():
        pytest.skip("زیپ نمونه ساخته نشده")
    from core.utils import extract_archive, list_images
    from jobs.run_job import phase_ocr, phase_render, phase_translate

    pages = list_images(extract_archive(zf, tmp_path / "in"))
    job_dir = tmp_path / "job"
    (job_dir / "out").mkdir(parents=True, exist_ok=True)
    (job_dir / "job.json").write_text(
        '{"kind": "photo", "src": "%s", "max_pages": 1}' % pages[0],
        encoding="utf-8")

    phase_ocr(job_dir)
    assert (job_dir / "regions.json").exists()
    phase_translate(job_dir)
    phase_render(job_dir)
    result = json.loads((job_dir / "result.json").read_text(encoding="utf-8"))
    assert result["ok"], result
    assert result["regions"] >= 1
    assert Path(result["files"][0]).exists()
