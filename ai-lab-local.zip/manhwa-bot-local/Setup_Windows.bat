@echo off
setlocal
cd /d "%~dp0"

echo ================================================================
echo   MANHWA BOT - FIRST-TIME SETUP
echo ================================================================
echo This downloads Python packages and open AI models to this computer.
echo It can take a while. Do not close this window during setup.
echo.
where py >nul 2>nul
if errorlevel 1 goto no_launcher
py -3.11 scripts\setup_local.py
if errorlevel 1 goto failed
echo.
echo Setup completed. Next, edit .env and add your Telegram token.
echo Then double-click Start_Bot.bat.
pause
exit /b 0

:no_launcher
echo Python Launcher was not found.
echo Install the latest 64-bit Python 3.11 from https://www.python.org/downloads/
echo During installation, tick the box: Add python.exe to PATH.
pause
exit /b 1

:failed
echo.
echo Setup did not finish. Read the last error above, check internet/disk space,
echo then run Setup_Windows.bat again. It can resume already downloaded models.
pause
exit /b 1
