#!/usr/bin/env python3
"""Build a safe, lightweight local-use ZIP (never includes .env or model weights)."""
from __future__ import annotations

import stat
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT.parent / "ai-lab-local.zip"
ARCHIVE_ROOT = "manhwa-bot-local"
EXCLUDE_DIRS = {
    ".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".cache", "models", "data", "out", "logs", "coverage",
    "dist", "build", "node_modules",
}
EXCLUDE_FILES = {".env", ".env.local", ".env.production"}
INCLUDE_ROOT_FILES = {
    ".env.example", ".gitignore", "README.md", "README_LOCAL_FA.md",
    "Dockerfile", "config.yaml", "requirements.txt", "pytest.ini",
    "setup_env.sh", "setup_local.sh", "start_local.sh",
    "Setup_Windows.bat", "Start_Bot.bat",
}
INCLUDE_DIRS = {
    "assets", "bots", "core", "jobs", "llm", "nlp", "scripts",
    "server", "speech", "tests", "tools", "vision",
}


def should_include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if path.name in EXCLUDE_FILES or path.suffix.lower() in {".pyc", ".pyo", ".log"}:
        return False
    if path.name.startswith(".env.") and path.name != ".env.example":
        return False
    first = rel.parts[0]
    if len(rel.parts) == 1:
        return path.name in INCLUDE_ROOT_FILES
    return first in INCLUDE_DIRS


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and should_include(p))
    if not files:
        raise SystemExit("No package files found.")
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6) as archive:
        for path in files:
            rel = path.relative_to(ROOT).as_posix()
            name = f"{ARCHIVE_ROOT}/{rel}"
            info = zipfile.ZipInfo.from_file(path, name)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | (path.stat().st_mode & 0o777)) << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(OUTPUT) as archive:
        names = archive.namelist()
        if any(name.endswith("/.env") or "/models/" in name or "/data/" in name
               for name in names):
            OUTPUT.unlink(missing_ok=True)
            raise SystemExit("Safety check failed: private or large runtime files found in ZIP.")
    print(f"Created: {OUTPUT}")
    print(f"Included source files: {len(files)} | ZIP size: {OUTPUT.stat().st_size:,} bytes")
    print("Excluded: .env secrets, virtualenvs, model weights, logs, caches and user data.")


if __name__ == "__main__":
    main()
