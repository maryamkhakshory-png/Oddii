#!/usr/bin/env python3
"""Load the private .env file and start the bot with the current Python runtime."""
from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_env_file(path: Path) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def main() -> None:
    os.chdir(ROOT)
    load_env_file(ROOT / ".env")
    token = (os.getenv("TELEGRAM_TOKEN") or "").strip()
    if not token:
        print("Telegram token is missing.")
        print("Open .env in this folder and set TELEGRAM_TOKEN=the-token-from-BotFather")
        raise SystemExit(1)

    needed = [
        ROOT / "models/nllb-600m-ct2/model.bin",
        ROOT / "models/llm/Qwen3.5-0.8B-Q4_K_M.gguf",
        ROOT / "models/piper/fa_IR-amir-medium.onnx",
        ROOT / "models/piper/fa_IR-amir-medium.onnx.json",
        ROOT / "assets/fonts/Vazirmatn-Regular.ttf",
    ]
    missing = [str(p.relative_to(ROOT)) for p in needed if not p.is_file()]
    if missing:
        print("Some local models/assets are missing:")
        for item in missing:
            print(f"  - {item}")
        print("Run Setup_Windows.bat or python3.11 scripts/setup_local.py first.")
        raise SystemExit(1)

    sys.path.insert(0, str(ROOT))
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    print("Starting your local Telegram bot. Keep this window open; press Ctrl+C to stop.", flush=True)
    runpy.run_module("bots.telegram_bot", run_name="__main__")


if __name__ == "__main__":
    main()
