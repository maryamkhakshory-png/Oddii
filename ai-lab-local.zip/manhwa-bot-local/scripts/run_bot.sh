#!/usr/bin/env bash
# Resilient launcher: recreate the excluded/missing venv and model files once if needed.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1

set -a
[[ -f .env ]] && . ./.env
set +a
if [[ -z "${TELEGRAM_TOKEN:-}" ]]; then
  echo "TELEGRAM_TOKEN is missing. Set it in $ROOT/.env before starting the bot."
  exit 1
fi

export MALLOC_ARENA_MAX=2
export OMP_NUM_THREADS=1
export TOKENIZERS_PARALLELISM=false
export HF_HUB_DISABLE_TELEMETRY=1
mkdir -p logs

needs_setup=0
[[ -x "$ROOT/.venv/bin/python" ]] || needs_setup=1
if [[ "$needs_setup" -eq 0 ]]; then
  "$ROOT/.venv/bin/python" - <<'PY' >/dev/null 2>&1 || needs_setup=1
import av, arabic_reshaper, ctranslate2, cv2, llama_cpp, numpy, PIL, piper, requests, rapidocr_onnxruntime, yaml
PY
fi
[[ -s "$ROOT/models/nllb-600m-ct2/model.bin" ]] || needs_setup=1
[[ -s "$ROOT/models/llm/Qwen3.5-0.8B-Q4_K_M.gguf" ]] || needs_setup=1
[[ -s "$ROOT/models/piper/fa_IR-amir-medium.onnx" ]] || needs_setup=1
[[ -s "$ROOT/assets/fonts/Vazirmatn-Regular.ttf" ]] || needs_setup=1

if [[ "$needs_setup" -eq 1 ]]; then
  echo "Dependencies or models are missing; bootstrapping with setup_env.sh (this can take several minutes)."
  bash "$ROOT/setup_env.sh" || exit 1
fi

PY="$ROOT/.venv/bin/python"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
echo "Bot supervisor started. Press Ctrl+C to stop."
while true; do
  echo "=== Starting bot: $(date '+%Y-%m-%d %H:%M:%S') ==="
  "$PY" -m bots.telegram_bot 2>&1 | tee -a "$ROOT/logs/bot.log"
  code=${PIPESTATUS[0]}
  echo "=== Bot exited with code $code at $(date '+%H:%M:%S'); retry in 5 seconds ==="
  sleep 5
done
