#!/usr/bin/env python3
"""One-time, beginner-friendly setup for the local Telegram bot (Python 3.11)."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / ".venv"
PY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
CPU_WHEEL_INDEX = "https://abetlen.github.io/llama-cpp-python/whl/cpu"


def stop(message: str, code: int = 1) -> None:
    print(f"\nERROR: {message}", file=sys.stderr)
    raise SystemExit(code)


def run(args: list[str], label: str) -> None:
    print(f"\n{'=' * 68}\n{label}\n{'=' * 68}", flush=True)
    try:
        subprocess.run(args, cwd=ROOT, check=True)
    except FileNotFoundError:
        stop(f"Could not run: {args[0]}")
    except subprocess.CalledProcessError as exc:
        stop(f"A setup step failed (exit code {exc.returncode}). Fix the message above, then run Setup again.")


def main() -> None:
    os.chdir(ROOT)
    if sys.version_info[:2] != (3, 11):
        stop("Please run this setup with 64-bit Python 3.11. On Windows, use Setup_Windows.bat; "
             "on macOS/Linux, use python3.11 scripts/setup_local.py.")
    if sys.maxsize <= 2**32:
        stop("A 64-bit version of Python is required.")

    free_gb = shutil.disk_usage(ROOT).free / (1024 ** 3)
    print("Local Manhwa Bot setup — all AI models run on this computer.")
    print(f"Python: {sys.version.split()[0]} | Free disk space: {free_gb:.1f} GB")
    if free_gb < 5:
        print("WARNING: Less than 5 GB is free. Dependency and model downloads may run out of disk space.")

    env_file = ROOT / ".env"
    if not env_file.exists():
        shutil.copyfile(ROOT / ".env.example", env_file)
        print("Created .env from .env.example. Add your Telegram token to .env before starting the bot.")

    if not PY.exists():
        print("\nCreating a private Python environment in .venv ...", flush=True)
        try:
            import venv
            venv.EnvBuilder(with_pip=True).create(VENV)
        except Exception as exc:
            stop(f"Could not create the Python environment: {exc}")

    run([str(PY), "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"],
        "Step 1/4 — Installing Python package tools")
    run([str(PY), "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")],
        "Step 2/4 — Installing free Python dependencies")
    run([str(PY), "-m", "pip", "install", "--only-binary=llama-cpp-python",
         "--extra-index-url", CPU_WHEEL_INDEX, "llama-cpp-python>=0.3.16,<1.0"],
        "Step 3/4 — Installing the prebuilt CPU wheel for local chat (no compiling)")
    run([str(PY), str(ROOT / "scripts" / "download_assets.py")],
        "Step 4/4 — Downloading the open translation, chat, and Persian voice models")

    print("\nSetup finished successfully.")
    print("Next: open .env in Notepad/TextEdit, add TELEGRAM_TOKEN=... and save it.")
    print("Then double-click Start_Bot.bat (Windows), or run scripts/start_local.sh (macOS/Linux).")
    print("The first setup needs internet. Keep at least 5 GB free on this drive.")


if __name__ == "__main__":
    main()
