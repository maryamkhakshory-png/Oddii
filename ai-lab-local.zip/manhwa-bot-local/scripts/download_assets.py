#!/usr/bin/env python3
"""Download the free, open local translation/chat/voice assets used by the bot."""
from __future__ import annotations

import os
import shutil
import urllib.request
from pathlib import Path

from huggingface_hub import hf_hub_download, snapshot_download

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "models"


def download_nllb() -> None:
    dst = MODELS / "nllb-600m-ct2"
    if (dst / "model.bin").is_file():
        print(f"NLLB already present: {dst}")
        return
    dst.mkdir(parents=True, exist_ok=True)
    candidates = [
        "JustFrederik/nllb-200-distilled-600M-ct2-int8",
        "OpenNMT/nllb-200-distilled-600M-ct2-int8",
        "michaelfeil/ct2fast-nllb-200-distilled-600M",
    ]
    patterns = ["*.json", "*.model", "*.txt", "*.bin", "vocab*",
                "sentencepiece*", "*.spm", "*.model"]
    errors = []
    for repo in candidates:
        try:
            snapshot_download(repo_id=repo, allow_patterns=patterns, local_dir=str(dst))
            if (dst / "model.bin").is_file():
                print(f"NLLB downloaded from {repo}")
                return
            errors.append(f"{repo}: downloaded but model.bin is missing")
        except Exception as exc:
            errors.append(f"{repo}: {type(exc).__name__}: {exc}")
    raise RuntimeError("Could not download NLLB model: " + " | ".join(errors))


def download_chat_model() -> None:
    dst = MODELS / "llm"
    filename = "Qwen3.5-0.8B-Q4_K_M.gguf"
    path = dst / filename
    if path.is_file() and path.stat().st_size > 450_000_000:
        print(f"Local chat model already present: {path}")
        return
    dst.mkdir(parents=True, exist_ok=True)
    hf_hub_download(
        repo_id="unsloth/Qwen3.5-0.8B-GGUF",
        filename=filename,
        local_dir=str(dst),
    )
    if not path.is_file() or path.stat().st_size < 450_000_000:
        raise RuntimeError(f"The local chat model download is incomplete: {path}")
    print(f"Local chat model ready: {path} ({path.stat().st_size:,} bytes)")


def download_font() -> None:
    path = ROOT / "assets/fonts/Vazirmatn-Regular.ttf"
    if path.is_file() and path.stat().st_size > 10_000:
        print(f"Persian font already present: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    urls = [
        "https://github.com/rastikerdar/vazirmatn/releases/download/v33.003/Vazirmatn-Regular.ttf",
        "https://github.com/google/fonts/raw/main/ofl/vazirmatn/Vazirmatn%5Bwght%5D.ttf",
    ]
    errors = []
    for url in urls:
        tmp = path.with_suffix(".ttf.part")
        try:
            urllib.request.urlretrieve(url, tmp)
            if tmp.stat().st_size > 10_000:
                tmp.replace(path)
                print(f"Persian font downloaded: {path}")
                return
        except Exception as exc:
            errors.append(f"{url}: {exc}")
        finally:
            tmp.unlink(missing_ok=True)
    raise RuntimeError("Could not download Vazirmatn font: " + " | ".join(errors))


def download_piper() -> None:
    dst = MODELS / "piper"
    dst.mkdir(parents=True, exist_ok=True)
    name = "fa_IR-amir-medium"
    model = dst / f"{name}.onnx"
    config = dst / f"{name}.onnx.json"
    if model.is_file() and config.is_file() and model.stat().st_size > 5_000_000:
        print(f"Piper voice already present: {model}")
        return
    base = ("https://huggingface.co/rhasspy/piper-voices/resolve/main/"
            "fa/fa_IR/amir/medium/fa_IR-amir-medium")
    errors = []
    for suffix, target in (("onnx", model), ("onnx.json", config)):
        tmp = target.with_suffix(target.suffix + ".part")
        try:
            request = urllib.request.Request(base + "." + suffix,
                                            headers={"User-Agent": "ai-lab-local-bot/1.0"})
            with urllib.request.urlopen(request, timeout=60) as response, open(tmp, "wb") as out:
                shutil.copyfileobj(response, out)
            tmp.replace(target)
        except Exception as exc:
            errors.append(f"{suffix}: {exc}")
        finally:
            tmp.unlink(missing_ok=True)
    if not model.is_file() or not config.is_file():
        raise RuntimeError("Could not download the Piper Persian voice: " + " | ".join(errors))
    print(f"Piper voice ready: {model} ({model.stat().st_size:,} bytes)")


def main() -> None:
    MODELS.mkdir(parents=True, exist_ok=True)
    # NLLB enables page/chapter translation; Qwen is the keyless local chat model.
    download_nllb()
    download_chat_model()
    download_font()
    download_piper()


if __name__ == "__main__":
    main()
